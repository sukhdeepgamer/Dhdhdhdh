import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import cookieParser from 'cookie-parser';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import db from './src/db.ts';
import Razorpay from 'razorpay';
import multer from 'multer';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const JWT_SECRET = process.env.JWT_SECRET || 'fallback_secret';
const PORT = 3000;

// Ensure uploads directory exists
const uploadDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Multer config
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

async function startServer() {
  const app = express();
  app.use(express.json());
  app.use(cookieParser());
  app.use('/uploads', express.static(uploadDir));

  // Razorpay instance
  const razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID || 'rzp_test_dummy',
    key_secret: process.env.RAZORPAY_KEY_SECRET || 'dummy_secret'
  });

  // --- Middleware ---
  const authenticate = (req: any, res: any, next: any) => {
    let token = req.cookies.token;

    console.log(`[Auth] Path: ${req.path}, Cookies token: ${!!req.cookies.token}, Auth header: ${!!req.headers.authorization}`);
    
    // Fallback to Authorization header
    if (!token && req.headers.authorization) {
      const parts = req.headers.authorization.split(' ');
      if (parts.length === 2 && parts[0] === 'Bearer') {
        token = parts[1];
        console.log(`[Auth] Using token from Authorization header`);
      }
    }

    if (!token) {
      console.log(`[Auth] No token found for path: ${req.path}`);
      return res.status(401).json({ error: 'Unauthorized' });
    }
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      req.user = decoded;
      next();
    } catch (err) {
      console.log(`[Auth] Invalid token for path: ${req.path}`);
      res.status(401).json({ error: 'Invalid token' });
    }
  };

  const isAdmin = (req: any, res: any, next: any) => {
    console.log(`[AdminCheck] Path: ${req.path}, User: ${req.user?.email}, Role: ${req.user?.role}`);
    if (req.user?.role !== 'admin') {
      console.log(`[AdminCheck] Access denied for ${req.user?.email}. Role is ${req.user?.role}. Expected 'admin'`);
      return res.status(403).json({ error: 'Forbidden' });
    }
    console.log(`[AdminCheck] Access granted for ${req.user?.email}`);
    next();
  };

  const optionalAuthenticate = (req: any, res: any, next: any) => {
    let token = req.cookies.token;
    if (!token && req.headers.authorization) {
      const parts = req.headers.authorization.split(' ');
      if (parts.length === 2 && parts[0] === 'Bearer') {
        token = parts[1];
      }
    }
    if (token) {
      try {
        const decoded = jwt.verify(token, JWT_SECRET) as any;
        req.user = decoded;
      } catch (err) {
        // Ignore invalid token for optional auth
      }
    }
    next();
  };

  // --- Auth Routes ---
  app.post('/api/auth/signup', async (req, res) => {
    const { name, email, password } = req.body;
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const result = db.prepare('INSERT INTO users (name, email, password) VALUES (?, ?, ?)').run(name, email, hashedPassword);
      const token = jwt.sign({ id: result.lastInsertRowid, email, role: 'user' }, JWT_SECRET);
      res.cookie('token', token, { 
        httpOnly: true, 
        secure: true, 
        sameSite: 'none',
        maxAge: 30 * 24 * 60 * 60 * 1000 // 30 days
      });
      res.json({ 
        token,
        user: { id: result.lastInsertRowid, name, email, role: 'user' } 
      });
    } catch (err: any) {
      res.status(400).json({ error: err.message.includes('UNIQUE') ? 'Email already exists' : 'Signup failed' });
    }
  });

  app.post('/api/auth/login', async (req, res) => {
    const { email, password } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email) as any;
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET);
    res.cookie('token', token, { 
      httpOnly: true, 
      secure: true, 
      sameSite: 'none',
      maxAge: 30 * 24 * 60 * 60 * 1000 // 30 days
    });
    res.json({ 
      token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role } 
    });
  });

  app.post('/api/auth/logout', (req, res) => {
    res.clearCookie('token');
    res.json({ message: 'Logged out' });
  });

  app.get('/api/auth/me', authenticate, (req: any, res) => {
    const user = db.prepare('SELECT id, name, email, role FROM users WHERE id = ?').get(req.user.id);
    res.json({ user });
  });

  // --- Product Routes ---
  app.get(['/api/products', '/api/get-products'], (req, res) => {
    const { category, limit, offset, minPrice, maxPrice, search } = req.query;
    let query = 'SELECT * FROM products WHERE is_available = 1';
    const params: any[] = [];

    if (category && category !== 'All') {
      query += ' AND category = ?';
      params.push(category);
    }

    if (minPrice) {
      query += ' AND (price * (1 - discount / 100.0)) >= ?';
      params.push(Number(minPrice));
    }

    if (maxPrice) {
      query += ' AND (price * (1 - discount / 100.0)) <= ?';
      params.push(Number(maxPrice));
    }

    if (search) {
      query += ' AND (name LIKE ? OR description LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    query += ' ORDER BY created_at DESC';
    
    if (limit !== undefined) {
      query += ' LIMIT ?';
      params.push(Number(limit));
      if (offset !== undefined) {
        query += ' OFFSET ?';
        params.push(Number(offset));
      }
    }

    const products = db.prepare(query).all(...params);
    
    // Also get total count for infinite scroll
    let countQuery = 'SELECT COUNT(*) as total FROM products WHERE is_available = 1';
    const countParams: any[] = [];
    if (category && category !== 'All') {
      countQuery += ' AND category = ?';
      countParams.push(category);
    }
    if (minPrice) {
      countQuery += ' AND (price * (1 - discount / 100.0)) >= ?';
      countParams.push(Number(minPrice));
    }
    if (maxPrice) {
      countQuery += ' AND (price * (1 - discount / 100.0)) <= ?';
      countParams.push(Number(maxPrice));
    }
    if (search) {
      countQuery += ' AND (name LIKE ? OR description LIKE ?)';
      countParams.push(`%${search}%`, `%${search}%`);
    }
    const { total } = db.prepare(countQuery).get(...countParams) as { total: number };

    res.json({ products, total });
  });

  app.get(['/api/categories', '/api/get-categories'], (req, res) => {
    const categories = db.prepare('SELECT DISTINCT category FROM products WHERE is_available = 1').all();
    res.json(categories.map((c: any) => c.category));
  });

  app.get('/api/admin/products', authenticate, isAdmin, (req, res) => {
    const products = db.prepare('SELECT * FROM products').all();
    res.json(products);
  });

  app.post('/api/admin/products', authenticate, isAdmin, upload.any(), (req, res) => {
    const { 
      name, description, price, mrp, discount, category, business_category, 
      stock, sku, pdp_template, hsn_code, is_bestseller, is_available, seo, variants 
    } = req.body;
    
    const files = req.files as Express.Multer.File[];
    const mainImages: string[] = [];
    let sizeChartUrl = '';
    
    files.forEach(file => {
      if (file.fieldname.startsWith('image_')) {
        mainImages.push(`/uploads/${file.filename}`);
      } else if (file.fieldname === 'size_chart') {
        sizeChartUrl = `/uploads/${file.filename}`;
      }
    });

    // Handle variant images
    const parsedVariants = JSON.parse(variants || '[]');
    const updatedVariants = parsedVariants.map((v: any) => {
      const variantImages: string[] = [];
      files.forEach(file => {
        if (file.fieldname.startsWith(`variant_${v.id}_image_`)) {
          variantImages.push(`/uploads/${file.filename}`);
        }
      });
      return { ...v, images: variantImages };
    });

    try {
      const result = db.prepare(`
        INSERT INTO products (
          name, description, price, mrp, discount, image_url, images, category, 
          business_category, stock, sku, pdp_template, hsn_code, is_bestseller, 
          is_available, seo, variants, size_chart
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        name, 
        description, 
        Number(price), 
        Number(mrp),
        Number(discount), 
        mainImages[0] || '', 
        JSON.stringify(mainImages),
        category, 
        business_category,
        Number(stock), 
        sku,
        pdp_template,
        hsn_code,
        is_bestseller === 'true' ? 1 : 0,
        is_available === 'false' || is_available === '0' ? 0 : 1,
        seo,
        JSON.stringify(updatedVariants),
        sizeChartUrl
      );
      res.json({ id: result.lastInsertRowid });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.put('/api/admin/products/:id', authenticate, isAdmin, upload.any(), (req, res) => {
    const { 
      name, description, price, mrp, discount, category, business_category, 
      stock, sku, pdp_template, hsn_code, is_bestseller, is_available, seo, variants 
    } = req.body;
    
    const files = req.files as Express.Multer.File[];
    const mainImages: string[] = JSON.parse(req.body.existing_images || '[]');
    let sizeChartUrl = req.body.existing_size_chart || '';
    
    files.forEach(file => {
      if (file.fieldname.startsWith('image_')) {
        mainImages.push(`/uploads/${file.filename}`);
      } else if (file.fieldname === 'size_chart') {
        sizeChartUrl = `/uploads/${file.filename}`;
      }
    });

    // Handle variant images
    const parsedVariants = JSON.parse(variants || '[]');
    const updatedVariants = parsedVariants.map((v: any) => {
      const variantImages: string[] = Array.isArray(v.images) ? v.images.filter((img: any) => typeof img === 'string') : [];
      files.forEach(file => {
        if (file.fieldname.startsWith(`variant_${v.id}_image_`)) {
          variantImages.push(`/uploads/${file.filename}`);
        }
      });
      return { ...v, images: variantImages };
    });

    try {
      db.prepare(`
        UPDATE products 
        SET name = ?, description = ?, price = ?, mrp = ?, discount = ?, image_url = ?, images = ?, 
            category = ?, business_category = ?, stock = ?, sku = ?, pdp_template = ?, 
            hsn_code = ?, is_bestseller = ?, is_available = ?, seo = ?, variants = ?, size_chart = ?
        WHERE id = ?
      `).run(
        name, 
        description, 
        Number(price), 
        Number(mrp),
        Number(discount), 
        mainImages[0] || '', 
        JSON.stringify(mainImages),
        category, 
        business_category,
        Number(stock), 
        sku,
        pdp_template,
        hsn_code,
        is_bestseller === 'true' ? 1 : 0,
        is_available === 'false' || is_available === '0' ? 0 : 1, 
        seo,
        JSON.stringify(updatedVariants),
        sizeChartUrl,
        req.params.id
      );
      res.json({ success: true });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.delete('/api/admin/products/:id', authenticate, isAdmin, (req, res) => {
    db.prepare('DELETE FROM products WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  });

  // --- Cart Routes ---
  app.get('/api/cart', authenticate, (req: any, res) => {
    const items = db.prepare(`
      SELECT c.*, p.name, p.price, p.discount, p.image_url 
      FROM cart c 
      JOIN products p ON c.product_id = p.id 
      WHERE c.user_id = ?
    `).all(req.user.id);
    res.json(items);
  });

  app.post('/api/cart', authenticate, (req: any, res) => {
    const { product_id, quantity } = req.body;
    db.prepare(`
      INSERT INTO cart (user_id, product_id, quantity) 
      VALUES (?, ?, ?) 
      ON CONFLICT(user_id, product_id) DO UPDATE SET quantity = quantity + EXCLUDED.quantity
    `).run(req.user.id, product_id, quantity || 1);
    res.json({ success: true });
  });

  app.delete(['/api/cart', '/api/clear-cart'], authenticate, (req: any, res) => {
    db.prepare('DELETE FROM cart WHERE user_id = ?').run(req.user.id);
    res.json({ success: true });
  });

  app.put('/api/cart/:id', authenticate, (req: any, res) => {
    const { quantity } = req.body;
    db.prepare('UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?').run(quantity, req.params.id, req.user.id);
    res.json({ success: true });
  });

  app.delete('/api/cart/:id', authenticate, (req: any, res) => {
    db.prepare('DELETE FROM cart WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
    res.json({ success: true });
  });

  // --- Order Routes ---
  app.post(['/api/orders', '/api/create-order'], optionalAuthenticate, async (req: any, res) => {
    const { 
      address, payment_method, cart_items, guest_name, guest_email, user_phone, 
      total_amount: frontendTotal, discount_amount = 0, tax_amount = 0, 
      shipping_fee = 0, wallet_amount = 0, advance_paid = 0, shipping_type = 'Standard'
    } = req.body;
    
    console.log('Order creation request:', { 
      user: req.user?.id || 'Guest', 
      payment_method, 
      total: frontendTotal,
      items_count: cart_items?.length,
      shipping_type
    });
    
    // Use total_amount from frontend if provided, otherwise calculate
    const total_amount = frontendTotal || cart_items.reduce((acc: number, item: any) => {
      const price = item.selectedVariant ? item.selectedVariant.price : item.price * (1 - item.discount / 100);
      return acc + price * item.quantity;
    }, 0);

    const transaction = db.transaction(() => {
      const orderResult = db.prepare(`
        INSERT INTO orders (
          user_id, guest_name, guest_email, user_phone, total_amount, 
          discount_amount, tax_amount, shipping_fee, wallet_amount, 
          advance_paid, payment_method, address, shipping_type
        ) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        req.user?.id || null, 
        guest_name || null, 
        guest_email || null, 
        user_phone || null, 
        total_amount, 
        discount_amount || 0,
        tax_amount || 0,
        shipping_fee || 0,
        wallet_amount || 0,
        advance_paid || 0,
        payment_method, 
        address,
        shipping_type
      );
      
      const orderId = orderResult.lastInsertRowid;
      const insertItem = db.prepare(`
        INSERT INTO order_items (order_id, product_id, quantity, price, product_name, product_image) 
        VALUES (?, ?, ?, ?, ?, ?)
      `);

      for (const item of cart_items) {
        const price = item.selectedVariant ? item.selectedVariant.price : item.price * (1 - item.discount / 100);
        insertItem.run(orderId, item.id, item.quantity, price, item.name, item.image_url);
        // Update stock
        db.prepare('UPDATE products SET stock = stock - ? WHERE id = ?').run(item.quantity, item.id);
      }

      // If wallet used, deduct balance
      if (req.user && wallet_amount > 0) {
        db.prepare('UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?').run(wallet_amount, req.user.id);
        db.prepare('INSERT INTO wallet_transactions (user_id, amount, type, reason, order_id) VALUES (?, ?, ?, ?, ?)').run(
          req.user.id, -wallet_amount, 'debit', 'Order Payment', orderId
        );
      }

      // Clear cart for logged in users
      if (req.user?.id) {
        db.prepare('DELETE FROM cart WHERE user_id = ?').run(req.user.id);
      }

      return orderId;
    });

    try {
      const orderId = transaction();
      console.log(`[OrderCreation] Order created successfully with ID: ${orderId}`);
      
      // Handle Razorpay if needed
      if (payment_method === 'upi' || (advance_paid && advance_paid > 0)) {
        const amountToPay = advance_paid > 0 ? advance_paid : total_amount;
        console.log(`[OrderCreation] Creating Razorpay order for amount: ${amountToPay}`);
        const options = {
          amount: Math.round(amountToPay * 100),
          currency: 'INR',
          receipt: `order_${orderId}`
        };
        const rzpOrder = await razorpay.orders.create(options);
        return res.json({ orderId, rzpOrder });
      }

      res.json({ orderId });
    } catch (err) {
      console.error('Order creation error:', err);
      res.status(500).json({ error: 'Order creation failed' });
    }
  });

  app.post('/api/orders/:id/pay', optionalAuthenticate, (req: any, res) => {
    // In a real app, you would verify the signature here
    const userId = req.user?.id || null;
    if (userId) {
      db.prepare('UPDATE orders SET payment_status = "paid" WHERE id = ? AND user_id = ?').run(req.params.id, userId);
    } else {
      db.prepare('UPDATE orders SET payment_status = "paid" WHERE id = ? AND user_id IS NULL').run(req.params.id);
    }
    res.json({ success: true });
  });

  app.get('/api/orders/track', (req, res) => {
    const { query } = req.query;
    if (!query) return res.status(400).json({ error: 'Query is required' });

    let orders;
    if (/^\d{10}$/.test(query as string)) {
      // Mobile number
      orders = db.prepare(`
        SELECT o.*, COALESCE(u.name, o.guest_name) as user_name 
        FROM orders o 
        LEFT JOIN users u ON o.user_id = u.id 
        WHERE o.user_phone = ? 
        ORDER BY o.created_at DESC
      `).all(query);
    } else {
      // Order ID
      const orderId = (query as string).replace('ORD-', '').replace(/^0+/, '');
      orders = db.prepare(`
        SELECT o.*, COALESCE(u.name, o.guest_name) as user_name 
        FROM orders o 
        LEFT JOIN users u ON o.user_id = u.id 
        WHERE o.id = ?
      `).all(orderId);
    }

    if (!orders || orders.length === 0) {
      return res.status(404).json({ error: 'No orders found' });
    }

    const ordersWithItems = orders.map((order: any) => {
      const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id);
      return { ...order, items };
    });

    res.json(ordersWithItems);
  });

  app.get('/api/orders', authenticate, (req: any, res) => {
    const orders = db.prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC').all(req.user.id);
    
    // Add items to each order
    const ordersWithItems = orders.map((order: any) => {
      const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id);
      return { ...order, items };
    });
    
    res.json(ordersWithItems);
  });

  app.get(['/api/admin/orders', '/api/get-orders'], authenticate, isAdmin, (req: any, res) => {
    console.log(`[AdminOrders] Fetching orders for admin: ${req.user?.email}`);
    const orders = db.prepare(`
      SELECT o.*, COALESCE(u.name, o.guest_name) as user_name 
      FROM orders o 
      LEFT JOIN users u ON o.user_id = u.id 
      ORDER BY o.created_at DESC
    `).all();
    
    console.log(`[AdminOrders] Found ${orders.length} orders`);
    
    // Add items to each order
    const ordersWithItems = orders.map((order: any) => {
      const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id);
      return { ...order, items };
    });
    
    res.json(ordersWithItems);
  });

  app.put('/api/admin/orders/:id', authenticate, isAdmin, (req, res) => {
    const { delivery_status, payment_status } = req.body;
    
    let query = 'UPDATE orders SET ';
    const params = [];
    
    if (delivery_status) {
      query += 'delivery_status = ?, ';
      params.push(delivery_status);
    }
    if (payment_status) {
      query += 'payment_status = ?, ';
      params.push(payment_status);
    }
    
    // Remove trailing comma and space
    query = query.slice(0, -2);
    query += ' WHERE id = ?';
    params.push(req.params.id);

    if (params.length > 1) {
      db.prepare(query).run(...params);
    }
    
    res.json({ success: true });
  });

  // --- Dashboard Stats ---
  app.get('/api/admin/stats', authenticate, isAdmin, (req, res) => {
    const totalSales = db.prepare('SELECT SUM(total_amount) as total FROM orders WHERE payment_status = "paid" OR payment_method = "cod"').get() as any;
    const totalOrders = db.prepare('SELECT COUNT(*) as count FROM orders').get() as any;
    const activeUsers = db.prepare('SELECT COUNT(*) as count FROM users').get() as any;
    res.json({
      totalSales: totalSales.total || 0,
      totalOrders: totalOrders.count,
      activeUsers: activeUsers.count
    });
  });

  app.get('/api/admin/analytics', authenticate, isAdmin, (req, res) => {
    const totalSales = db.prepare('SELECT SUM(total_amount) as total FROM orders WHERE payment_status = "paid" OR payment_method = "cod"').get() as any;
    const totalOrders = db.prepare('SELECT COUNT(*) as count FROM orders').get() as any;
    const prepaidOrders = db.prepare('SELECT COUNT(*) as count FROM orders WHERE payment_method != "cod"').get() as any;
    
    const avgOrderValue = totalOrders.count > 0 ? (totalSales.total || 0) / totalOrders.count : 0;
    const prepaidPercentage = totalOrders.count > 0 ? (prepaidOrders.count / totalOrders.count) * 100 : 0;

    // Sales trend (last 7 days)
    const salesTrend = db.prepare(`
      SELECT date(created_at) as date, SUM(total_amount) as value, COUNT(*) as count
      FROM orders
      WHERE created_at >= date('now', '-7 days')
      GROUP BY date(created_at)
      ORDER BY date(created_at) ASC
    `).all();

    // Category distribution
    const categoryDistribution = db.prepare(`
      SELECT p.category as name, COUNT(oi.id) as value
      FROM order_items oi
      JOIN products p ON oi.product_id = p.id
      GROUP BY p.category
    `).all();

    res.json({
      totalSales: totalSales.total || 0,
      totalOrders: totalOrders.count,
      prepaidPercentage,
      avgOrderValue,
      salesTrend,
      categoryDistribution,
      customerTypeDistribution: [
        { name: 'New Customers', value: 100 }, // Placeholder for now
        { name: 'Returning', value: 0 },
      ],
      orderFunnel: [
        { stage: 'Visits', value: 100 }, // Placeholder for now
        { stage: 'Add to Cart', value: 50 },
        { stage: 'Checkout', value: 20 },
        { stage: 'Orders', value: totalOrders.count },
      ]
    });
  });

  app.post('/api/admin/change-password', authenticate, isAdmin, async (req: any, res) => {
    const { currentPassword, newPassword } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id) as any;
    
    if (!user || !(await bcrypt.compare(currentPassword, user.password))) {
      return res.status(401).json({ error: 'Invalid current password' });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    db.prepare('UPDATE users SET password = ? WHERE id = ?').run(hashedPassword, req.user.id);
    res.json({ success: true });
  });

  // --- Admin User Management ---
  app.get('/api/admin/users', authenticate, isAdmin, (req, res) => {
    const users = db.prepare('SELECT id, name, email, role, created_at FROM users').all();
    res.json(users);
  });

  app.put('/api/admin/users/:id', authenticate, isAdmin, (req, res) => {
    const { role } = req.body;
    db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, req.params.id);
    res.json({ success: true });
  });

  app.delete('/api/admin/users/:id', authenticate, isAdmin, (req, res) => {
    db.prepare('DELETE FROM users WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  });

  // --- Wallet Management ---
  app.get('/api/admin/wallet/transactions', authenticate, isAdmin, (req, res) => {
    const transactions = db.prepare(`
      SELECT wt.*, u.name as user_name, u.email as user_email
      FROM wallet_transactions wt
      JOIN users u ON wt.user_id = u.id
      ORDER BY wt.created_at DESC
    `).all();
    res.json(transactions);
  });

  app.post('/api/admin/wallet/action', authenticate, isAdmin, (req, res) => {
    const { userId, amount, type, reason } = req.body;
    
    const transaction = db.transaction(() => {
      // Update user balance
      db.prepare('UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?').run(amount, userId);
      
      // Record transaction
      db.prepare(`
        INSERT INTO wallet_transactions (user_id, amount, type, reason)
        VALUES (?, ?, ?, ?)
      `).run(userId, amount, type, reason);
    });

    try {
      transaction();
      res.json({ success: true });
    } catch (err) {
      console.error('Wallet action error:', err);
      res.status(500).json({ error: 'Failed to update wallet' });
    }
  });

  // --- Review Management ---
  app.get('/api/admin/reviews', authenticate, isAdmin, (req, res) => {
    const reviews = db.prepare(`
      SELECT r.*, p.name as product_name, p.image_url as product_image
      FROM reviews r
      JOIN products p ON r.product_id = p.id
      ORDER BY r.created_at DESC
    `).all();
    res.json(reviews);
  });

  app.put('/api/admin/reviews/:id', authenticate, isAdmin, (req, res) => {
    const { status } = req.body;
    db.prepare('UPDATE reviews SET status = ? WHERE id = ?').run(status, req.params.id);
    res.json({ success: true });
  });

  app.delete('/api/admin/reviews/:id', authenticate, isAdmin, (req, res) => {
    db.prepare('DELETE FROM reviews WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  });

  // --- Offer Management ---
  app.get(['/api/admin/offers', '/api/get-offers'], (req, res) => {
    const offers = db.prepare('SELECT * FROM offers ORDER BY created_at DESC').all();
    res.json(offers);
  });

  app.post('/api/admin/offers', authenticate, isAdmin, (req, res) => {
    const { name, type, logic, discountType, discountValue, autoApply, startDate, endDate } = req.body;
    db.prepare(`
      INSERT INTO offers (name, type, logic, discount_type, discount_value, auto_apply, start_date, end_date)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(name, type, logic, discountType, discountValue, autoApply ? 1 : 0, startDate, endDate);
    res.json({ success: true });
  });

  app.delete('/api/admin/offers/:id', authenticate, isAdmin, (req, res) => {
    db.prepare('DELETE FROM offers WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  });

  // --- Admin Settings Management ---
  app.get('/api/admin/settings', authenticate, isAdmin, (req, res) => {
    const settings = db.prepare('SELECT * FROM settings').all();
    const settingsObj = settings.reduce((acc: any, curr: any) => {
      acc[curr.key] = curr.value;
      return acc;
    }, {});
    res.json(settingsObj);
  });

  app.post('/api/admin/settings', authenticate, isAdmin, (req, res) => {
    const settings = req.body;
    const upsert = db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');
    const transaction = db.transaction((data) => {
      for (const [key, value] of Object.entries(data)) {
        upsert.run(key, value);
      }
    });
    transaction(settings);
    res.json({ success: true });
  });

  // --- Public Settings ---
  app.get('/api/settings', (req, res) => {
    const settings = db.prepare('SELECT * FROM settings').all();
    const settingsObj = settings.reduce((acc: any, curr: any) => {
      acc[curr.key] = curr.value;
      return acc;
    }, {});
    res.json(settingsObj);
  });

  // --- OAuth Callback Hints (Add your manual logic here) ---
  app.get('/api/auth/google/callback', async (req, res) => {
    // 1. Exchange code for tokens
    // 2. Get user info from Google
    // 3. Find or create user in DB
    // 4. Set JWT cookie and redirect
    res.send('Google Auth Callback - Implement your manual logic here');
  });

  app.get('/api/auth/meta/callback', async (req, res) => {
    // 1. Exchange code for tokens
    // 2. Get user info from Meta
    // 3. Find or create user in DB
    // 4. Set JWT cookie and redirect
    res.send('Meta Auth Callback - Implement your manual logic here');
  });

  // --- OAuth Placeholder Routes ---
  app.get('/api/auth/google/url', (req, res) => {
    const redirectUri = `${process.env.APP_URL}/api/auth/google/callback`;
    const url = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${process.env.GOOGLE_CLIENT_ID}&redirect_uri=${redirectUri}&response_type=code&scope=email%20profile`;
    res.json({ url });
  });

  app.get('/api/auth/meta/url', (req, res) => {
    const redirectUri = `${process.env.APP_URL}/api/auth/meta/callback`;
    const url = `https://www.facebook.com/v12.0/dialog/oauth?client_id=${process.env.META_CLIENT_ID}&redirect_uri=${redirectUri}&scope=email`;
    res.json({ url });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'dist', 'index.html')));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
