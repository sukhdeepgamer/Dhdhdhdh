export interface WalletTransaction {
  id: string;
  userId: number;
  amount: number; // Positive for credit, negative for debit
  type: 'credit' | 'debit';
  reason: string;
  orderId?: number;
  createdAt: string;
}

export interface User {
  id: number;
  name: string;
  email: string;
  role: 'user' | 'admin';
  walletBalance: number;
}

export interface ProductVariant {
  id: string;
  color: string;
  colorCode?: string;
  size: string;
  mrp: number;
  price: number;
  stock: number;
  sku: string;
  images: string[];
}

export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  mrp?: number;
  discount: number;
  image_url: string;
  category: string;
  business_category?: string;
  stock: number;
  sku?: string;
  is_available: boolean;
  is_bestseller?: boolean;
  pdp_template?: string;
  hsn_code?: string;
  size_chart_url?: string;
  variants?: ProductVariant[];
  seo?: {
    title: string;
    description: string;
    keywords?: string;
    slug?: string;
    socialImage?: string;
  };
}

export interface Address {
  id: string;
  fullName: string;
  mobileNumber: string;
  houseNumber: string;
  street: string;
  area: string;
  city: string;
  state: string;
  pincode: string;
  landmark?: string;
  type: 'home' | 'work' | 'other';
  isDefault: boolean;
}

export interface HomepageSettings {
  announcementBar: {
    enabled: boolean;
    text: string;
    backgroundColor: string;
    textColor: string;
    link?: string;
  };
  banners: {
    id: string;
    type: 'image' | 'video';
    url: string;
    link?: string;
    order: number;
    isVisible: boolean;
  }[];
}

export interface CartItem extends Product {
  cart_id: number;
  quantity: number;
  selectedVariant?: ProductVariant;
}

export interface Order {
  id: number;
  user_id: number;
  user_name: string;
  user_phone?: string;
  total_amount: number;
  payment_method: 'COD' | 'Prepaid';
  payment_status: 'pending' | 'paid' | 'failed';
  delivery_status: 'pending' | 'accepted' | 'shipped' | 'pickup_ready' | 'fulfilled' | 'cancelled' | 'rejected';
  address: string;
  shipping_type: 'Standard' | 'Express';
  created_at: string;
  items: {
    product_id: number;
    product_name: string;
    product_image: string;
    quantity: number;
    price: number;
  }[];
}

export interface Review {
  id: number;
  product_id: number;
  product_name: string;
  product_image: string;
  user_name: string;
  rating: number;
  comment: string;
  status: 'pending' | 'approved' | 'rejected' | 'reported' | 'spam';
  created_at: string;
}

export interface RTORule {
  id: string;
  name: string;
  type: 'product' | 'category' | 'variant' | 'location';
  targetIds: string[]; // IDs of products, categories, or variants
  locations?: string[]; // PIN codes or States
  paymentRules: {
    allowCOD: boolean;
    requireAdvance: boolean;
    advanceType?: 'fixed' | 'percentage';
    advanceValue?: number;
  };
  priority: number; // Higher number = higher priority
}

export interface DeliverySettings {
  flatFee: number;
  freeDeliveryThreshold: number;
  radiusType: 'local' | 'all_india';
  minHandlingTime: number;
  maxHandlingTime: number;
}

export interface Offer {
  id: string;
  name: string;
  type: 'product' | 'cart' | 'bogo';
  logic: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  couponCode?: string;
  autoApply: boolean;
  minCartValue?: number;
  targetIds?: string[]; // product/category IDs
  startDate: string;
  endDate: string;
  usageLimit?: number;
  usedCount: number;
  status: 'active' | 'scheduled' | 'expired';
}

export interface TaxRule {
  id: string;
  name: string;
  percentage: number;
  applyTo: 'product' | 'category' | 'all';
  targetIds?: string[];
  includeInPrice: boolean;
  type: 'gst' | 'extra_charge';
}

export interface ShippingIntegration {
  method: 'shiprocket' | 'manual';
  apiKey?: string;
  apiSecret?: string;
  enabled: boolean;
}

export interface AnalyticsData {
  totalSales: number;
  totalOrders: number;
  prepaidPercentage: number;
  avgOrderValue: number;
  salesTrend: { date: string; value: number; count: number }[];
  customerTypeDistribution: { name: string; value: number }[];
  categoryDistribution: { name: string; value: number }[];
  orderFunnel: { stage: string; value: number }[];
}
