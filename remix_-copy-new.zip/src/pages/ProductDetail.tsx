import React, { useState, useEffect, useMemo } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingCart, Heart, Star, ArrowLeft, ShieldCheck, Truck, RotateCcw, Share2, Plus, Minus, ChevronRight, Info, Check } from 'lucide-react';
import { Product, ProductVariant, DeliverySettings } from '../types';
import { useCart } from '../contexts/CartContext';
import { useWishlist } from '../contexts/WishlistContext';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | null>(null);
  const [deliverySettings, setDeliverySettings] = useState<DeliverySettings | null>(null);
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();

  useEffect(() => {
    setLoading(true);
    fetch(`/api/products`)
      .then(res => res.json())
      .then(data => {
        const found = data.products.find((p: Product) => p.id === Number(id));
        if (found) {
          setProduct(found);
          if (found.variants && found.variants.length > 0) {
            setSelectedVariant(found.variants[0]);
          }
        } else {
          navigate('/products');
        }
        setLoading(false);
      })
      .catch(() => {
        setLoading(false);
        navigate('/products');
      });

    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data && data.delivery_settings) {
          setDeliverySettings(JSON.parse(data.delivery_settings));
        }
      });
  }, [id, navigate]);

  // Update SEO Meta Tags
  useEffect(() => {
    if (product) {
      document.title = product.seo?.title || `${product.name} | iCraft Tech`;
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) {
        metaDesc.setAttribute('content', product.seo?.description || product.description);
      }
    }
  }, [product]);

  const images = useMemo(() => {
    if (!product) return [];
    if (selectedVariant && selectedVariant.images && selectedVariant.images.length > 0) {
      return selectedVariant.images;
    }
    return [
      product.image_url,
      "https://picsum.photos/seed/tech1/1200/1200",
      "https://picsum.photos/seed/tech2/1200/1200",
      "https://picsum.photos/seed/tech3/1200/1200",
    ];
  }, [product, selectedVariant]);

  useEffect(() => {
    setCurrentImageIndex(0);
  }, [selectedVariant]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="w-8 h-8 border-2 border-black border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!product) return null;

  const currentPrice = selectedVariant ? selectedVariant.price : product.price * (1 - product.discount / 100);
  const currentMrp = selectedVariant ? selectedVariant.mrp : product.price;
  const currentStock = selectedVariant ? selectedVariant.stock : product.stock;
  const discountPercentage = selectedVariant 
    ? Math.round(((selectedVariant.mrp - selectedVariant.price) / selectedVariant.mrp) * 100)
    : product.discount;

  const estimatedDelivery = deliverySettings ? (() => {
    const today = new Date();
    const minDate = new Date(today);
    minDate.setDate(today.getDate() + deliverySettings.minHandlingTime);
    const maxDate = new Date(today);
    maxDate.setDate(today.getDate() + deliverySettings.maxHandlingTime);
    
    const options: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'short' };
    return `${minDate.toLocaleDateString('en-IN', options)} - ${maxDate.toLocaleDateString('en-IN', options)}`;
  })() : null;

  const colors = product.variants ? Array.from(new Set(product.variants.map(v => v.color))) : [];
  const sizes = product.variants ? Array.from(new Set(product.variants.map(v => v.size))) : [];

  const handleAddToCart = () => {
    const cartItem = {
      ...product,
      selectedVariant: selectedVariant || undefined,
      quantity
    };
    addToCart(cartItem as any);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Mobile Top Bar */}
      <div className="lg:hidden sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100 px-4 py-3 flex items-center justify-between">
        <button onClick={() => navigate(-1)} className="p-2 -ml-2">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div className="flex items-center space-x-2">
          <button className="p-2">
            <Share2 className="w-5 h-5" />
          </button>
          <button
            onClick={() => toggleWishlist(product)}
            className={cn("p-2", isInWishlist(product.id) ? "text-red-500" : "text-gray-400")}
          >
            <Heart className={cn("w-5 h-5", isInWishlist(product.id) && "fill-current")} />
          </button>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          
          {/* Left: Image Carousel */}
          <div className="lg:col-span-7 space-y-6">
            <div className="relative aspect-square bg-gray-50 rounded-lg overflow-hidden border border-gray-100 group">
              <AnimatePresence mode="wait">
                <motion.img
                  key={`${selectedVariant?.id || 'main'}-${currentImageIndex}`}
                  src={images[currentImageIndex]}
                  alt={product.name}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </AnimatePresence>
              
              {/* Carousel Controls */}
              {images.length > 1 && (
                <>
                  <div className="absolute inset-y-0 left-0 flex items-center">
                    <button 
                      onClick={() => setCurrentImageIndex((prev) => (prev === 0 ? images.length - 1 : prev - 1))}
                      className="p-2 bg-white/50 backdrop-blur-md rounded-r-xl opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <ArrowLeft className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="absolute inset-y-0 right-0 flex items-center">
                    <button 
                      onClick={() => setCurrentImageIndex((prev) => (prev === images.length - 1 ? 0 : prev + 1))}
                      className="p-2 bg-white/50 backdrop-blur-md rounded-l-xl opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>
                </>
              )}

              {/* Dots */}
              {images.length > 1 && (
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
                  {images.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setCurrentImageIndex(i)}
                      className={cn(
                        "w-1.5 h-1.5 rounded-full transition-all",
                        currentImageIndex === i ? "bg-black w-4" : "bg-black/20"
                      )}
                    />
                  ))}
                </div>
              )}
            </div>
            
            {/* Thumbnails */}
            {images.length > 1 && (
              <div className="grid grid-cols-4 gap-4">
                {images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrentImageIndex(i)}
                    className={cn(
                      "aspect-square rounded-lg overflow-hidden border-2 transition-all",
                      currentImageIndex === i ? "border-black" : "border-transparent opacity-60 hover:opacity-100"
                    )}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right: Product Info */}
          <div className="lg:col-span-5 space-y-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-[10px] font-bold uppercase tracking-widest text-gray-400">
                <Link to="/" className="hover:text-black">Home</Link>
                <ChevronRight className="w-3 h-3" />
                <span className="text-black">{product.category}</span>
              </div>
              
              <h1 className="text-3xl lg:text-4xl font-bold text-black leading-tight">
                {product.name}
              </h1>

              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className={cn("w-3.5 h-3.5", i < 4 ? "text-black fill-current" : "text-gray-200")} />
                  ))}
                  <span className="ml-2 text-xs font-medium text-gray-500">4.8 (120 reviews)</span>
                </div>
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex items-baseline space-x-3">
                <span className="text-2xl font-bold text-black">
                  ₹{currentPrice.toLocaleString()}
                </span>
                {discountPercentage > 0 && (
                  <span className="text-lg text-gray-400 line-through font-normal">
                    ₹{currentMrp.toLocaleString()}
                  </span>
                )}
              </div>
              {discountPercentage > 0 && (
                <span className="inline-block px-2 py-0.5 bg-red-50 text-red-600 text-[10px] font-bold rounded">
                  SAVE {discountPercentage}%
                </span>
              )}
              {currentStock <= 5 && currentStock > 0 && (
                <p className="text-xs font-bold text-orange-600 mt-2">Only {currentStock} left in stock - order soon!</p>
              )}
              {currentStock === 0 && (
                <p className="text-xs font-bold text-red-600 mt-2">Out of Stock</p>
              )}
            </div>

            {/* Variants Selection */}
            {product.variants && product.variants.length > 0 && (
              <div className="space-y-6 pt-6 border-t border-gray-100">
                {colors.length > 0 && (
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Color: <span className="text-black">{selectedVariant?.color}</span></label>
                    </div>
                    <div className="flex flex-wrap gap-3">
                      {colors.map((color) => {
                        const variant = product.variants?.find(v => v.color === color);
                        const isSelected = selectedVariant?.color === color;
                        const colorCode = variant?.colorCode || (color as string).toLowerCase();
                        
                        return (
                          <button
                            key={color}
                            onClick={() => {
                              const newVariant = product.variants?.find(v => v.color === color && (v.size === selectedVariant?.size || true));
                              if (newVariant) setSelectedVariant(newVariant);
                            }}
                            className={cn(
                              "group relative w-10 h-10 rounded-full border-2 transition-all p-0.5",
                              isSelected ? "border-black scale-110" : "border-transparent hover:border-gray-200"
                            )}
                            title={color}
                          >
                            <div 
                              className="w-full h-full rounded-full border border-black/5 flex items-center justify-center"
                              style={{ backgroundColor: colorCode }}
                            >
                              {isSelected && <Check className={cn("w-4 h-4", ['white', '#ffffff', 'yellow', 'lightgray'].includes((colorCode as string).toLowerCase()) ? "text-black" : "text-white")} />}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {sizes.length > 0 && (
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Size: <span className="text-black">{selectedVariant?.size}</span></label>
                      <button className="text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-black underline">Size Guide</button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {sizes.map((size) => {
                        const isSelected = selectedVariant?.size === size;
                        const isAvailable = product.variants?.some(v => v.size === size && v.color === selectedVariant?.color && v.stock > 0);
                        return (
                          <button
                            key={size}
                            onClick={() => {
                              const newVariant = product.variants?.find(v => v.size === size && v.color === selectedVariant?.color);
                              if (newVariant) setSelectedVariant(newVariant);
                            }}
                            disabled={!isAvailable}
                            className={cn(
                              "min-w-[3rem] h-10 px-4 rounded-md border text-sm font-bold transition-all",
                              isSelected ? "border-black bg-black text-white" : "border-gray-200 text-gray-600 hover:border-black",
                              !isAvailable && "opacity-30 cursor-not-allowed line-through"
                            )}
                          >
                            {size}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Shopify Style Options */}
            <div className="space-y-6 pt-6 border-t border-gray-100">
              <div className="space-y-3">
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Quantity</label>
                <div className="flex items-center w-32 border border-gray-200 rounded-md overflow-hidden">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 flex items-center justify-center hover:bg-gray-50"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <span className="flex-1 text-center text-sm font-bold">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-10 h-10 flex items-center justify-center hover:bg-gray-50"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                </div>
              </div>

              <div className="space-y-3">
                <button
                  onClick={handleAddToCart}
                  disabled={currentStock === 0}
                  className={cn(
                    "w-full h-12 rounded-md font-bold uppercase tracking-widest text-[10px] transition-all",
                    currentStock > 0 ? "bg-black text-white hover:bg-gray-900" : "bg-gray-100 text-gray-400 cursor-not-allowed"
                  )}
                >
                  {currentStock > 0 ? 'Add to Cart' : 'Out of Stock'}
                </button>
                <button 
                  disabled={currentStock === 0}
                  className={cn(
                    "w-full h-12 border rounded-md font-bold uppercase tracking-widest text-[10px] transition-all",
                    currentStock > 0 ? "border-black text-black hover:bg-gray-50" : "border-gray-200 text-gray-300 cursor-not-allowed"
                  )}
                >
                  Buy it now
                </button>
              </div>
            </div>

            {/* Delivery Info */}
            {estimatedDelivery && (
              <div className="p-4 bg-gray-50 rounded-xl space-y-3">
                <div className="flex items-center space-x-3 text-gray-600">
                  <Truck className="w-5 h-5" />
                  <div className="text-xs">
                    <p className="font-bold text-black">Estimated Delivery</p>
                    <p>{estimatedDelivery}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Description */}
            <div className="space-y-4 pt-6 border-t border-gray-100">
              <h3 className="text-xs font-bold uppercase tracking-widest text-black">Description</h3>
              <p className="text-sm text-gray-600 leading-relaxed">
                {product.description || "This premium product is crafted with the finest materials to ensure lasting quality and performance. Perfect for everyday use, it combines style with functionality."}
              </p>
            </div>

            {/* Shopify Style Accordions (Simplified) */}
            <div className="space-y-4 pt-6 border-t border-gray-100">
              {[
                { icon: Info, title: 'Product Details' },
                { icon: Truck, title: 'Shipping & Returns' },
                { icon: ShieldCheck, title: 'Warranty Information' }
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between py-2 cursor-pointer group">
                  <div className="flex items-center space-x-3">
                    <item.icon className="w-4 h-4 text-gray-400 group-hover:text-black" />
                    <span className="text-xs font-bold text-gray-600 group-hover:text-black">{item.title}</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-black" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Sticky Mobile Add to Cart */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-100 p-4 pb-8">
        <div className="flex items-center space-x-4">
          <div className="flex-1">
            <button
              onClick={handleAddToCart}
              disabled={currentStock === 0}
              className={cn(
                "w-full h-12 rounded-md font-bold uppercase tracking-widest text-[10px]",
                currentStock > 0 ? "bg-black text-white" : "bg-gray-100 text-gray-400"
              )}
            >
              {currentStock > 0 ? `Add to Cart • ₹${currentPrice.toLocaleString()}` : 'Out of Stock'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
