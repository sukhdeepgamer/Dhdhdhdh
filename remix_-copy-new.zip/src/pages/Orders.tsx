import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Package, Truck, CheckCircle, Clock } from 'lucide-react';
import { Order } from '../types';
import { apiFetch } from '../utils/api';

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiFetch('/api/orders')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setOrders(data);
        } else {
          setOrders([]);
        }
        setLoading(false);
      })
      .catch(() => {
        setOrders([]);
        setLoading(false);
      });
  }, []);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'delivered': return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'out_for_delivery': return <Truck className="w-5 h-5 text-blue-500" />;
      case 'packed': return <Package className="w-5 h-5 text-purple-500" />;
      default: return <Clock className="w-5 h-5 text-yellow-500" />;
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 sm:px-6 lg:px-8 space-y-8">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-gray-900">My Orders</h1>
        <p className="text-gray-500">Track and manage your gadget purchases</p>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-40 bg-white rounded-3xl animate-pulse border border-gray-100" />
          ))}
        </div>
      ) : orders.length === 0 ? (
        <div className="text-center py-20 bg-white rounded-3xl border border-gray-100">
          <Package className="w-16 h-16 text-gray-200 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-gray-900">No orders yet</h3>
          <p className="text-gray-500">Your order history will appear here</p>
        </div>
      ) : (
        <div className="space-y-6">
          {Array.isArray(orders) && orders.map((order) => (
            <motion.div
              key={order.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden"
            >
              <div className="p-6 flex flex-wrap justify-between items-center gap-4 bg-gray-50/50">
                <div className="space-y-1">
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Order ID</p>
                  <p className="font-mono font-bold text-gray-900">#ORD-{order.id.toString().padStart(6, '0')}</p>
                </div>
                <div className="space-y-1 text-right">
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Date</p>
                  <p className="font-bold text-gray-900">{new Date(order.created_at).toLocaleDateString()}</p>
                </div>
              </div>
              <div className="p-6 space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-white rounded-xl shadow-sm border border-gray-100">
                      {getStatusIcon(order.delivery_status)}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-gray-900 uppercase">
                        {order.delivery_status.replace(/_/g, ' ')}
                      </p>
                      <p className="text-xs text-gray-500">Latest update on {new Date(order.created_at).toLocaleTimeString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-gray-900">₹{order.total_amount.toFixed(0)}</p>
                    <p className="text-xs font-bold text-green-600 uppercase">{order.payment_status}</p>
                  </div>
                </div>
                <div className="p-4 bg-purple-50/50 rounded-2xl border border-purple-100">
                  <p className="text-xs font-bold text-purple-600 uppercase mb-1 text-right">Delivery Address</p>
                  <p className="text-sm text-gray-700 text-right">{order.address}</p>
                </div>

                {/* Order Items */}
                <div className="space-y-4 pt-4 border-t border-gray-100">
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Items</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {order.items?.map((item, idx) => (
                      <div key={idx} className="flex items-center space-x-3 bg-gray-50 p-3 rounded-2xl border border-gray-100">
                        <img 
                          src={item.product_image || 'https://picsum.photos/seed/product/100/100'} 
                          alt={item.product_name} 
                          className="w-12 h-12 rounded-lg object-cover flex-shrink-0"
                        />
                        <div className="min-w-0">
                          <p className="text-sm font-bold text-gray-900 truncate">{item.product_name}</p>
                          <p className="text-xs text-gray-500">Qty: {item.quantity} × ₹{item.price.toFixed(0)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
