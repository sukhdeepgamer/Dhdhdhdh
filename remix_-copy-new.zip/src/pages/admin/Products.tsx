import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Edit2, Trash2, Search, Filter, Package } from 'lucide-react';
import AdminSidebar from '../../components/AdminSidebar';
import ConfirmationModal from '../../components/ConfirmationModal';
import { Product } from '../../types';
import toast from 'react-hot-toast';
import { apiFetch } from '../../utils/api';

export default function AdminProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [deleteConfirm, setDeleteConfirm] = useState<{ isOpen: boolean; id: number | null }>({
    isOpen: false,
    id: null
  });

  const fetchProducts = () => {
    apiFetch('/api/admin/products')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setProducts(data);
        } else {
          setProducts([]);
        }
      })
      .catch(() => setProducts([]));
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleDelete = async (id: number) => {
    const res = await apiFetch(`/api/admin/products/${id}`, { method: 'DELETE' });
    if (res.ok) {
      toast.success('Product deleted');
      fetchProducts();
    }
    setDeleteConfirm({ isOpen: false, id: null });
  };

  return (
    <div className="flex min-h-screen bg-[#F5F7F9]">
      <AdminSidebar />
      <div className="flex-1 ml-64">
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 sticky top-0 z-40">
          <div className="flex items-center space-x-3">
            <Package className="w-6 h-6 text-teal-600" />
            <h1 className="text-lg font-bold text-gray-900">Products Management</h1>
          </div>
          <Link
            to="/admin/products/add"
            className="flex items-center space-x-2 px-4 py-2 bg-teal-600 text-white rounded-lg text-sm font-bold hover:bg-teal-700 transition-all shadow-lg shadow-teal-100"
          >
            <Plus className="w-4 h-4" />
            <span>Add Product</span>
          </Link>
        </header>

        <main className="p-8 space-y-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input 
                type="text" 
                placeholder="Search products by name, SKU or category..."
                className="w-full pl-10 pr-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all"
              />
            </div>
            <div className="flex items-center space-x-3">
              <button className="flex items-center space-x-2 px-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm font-bold text-gray-600 hover:bg-gray-50 transition-all">
                <Filter className="w-4 h-4" />
                <span>Filters</span>
              </button>
              <select className="px-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm font-bold text-gray-600 focus:outline-none focus:ring-2 focus:ring-teal-500/20">
                <option>Sort by: Newest</option>
                <option>Price: Low to High</option>
                <option>Price: High to Low</option>
                <option>Stock: Low to High</option>
              </select>
            </div>
          </div>

          <ConfirmationModal
            isOpen={deleteConfirm.isOpen}
            onClose={() => setDeleteConfirm({ isOpen: false, id: null })}
            onConfirm={() => deleteConfirm.id && handleDelete(deleteConfirm.id)}
            title="Delete Product"
            message="Are you sure you want to delete this product? This action cannot be undone."
            confirmLabel="Delete"
          />

          <div className="bg-white rounded-3xl border border-gray-200 shadow-sm overflow-hidden">
            <table className="w-full text-left">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Product Info</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Category</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Pricing</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Inventory</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {Array.isArray(products) && products.map((product) => {
                  const discount = product.mrp ? Math.round(((product.mrp - product.price) / product.mrp) * 100) : 0;
                  return (
                    <tr key={product.id} className="hover:bg-gray-50/50 transition-colors group">
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 rounded-xl border border-gray-100 overflow-hidden bg-gray-50">
                            <img src={product.image_url} alt="" className="w-full h-full object-cover" />
                          </div>
                          <div className="flex flex-col">
                            <span className="font-bold text-gray-900 leading-tight">{product.name}</span>
                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mt-1">SKU: {product.sku || 'N/A'}</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-1 bg-teal-50 text-teal-600 text-[10px] font-bold rounded uppercase tracking-wider border border-teal-100">
                          {product.category}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex flex-col">
                          <span className="font-bold text-gray-900">₹{product.price}</span>
                          {product.mrp && product.mrp > product.price && (
                            <div className="flex items-center space-x-2">
                              <span className="text-[10px] text-gray-400 line-through">₹{product.mrp}</span>
                              <span className="text-[10px] text-green-600 font-bold">{discount}% OFF</span>
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex flex-col">
                          <span className={`font-bold text-sm ${product.stock <= 5 ? 'text-orange-600' : 'text-gray-900'}`}>
                            {product.stock} units
                          </span>
                          {product.stock <= 5 && (
                            <span className="text-[10px] font-bold text-orange-500 uppercase tracking-wider">Low Stock</span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase border ${
                          product.is_available 
                            ? 'bg-green-50 text-green-600 border-green-100' 
                            : 'bg-gray-50 text-gray-400 border-gray-100'
                        }`}>
                          {product.is_available ? 'Active' : 'Hidden'}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right space-x-1">
                        <Link
                          to={`/admin/products/edit/${product.id}`}
                          className="inline-block p-2 text-gray-300 hover:text-teal-600 hover:bg-teal-50 rounded-lg transition-all"
                        >
                          <Edit2 className="w-4 h-4" />
                        </Link>
                        <button
                          onClick={() => setDeleteConfirm({ isOpen: true, id: product.id })}
                          className="p-2 text-gray-300 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {(!Array.isArray(products) || products.length === 0) && (
              <div className="p-20 text-center space-y-4">
                <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto">
                  <Package className="w-10 h-10 text-gray-200" />
                </div>
                <div className="space-y-1">
                  <p className="text-gray-900 font-bold">No products found</p>
                  <p className="text-gray-500 text-sm">Start by adding your first product to the catalog.</p>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
