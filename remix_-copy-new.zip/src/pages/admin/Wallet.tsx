import React, { useState, useEffect } from 'react';
import { 
  Wallet, 
  Plus, 
  Minus, 
  Search, 
  History, 
  User as UserIcon, 
  ArrowUpRight, 
  ArrowDownRight,
  Filter,
  ChevronRight
} from 'lucide-react';
import AdminSidebar from '../../components/AdminSidebar';
import { User, WalletTransaction } from '../../types';
import toast from 'react-hot-toast';
import { motion, AnimatePresence } from 'motion/react';
import { apiFetch } from '../../utils/api';

export default function AdminWallet() {
  const [users, setUsers] = useState<User[]>([]);
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [showActionModal, setShowActionModal] = useState<{ isOpen: boolean; type: 'credit' | 'debit'; user: User | null }>({
    isOpen: false,
    type: 'credit',
    user: null
  });
  const [actionAmount, setActionAmount] = useState('');
  const [actionReason, setActionReason] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Mocking API calls
      const usersRes = await apiFetch('/api/admin/users');
      const usersData = await usersRes.json();
      setUsers(usersData || []);

      const transRes = await apiFetch('/api/admin/wallet/transactions');
      const transData = await transRes.json();
      setTransactions(transData || []);
    } catch (error) {
      console.error('Failed to fetch wallet data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleWalletAction = async () => {
    if (!showActionModal.user || !actionAmount || !actionReason) {
      toast.error('Please fill in all fields');
      return;
    }

    const amount = parseFloat(actionAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    try {
      const res = await apiFetch('/api/admin/wallet/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: showActionModal.user.id,
          amount: showActionModal.type === 'credit' ? amount : -amount,
          type: showActionModal.type,
          reason: actionReason
        })
      });

      if (res.ok) {
        toast.success(`Points ${showActionModal.type === 'credit' ? 'added' : 'deducted'} successfully`);
        setShowActionModal({ isOpen: false, type: 'credit', user: null });
        setActionAmount('');
        setActionReason('');
        fetchData();
      } else {
        toast.error('Failed to update wallet');
      }
    } catch (error) {
      toast.error('Something went wrong');
    }
  };

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    user.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex min-h-screen bg-[#F5F7F9]">
      <AdminSidebar />
      
      <div className="flex-1 ml-64">
        {/* Topbar */}
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 sticky top-0 z-40">
          <div className="flex items-center space-x-3">
            <Wallet className="w-6 h-6 text-teal-600" />
            <h1 className="text-lg font-bold text-gray-900">V Wallet & Points System</h1>
          </div>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input 
                type="text" 
                placeholder="Search users..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 w-64 transition-all"
              />
            </div>
          </div>
        </header>

        <main className="p-8 space-y-8">
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="p-2 bg-teal-50 rounded-lg">
                  <Wallet className="w-5 h-5 text-teal-600" />
                </div>
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Total Liability</span>
              </div>
              <p className="text-2xl font-bold text-gray-900">₹{users.reduce((acc, u) => acc + (u.walletBalance || 0), 0).toLocaleString()}</p>
              <p className="text-xs text-gray-500 mt-1">Total points across all users</p>
            </div>
            <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="p-2 bg-blue-50 rounded-lg">
                  <ArrowUpRight className="w-5 h-5 text-blue-600" />
                </div>
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Total Credits</span>
              </div>
              <p className="text-2xl font-bold text-gray-900">₹{transactions.filter(t => t.type === 'credit').reduce((acc, t) => acc + t.amount, 0).toLocaleString()}</p>
              <p className="text-xs text-gray-500 mt-1">Total points added manually/refunds</p>
            </div>
            <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="p-2 bg-orange-50 rounded-lg">
                  <ArrowDownRight className="w-5 h-5 text-orange-600" />
                </div>
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Total Debits</span>
              </div>
              <p className="text-2xl font-bold text-gray-900">₹{Math.abs(transactions.filter(t => t.type === 'debit').reduce((acc, t) => acc + t.amount, 0)).toLocaleString()}</p>
              <p className="text-xs text-gray-500 mt-1">Total points used in orders/deducted</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* User List */}
            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                <h2 className="text-sm font-bold text-gray-900">User Wallet Balances</h2>
                <button className="p-2 hover:bg-gray-50 rounded-lg text-gray-400">
                  <Filter className="w-4 h-4" />
                </button>
              </div>
              <div className="divide-y divide-gray-100 max-h-[600px] overflow-y-auto custom-scrollbar">
                {filteredUsers.map(user => (
                  <div key={user.id} className="p-4 flex items-center justify-between hover:bg-gray-50/50 transition-colors group">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                        <UserIcon className="w-5 h-5 text-gray-400" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-gray-900">{user.name}</p>
                        <p className="text-xs text-gray-500">{user.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <p className="text-sm font-bold text-teal-600">₹{user.walletBalance || 0}</p>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Balance</p>
                      </div>
                      <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                          onClick={() => setShowActionModal({ isOpen: true, type: 'credit', user })}
                          className="p-2 bg-teal-50 text-teal-600 rounded-lg hover:bg-teal-100 transition-colors"
                          title="Add Points"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => setShowActionModal({ isOpen: true, type: 'debit', user })}
                          className="p-2 bg-orange-50 text-orange-600 rounded-lg hover:bg-orange-100 transition-colors"
                          title="Deduct Points"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Transactions */}
            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                <h2 className="text-sm font-bold text-gray-900">Wallet History</h2>
                <button className="text-xs font-bold text-teal-600 hover:text-teal-700">View All</button>
              </div>
              <div className="divide-y divide-gray-100 max-h-[600px] overflow-y-auto custom-scrollbar">
                {transactions.map(transaction => (
                  <div key={transaction.id} className="p-4 flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        transaction.type === 'credit' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'
                      }`}>
                        {transaction.type === 'credit' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-gray-900">{transaction.reason}</p>
                        <p className="text-[10px] text-gray-500">
                          {new Date(transaction.createdAt).toLocaleString()} • User ID: {transaction.userId}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-bold ${
                        transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {transaction.type === 'credit' ? '+' : ''}{transaction.amount}
                      </p>
                      {transaction.orderId && (
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Order #{transaction.orderId}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Action Modal */}
      <AnimatePresence>
        {showActionModal.isOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowActionModal({ isOpen: false, type: 'credit', user: null })}
              className="absolute inset-0 bg-black/20 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden"
            >
              <div className={`p-6 border-b border-gray-100 flex items-center justify-between ${
                showActionModal.type === 'credit' ? 'bg-teal-50' : 'bg-orange-50'
              }`}>
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    showActionModal.type === 'credit' ? 'bg-teal-600 text-white' : 'bg-orange-600 text-white'
                  }`}>
                    {showActionModal.type === 'credit' ? <Plus className="w-6 h-6" /> : <Minus className="w-6 h-6" />}
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">
                      {showActionModal.type === 'credit' ? 'Add Points' : 'Deduct Points'}
                    </h3>
                    <p className="text-xs text-gray-500">For {showActionModal.user?.name}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowActionModal({ isOpen: false, type: 'credit', user: null })}
                  className="p-2 hover:bg-white/50 rounded-full transition-colors"
                >
                  <X className="w-5 h-5 text-gray-400" />
                </button>
              </div>

              <div className="p-6 space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Points Amount (₹)</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold">₹</span>
                    <input 
                      type="number" 
                      value={actionAmount}
                      onChange={(e) => setActionAmount(e.target.value)}
                      placeholder="0.00"
                      className="w-full pl-8 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-lg font-bold focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Reason</label>
                  <select 
                    value={actionReason}
                    onChange={(e) => setActionReason(e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 appearance-none"
                  >
                    <option value="">Select a reason</option>
                    {showActionModal.type === 'credit' ? (
                      <>
                        <option value="Manual Bonus">Manual Bonus</option>
                        <option value="Refund">Refund</option>
                        <option value="Reward">Reward</option>
                        <option value="Loyalty Points">Loyalty Points</option>
                      </>
                    ) : (
                      <>
                        <option value="Manual Deduction">Manual Deduction</option>
                        <option value="Order Correction">Order Correction</option>
                        <option value="Expired Points">Expired Points</option>
                      </>
                    )}
                  </select>
                </div>

                <div className="p-4 bg-gray-50 rounded-xl space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-500">Current Balance</span>
                    <span className="font-bold text-gray-900">₹{showActionModal.user?.walletBalance || 0}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-500">Adjustment</span>
                    <span className={`font-bold ${showActionModal.type === 'credit' ? 'text-green-600' : 'text-red-600'}`}>
                      {showActionModal.type === 'credit' ? '+' : '-'}{actionAmount || '0'}
                    </span>
                  </div>
                  <div className="h-px bg-gray-200 my-2" />
                  <div className="flex justify-between text-sm">
                    <span className="font-bold text-gray-900">New Balance</span>
                    <span className="font-bold text-teal-600">
                      ₹{Math.max(0, (showActionModal.user?.walletBalance || 0) + (showActionModal.type === 'credit' ? parseFloat(actionAmount || '0') : -parseFloat(actionAmount || '0')))}
                    </span>
                  </div>
                </div>

                <button 
                  onClick={handleWalletAction}
                  className={`w-full py-4 rounded-xl text-white font-bold shadow-lg transition-all ${
                    showActionModal.type === 'credit' 
                      ? 'bg-teal-600 hover:bg-teal-700 shadow-teal-100' 
                      : 'bg-orange-600 hover:bg-orange-700 shadow-orange-100'
                  }`}
                >
                  Confirm {showActionModal.type === 'credit' ? 'Credit' : 'Debit'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function X({ className }: { className?: string }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
    </svg>
  );
}
