import React, { useState, useEffect } from 'react';
import { Home, Save, Plus, Trash2, MoveUp, MoveDown, Image as ImageIcon, Video, Link as LinkIcon, Eye, EyeOff } from 'lucide-react';
import AdminSidebar from '../../components/AdminSidebar';
import { HomepageSettings } from '../../types';
import toast from 'react-hot-toast';
import { apiFetch } from '../../utils/api';

export default function AdminHomepageControl() {
  const [settings, setSettings] = useState<HomepageSettings>({
    announcementBar: {
      enabled: true,
      text: 'Free shipping on orders over ₹999!',
      backgroundColor: '#0D9488',
      textColor: '#FFFFFF',
      link: ''
    },
    banners: []
  });

  useEffect(() => {
    apiFetch('/api/admin/settings')
      .then(res => res.json())
      .then(data => {
        if (data && data.homepage_settings) {
          setSettings(JSON.parse(data.homepage_settings));
        }
      });
  }, []);

  const handleSave = async () => {
    try {
      const res = await apiFetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ homepage_settings: JSON.stringify(settings) })
      });
      if (res.ok) {
        toast.success('Homepage settings saved successfully');
      } else {
        toast.error('Failed to save settings');
      }
    } catch (err) {
      toast.error('Something went wrong');
    }
  };

  const addBanner = (type: 'image' | 'video') => {
    const newBanner = {
      id: Date.now().toString(),
      type,
      url: '',
      link: '',
      order: settings.banners.length,
      isVisible: true
    };
    setSettings({
      ...settings,
      banners: [...settings.banners, newBanner]
    });
  };

  const removeBanner = (id: string) => {
    setSettings({
      ...settings,
      banners: settings.banners.filter(b => b.id !== id)
    });
  };

  const updateBanner = (id: string, updates: any) => {
    setSettings({
      ...settings,
      banners: settings.banners.map(b => b.id === id ? { ...b, ...updates } : b)
    });
  };

  const moveBanner = (index: number, direction: 'up' | 'down') => {
    const newBanners = [...settings.banners];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= newBanners.length) return;
    
    [newBanners[index], newBanners[targetIndex]] = [newBanners[targetIndex], newBanners[index]];
    setSettings({ ...settings, banners: newBanners });
  };

  return (
    <div className="flex min-h-screen bg-[#F5F7F9]">
      <AdminSidebar />
      <div className="flex-1 ml-64">
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 sticky top-0 z-40">
          <div className="flex items-center space-x-3">
            <Home className="w-6 h-6 text-teal-600" />
            <h1 className="text-lg font-bold text-gray-900">Homepage Control</h1>
          </div>
          <button 
            onClick={handleSave}
            className="flex items-center space-x-2 px-4 py-2 bg-teal-600 text-white rounded-lg text-sm font-bold hover:bg-teal-700 transition-all shadow-lg shadow-teal-100"
          >
            <Save className="w-4 h-4" />
            <span>Save Changes</span>
          </button>
        </header>

        <main className="p-8 max-w-5xl mx-auto space-y-8">
          {/* Announcement Bar Section */}
          <section className="bg-white rounded-3xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-teal-100 rounded-lg">
                  <Home className="w-5 h-5 text-teal-600" />
                </div>
                <h2 className="text-md font-bold text-gray-900">Announcement Bar</h2>
              </div>
              <button 
                onClick={() => setSettings({
                  ...settings,
                  announcementBar: { ...settings.announcementBar, enabled: !settings.announcementBar.enabled }
                })}
                className={`w-12 h-6 rounded-full transition-all relative ${settings.announcementBar.enabled ? 'bg-teal-600' : 'bg-gray-300'}`}
              >
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${settings.announcementBar.enabled ? 'right-1' : 'left-1'}`} />
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Announcement Text</label>
                <input 
                  type="text" 
                  value={settings.announcementBar.text}
                  onChange={(e) => setSettings({
                    ...settings,
                    announcementBar: { ...settings.announcementBar, text: e.target.value }
                  })}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  placeholder="Enter announcement text..."
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Background Color</label>
                  <div className="flex items-center space-x-2">
                    <input 
                      type="color" 
                      value={settings.announcementBar.backgroundColor}
                      onChange={(e) => setSettings({
                        ...settings,
                        announcementBar: { ...settings.announcementBar, backgroundColor: e.target.value }
                      })}
                      className="w-10 h-10 rounded-lg cursor-pointer border-none"
                    />
                    <input 
                      type="text" 
                      value={settings.announcementBar.backgroundColor}
                      onChange={(e) => setSettings({
                        ...settings,
                        announcementBar: { ...settings.announcementBar, backgroundColor: e.target.value }
                      })}
                      className="flex-1 px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm uppercase"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Text Color</label>
                  <div className="flex items-center space-x-2">
                    <input 
                      type="color" 
                      value={settings.announcementBar.textColor}
                      onChange={(e) => setSettings({
                        ...settings,
                        announcementBar: { ...settings.announcementBar, textColor: e.target.value }
                      })}
                      className="w-10 h-10 rounded-lg cursor-pointer border-none"
                    />
                    <input 
                      type="text" 
                      value={settings.announcementBar.textColor}
                      onChange={(e) => setSettings({
                        ...settings,
                        announcementBar: { ...settings.announcementBar, textColor: e.target.value }
                      })}
                      className="flex-1 px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm uppercase"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Link (Optional)</label>
                  <input 
                    type="text" 
                    value={settings.announcementBar.link}
                    onChange={(e) => setSettings({
                      ...settings,
                      announcementBar: { ...settings.announcementBar, link: e.target.value }
                    })}
                    className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm"
                    placeholder="/products or https://..."
                  />
                </div>
              </div>

              {/* Preview */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Preview</label>
                <div 
                  className="w-full py-2 px-4 text-center text-sm font-medium rounded-lg"
                  style={{ 
                    backgroundColor: settings.announcementBar.backgroundColor,
                    color: settings.announcementBar.textColor
                  }}
                >
                  {settings.announcementBar.text || 'Announcement Preview'}
                </div>
              </div>
            </div>
          </section>

          {/* Banners Section */}
          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-teal-100 rounded-lg">
                  <ImageIcon className="w-5 h-5 text-teal-600" />
                </div>
                <h2 className="text-md font-bold text-gray-900">Hero Banners & Media</h2>
              </div>
              <div className="flex items-center space-x-2">
                <button 
                  onClick={() => addBanner('image')}
                  className="flex items-center space-x-2 px-3 py-2 bg-white border border-gray-200 rounded-lg text-xs font-bold text-gray-600 hover:bg-gray-50"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Image</span>
                </button>
                <button 
                  onClick={() => addBanner('video')}
                  className="flex items-center space-x-2 px-3 py-2 bg-white border border-gray-200 rounded-lg text-xs font-bold text-gray-600 hover:bg-gray-50"
                >
                  <Video className="w-4 h-4" />
                  <span>Add Video</span>
                </button>
              </div>
            </div>

            <div className="space-y-4">
              {settings.banners.map((banner, index) => (
                <div key={banner.id} className="bg-white rounded-3xl border border-gray-200 shadow-sm p-6 flex items-start space-x-6 group">
                  <div className="flex flex-col space-y-2">
                    <button 
                      onClick={() => moveBanner(index, 'up')}
                      disabled={index === 0}
                      className="p-1 text-gray-400 hover:text-teal-600 disabled:opacity-30"
                    >
                      <MoveUp className="w-4 h-4" />
                    </button>
                    <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center text-xs font-bold text-gray-500">
                      {index + 1}
                    </div>
                    <button 
                      onClick={() => moveBanner(index, 'down')}
                      disabled={index === settings.banners.length - 1}
                      className="p-1 text-gray-400 hover:text-teal-600 disabled:opacity-30"
                    >
                      <MoveDown className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                          {banner.type === 'image' ? 'Image URL' : 'Video URL'}
                        </label>
                        <div className="relative">
                          {banner.type === 'image' ? <ImageIcon className="absolute left-3 top-3 w-4 h-4 text-gray-400" /> : <Video className="absolute left-3 top-3 w-4 h-4 text-gray-400" />}
                          <input 
                            type="text" 
                            value={banner.url}
                            onChange={(e) => updateBanner(banner.id, { url: e.target.value })}
                            className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm"
                            placeholder="https://..."
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Redirect Link</label>
                        <div className="relative">
                          <LinkIcon className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                          <input 
                            type="text" 
                            value={banner.link}
                            onChange={(e) => updateBanner(banner.id, { link: e.target.value })}
                            className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm"
                            placeholder="/products/category-name"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="aspect-video bg-gray-100 rounded-2xl overflow-hidden border border-gray-200 flex items-center justify-center relative">
                        {banner.url ? (
                          banner.type === 'image' ? (
                            <img src={banner.url} alt="Banner Preview" className="w-full h-full object-cover" />
                          ) : (
                            <div className="flex flex-col items-center text-gray-400">
                              <Video className="w-8 h-8 mb-2" />
                              <span className="text-[10px] font-bold uppercase">Video Preview</span>
                            </div>
                          )
                        ) : (
                          <div className="flex flex-col items-center text-gray-400">
                            <ImageIcon className="w-8 h-8 mb-2" />
                            <span className="text-[10px] font-bold uppercase">No Media URL</span>
                          </div>
                        )}
                        <div className="absolute top-2 right-2 flex space-x-2">
                          <button 
                            onClick={() => updateBanner(banner.id, { isVisible: !banner.isVisible })}
                            className={`p-2 rounded-lg ${banner.isVisible ? 'bg-white text-teal-600' : 'bg-gray-900 text-white'} shadow-sm`}
                          >
                            {banner.isVisible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                          </button>
                          <button 
                            onClick={() => removeBanner(banner.id)}
                            className="p-2 bg-white text-red-500 rounded-lg shadow-sm hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {settings.banners.length === 0 && (
                <div className="bg-white rounded-3xl border-2 border-dashed border-gray-200 p-12 text-center space-y-4">
                  <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto">
                    <ImageIcon className="w-8 h-8 text-gray-300" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-gray-900 font-bold">No banners added yet</p>
                    <p className="text-gray-500 text-sm">Add images or videos to showcase on your homepage hero section.</p>
                  </div>
                </div>
              )}
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
