import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Filter, 
  ChevronDown, 
  MoreVertical, 
  Eye, 
  CheckCircle, 
  XCircle, 
  Truck, 
  Package, 
  User, 
  MapPin, 
  CreditCard,
  ArrowRight
} from 'lucide-react';
import AdminSidebar from '../../components/AdminSidebar';
import { Order } from '../../types';
import toast from 'react-hot-toast';
import { apiFetch } from '../../utils/api';

const TABS = [
  { id: 'all', label: 'All Orders' },
  { id: 'pending', label: 'Pending' },
  { id: 'accepted', label: 'Accepted' },
  { id: 'shipped', label: 'Shipped' },
  { id: 'pickup_ready', label: 'Pickup Ready' },
  { id: 'fulfilled', label: 'Fulfilled' },
  { id: 'cancelled', label: 'Cancelled' },
  { id: 'rejected', label: 'Rejected' },
];

export default function AdminOrders() {
  const [activeTab, setActiveTab] = useState('all');
  const [orders, setOrders] = useState<Order[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      console.log('Fetching orders...');
      const res = await apiFetch('/api/get-orders');
      if (!res.ok) {
        const errorData = await res.json();
        console.error('Failed to fetch orders:', errorData);
        toast.error(`Failed to fetch orders: ${errorData.error || 'Unknown error'}`);
        setLoading(false);
        return;
      }
      const data = await res.json();
      console.log('Orders data received:', data);
      if (Array.isArray(data)) {
        setOrders(data);
      } else {
        console.warn('Received non-array data for orders:', data);
      }
    } catch (error) {
      console.error('Error fetching orders:', error);
      toast.error('Failed to fetch orders');
    } finally {
      setLoading(false);
    }
  };

  const updateOrderStatus = async (orderId: number, newStatus: string) => {
    try {
      const res = await apiFetch(`/api/admin/orders/${orderId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ delivery_status: newStatus }),
      });
      if (res.ok) {
        toast.success(`Order marked as ${newStatus.replace('_', ' ')}`);
        fetchOrders();
        if (selectedOrder?.id === orderId) {
          setSelectedOrder(prev => prev ? { ...prev, delivery_status: newStatus as any } : null);
        }
      }
    } catch (error) {
      toast.error('Failed to update order status');
    }
  };

  const filteredOrders = orders.filter(order => {
    const matchesTab = activeTab === 'all' || order.delivery_status === activeTab;
    const userName = order.user_name || 'Unknown User';
    const matchesSearch = order.id.toString().includes(searchQuery) || 
                         userName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTab && matchesSearch;
  });

  const getStatusStyles = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-50 text-yellow-600 border-yellow-100';
      case 'accepted': return 'bg-blue-50 text-blue-600 border-blue-100';
      case 'shipped': return 'bg-indigo-50 text-indigo-600 border-indigo-100';
      case 'pickup_ready': return 'bg-purple-50 text-purple-600 border-purple-100';
      case 'fulfilled': return 'bg-green-50 text-green-600 border-green-100';
      case 'cancelled': return 'bg-red-50 text-red-600 border-red-100';
      case 'rejected': return 'bg-gray-50 text-gray-600 border-gray-100';
      default: return 'bg-gray-50 text-gray-600 border-gray-100';
    }
  };

  return (
    <div className="flex min-h-screen bg-[#F5F7F9]">
      <AdminSidebar />
      
      <div className="flex-1 ml-64">
        {/* Topbar */}
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 sticky top-0 z-40">
          <h1 className="text-lg font-bold text-gray-900">Orders Management</h1>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input 
                type="text" 
                placeholder="Search by Order ID or Name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 w-64 transition-all"
              />
            </div>
            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <Filter className="w-5 h-5 text-gray-500" />
            </button>
          </div>
        </header>

        <main className="p-8 space-y-6">
          {/* Tabs */}
          <div className="flex items-center space-x-1 bg-white p-1 rounded-xl border border-gray-200 w-fit">
            {TABS.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${
                  activeTab === tab.id 
                    ? 'bg-teal-600 text-white shadow-sm' 
                    : 'text-gray-500 hover:bg-gray-50'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Orders Table */}
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Order ID</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Product</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Payment</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Customer</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Address</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Shipping</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50/50 transition-colors group">
                    <td className="px-6 py-4">
                      <span className="text-sm font-bold text-teal-600">#ORD-{order.id.toString().padStart(6, '0')}</span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-lg bg-gray-100 overflow-hidden flex-shrink-0">
                          <img 
                            src={order.items?.[0]?.product_image || 'https://picsum.photos/seed/product/100/100'} 
                            alt="" 
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-bold text-gray-900 truncate max-w-[150px]">{order.items?.[0]?.product_name}</p>
                          {order.items?.length > 1 && (
                            <p className="text-[10px] text-gray-500">+{order.items.length - 1} more items</p>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col">
                        <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded w-fit mb-1 ${
                          order.payment_method === 'upi' || order.payment_method === 'Prepaid' 
                            ? 'bg-green-50 text-green-600' 
                            : order.payment_method === 'partial_advance'
                            ? 'bg-blue-50 text-blue-600'
                            : 'bg-orange-50 text-orange-600'
                        }`}>
                          {order.payment_method.replace(/_/g, ' ')}
                        </span>
                        <span className="text-xs font-bold text-gray-900">₹{order.total_amount.toLocaleString()}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col">
                        <p className="text-sm font-bold text-gray-900">{order.user_name || 'Unknown User'}</p>
                        <p className="text-xs text-gray-500">{order.user_phone || 'N/A'}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-xs text-gray-500 truncate max-w-[150px]">{order.address}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-xs font-medium text-gray-600 bg-gray-100 px-2 py-1 rounded-lg">
                        {order.shipping_type}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <button 
                          onClick={() => setSelectedOrder(order)}
                          className="p-2 hover:bg-teal-50 text-gray-400 hover:text-teal-600 rounded-lg transition-all"
                          title="View Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <div className="relative group/menu">
                          <button className="p-2 hover:bg-gray-100 text-gray-400 rounded-lg transition-all">
                            <MoreVertical className="w-4 h-4" />
                          </button>
                          <div className="absolute right-0 top-full mt-1 w-48 bg-white border border-gray-200 rounded-xl shadow-xl opacity-0 invisible group-hover/menu:opacity-100 group-hover/menu:visible transition-all z-50 py-1">
                            {order.delivery_status === 'pending' && (
                              <>
                                <button 
                                  onClick={() => updateOrderStatus(order.id, 'accepted')}
                                  className="w-full px-4 py-2 text-left text-xs font-bold text-blue-600 hover:bg-blue-50 flex items-center space-x-2"
                                >
                                  <CheckCircle className="w-3 h-3" />
                                  <span>Accept Order</span>
                                </button>
                                <button 
                                  onClick={() => updateOrderStatus(order.id, 'rejected')}
                                  className="w-full px-4 py-2 text-left text-xs font-bold text-red-600 hover:bg-red-50 flex items-center space-x-2"
                                >
                                  <XCircle className="w-3 h-3" />
                                  <span>Reject Order</span>
                                </button>
                              </>
                            )}
                            {order.delivery_status === 'accepted' && (
                              <button 
                                onClick={() => updateOrderStatus(order.id, 'shipped')}
                                className="w-full px-4 py-2 text-left text-xs font-bold text-indigo-600 hover:bg-indigo-50 flex items-center space-x-2"
                              >
                                <Truck className="w-3 h-3" />
                                <span>Mark as Shipped</span>
                              </button>
                            )}
                            {order.delivery_status === 'shipped' && (
                              <button 
                                onClick={() => updateOrderStatus(order.id, 'fulfilled')}
                                className="w-full px-4 py-2 text-left text-xs font-bold text-green-600 hover:bg-green-50 flex items-center space-x-2"
                              >
                                <Package className="w-3 h-3" />
                                <span>Mark as Delivered</span>
                              </button>
                            )}
                            <div className="h-px bg-gray-100 my-1"></div>
                            <button 
                              onClick={() => updateOrderStatus(order.id, 'cancelled')}
                              className="w-full px-4 py-2 text-left text-xs font-bold text-gray-500 hover:bg-gray-50 flex items-center space-x-2"
                            >
                              <XCircle className="w-3 h-3" />
                              <span>Cancel Order</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            
            {filteredOrders.length === 0 && (
              <div className="p-12 text-center">
                <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Package className="w-8 h-8 text-gray-300" />
                </div>
                <p className="text-gray-500 font-medium">No orders found matching your criteria</p>
              </div>
            )}
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between bg-white px-6 py-4 rounded-2xl border border-gray-200 shadow-sm">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-wider">
              Showing <span className="text-gray-900">{filteredOrders.length}</span> of <span className="text-gray-900">{orders.length}</span> orders
            </p>
            <div className="flex items-center space-x-2">
              <button className="px-4 py-2 text-xs font-bold text-gray-400 bg-gray-50 border border-gray-100 rounded-lg cursor-not-allowed">Previous</button>
              <button className="px-4 py-2 text-xs font-bold text-teal-600 bg-teal-50 border border-teal-100 rounded-lg hover:bg-teal-100 transition-colors">Next</button>
            </div>
          </div>
        </main>

        {/* Order Details Sidebar */}
        <AnimatePresence>
          {selectedOrder && (
            <>
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setSelectedOrder(null)}
                className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[100]"
              />
              <motion.div 
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                className="fixed top-0 right-0 h-screen w-[450px] bg-white shadow-2xl z-[101] overflow-y-auto"
              >
                <div className="p-6 border-b border-gray-100 flex items-center justify-between sticky top-0 bg-white z-10">
                  <div>
                    <h2 className="text-lg font-bold text-gray-900">Order Details</h2>
                    <p className="text-xs text-teal-600 font-bold">#ORD-{selectedOrder.id.toString().padStart(6, '0')}</p>
                  </div>
                  <button 
                    onClick={() => setSelectedOrder(null)}
                    className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                  >
                    <ArrowRight className="w-5 h-5 text-gray-500" />
                  </button>
                </div>

                <div className="p-6 space-y-8">
                  {/* Status Banner */}
                  <div className={`p-4 rounded-xl border flex items-center justify-between ${getStatusStyles(selectedOrder.delivery_status)}`}>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5" />
                      <span className="text-sm font-bold uppercase tracking-wide">
                        {selectedOrder.delivery_status.replace('_', ' ')}
                      </span>
                    </div>
                    <span className="text-[10px] font-bold opacity-70">{new Date(selectedOrder.created_at).toLocaleString()}</span>
                  </div>

                  {/* Customer Info */}
                  <div className="space-y-4">
                    <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Customer Information</h3>
                    <div className="bg-gray-50 rounded-xl p-4 space-y-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center border border-gray-200">
                          <User className="w-4 h-4 text-gray-500" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-gray-900">{selectedOrder.user_name || 'Unknown User'}</p>
                          <p className="text-xs text-gray-500">{selectedOrder.user_phone || 'No phone provided'}</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center border border-gray-200 mt-0.5">
                          <MapPin className="w-4 h-4 text-gray-500" />
                        </div>
                        <p className="text-xs text-gray-600 leading-relaxed">{selectedOrder.address}</p>
                      </div>
                    </div>
                  </div>

                  {/* Items */}
                  <div className="space-y-4">
                    <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Order Items</h3>
                    <div className="space-y-3">
                      {selectedOrder.items.map((item, idx) => (
                        <div key={idx} className="flex items-center space-x-4 p-3 border border-gray-100 rounded-xl">
                          <div className="w-12 h-12 rounded-lg bg-gray-50 overflow-hidden flex-shrink-0">
                            <img src={item.product_image} alt="" className="w-full h-full object-cover" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-bold text-gray-900 truncate">{item.product_name}</p>
                            <p className="text-xs text-gray-500">Qty: {item.quantity} × ₹{item.price}</p>
                          </div>
                          <p className="text-sm font-bold text-gray-900">₹{item.quantity * item.price}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Payment Summary */}
                  <div className="space-y-4">
                    <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Payment Summary</h3>
                    <div className="bg-gray-50 rounded-xl p-4 space-y-3">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-500">Subtotal</span>
                        <span className="font-bold text-gray-900">₹{selectedOrder.total_amount + (selectedOrder.discount_amount || 0) - (selectedOrder.tax_amount || 0) - (selectedOrder.shipping_fee || 0)}</span>
                      </div>
                      {selectedOrder.discount_amount > 0 && (
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-500">Discount</span>
                          <span className="text-green-600 font-bold">-₹{selectedOrder.discount_amount}</span>
                        </div>
                      )}
                      {selectedOrder.tax_amount > 0 && (
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-500">Tax</span>
                          <span className="font-bold text-gray-900">+₹{selectedOrder.tax_amount}</span>
                        </div>
                      )}
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-500">Shipping</span>
                        <span className={selectedOrder.shipping_fee === 0 ? "text-green-600 font-bold" : "font-bold text-gray-900"}>
                          {selectedOrder.shipping_fee === 0 ? 'FREE' : `+₹${selectedOrder.shipping_fee}`}
                        </span>
                      </div>
                      {selectedOrder.wallet_amount > 0 && (
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-500">Wallet Used</span>
                          <span className="text-orange-600 font-bold">-₹{selectedOrder.wallet_amount}</span>
                        </div>
                      )}
                      <div className="h-px bg-gray-200 my-1"></div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold text-gray-900">Final Total</span>
                        <span className="text-lg font-black text-teal-600">₹{selectedOrder.total_amount - (selectedOrder.wallet_amount || 0)}</span>
                      </div>
                      {selectedOrder.advance_paid > 0 && (
                        <div className="flex items-center justify-between text-xs pt-1 border-t border-gray-100">
                          <span className="text-gray-500 italic">Advance Paid</span>
                          <span className="font-bold text-teal-600">₹{selectedOrder.advance_paid}</span>
                        </div>
                      )}
                      <div className="flex items-center space-x-2 pt-2">
                        <CreditCard className="w-4 h-4 text-gray-400" />
                        <span className="text-xs font-bold text-gray-600 uppercase tracking-wide">
                          {selectedOrder.payment_method} - {selectedOrder.payment_status}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Quick Actions */}
                  <div className="pt-4 grid grid-cols-2 gap-3">
                    {selectedOrder.delivery_status === 'pending' && (
                      <>
                        <button 
                          onClick={() => updateOrderStatus(selectedOrder.id, 'accepted')}
                          className="py-3 bg-teal-600 text-white text-sm font-bold rounded-xl hover:bg-teal-700 transition-all shadow-lg shadow-teal-100"
                        >
                          Accept Order
                        </button>
                        <button 
                          onClick={() => updateOrderStatus(selectedOrder.id, 'rejected')}
                          className="py-3 bg-white border border-red-200 text-red-600 text-sm font-bold rounded-xl hover:bg-red-50 transition-all"
                        >
                          Reject
                        </button>
                      </>
                    )}
                    {selectedOrder.delivery_status === 'accepted' && (
                      <button 
                        onClick={() => updateOrderStatus(selectedOrder.id, 'shipped')}
                        className="col-span-2 py-3 bg-indigo-600 text-white text-sm font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
                      >
                        Mark as Shipped
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
