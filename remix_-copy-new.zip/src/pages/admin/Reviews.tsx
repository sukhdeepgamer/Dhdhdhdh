import React, { useState, useEffect } from 'react';
import { 
  Star, 
  Search, 
  Filter, 
  CheckCircle, 
  XCircle, 
  Trash2, 
  MessageSquare, 
  AlertTriangle, 
  MoreVertical,
  ChevronDown
} from 'lucide-react';
import AdminSidebar from '../../components/AdminSidebar';
import { Review } from '../../types';
import toast from 'react-hot-toast';
import { apiFetch } from '../../utils/api';

const TABS = [
  { id: 'all', label: 'All Reviews' },
  { id: 'pending', label: 'Pending Approval' },
  { id: 'approved', label: 'Approved' },
  { id: 'rejected', label: 'Rejected' },
  { id: 'reported', label: 'Reported' },
];

const MOCK_REVIEWS: Review[] = [
  {
    id: 1,
    product_id: 101,
    product_name: 'iPhone 15 Pro',
    product_image: 'https://picsum.photos/seed/iphone/100/100',
    user_name: 'Rahul Sharma',
    rating: 5,
    comment: 'Amazing phone! The camera is incredible and the battery life is much better than my previous model.',
    status: 'approved',
    created_at: '2024-03-15T10:30:00Z'
  },
  {
    id: 2,
    product_id: 102,
    product_name: 'MacBook Air M2',
    product_image: 'https://picsum.photos/seed/macbook/100/100',
    user_name: 'Priya Patel',
    rating: 4,
    comment: 'Great laptop, very light. But the midnight color attracts a lot of fingerprints.',
    status: 'pending',
    created_at: '2024-03-16T14:20:00Z'
  },
  {
    id: 3,
    product_id: 103,
    product_name: 'Sony WH-1000XM5',
    product_image: 'https://picsum.photos/seed/sony/100/100',
    user_name: 'Amit Kumar',
    rating: 2,
    comment: 'The noise cancellation is good but the build quality feels cheap compared to XM4. Disappointed.',
    status: 'reported',
    created_at: '2024-03-17T09:15:00Z'
  },
  {
    id: 4,
    product_id: 104,
    product_name: 'Samsung Galaxy Watch 6',
    product_image: 'https://picsum.photos/seed/watch/100/100',
    user_name: 'Sneha Reddy',
    rating: 5,
    comment: 'Perfect companion for my S23. The display is bright and clear.',
    status: 'pending',
    created_at: '2024-03-18T11:45:00Z'
  }
];

export default function AdminReviews() {
  const [activeTab, setActiveTab] = useState('all');
  const [reviews, setReviews] = useState<Review[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [selectedRating, setSelectedRating] = useState<number | 'all'>('all');

  useEffect(() => {
    fetchReviews();
  }, []);

  const fetchReviews = async () => {
    setLoading(true);
    try {
      const res = await apiFetch('/api/admin/reviews');
      const data = await res.json();
      setReviews(data || []);
    } catch (error) {
      console.error('Failed to fetch reviews:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateReviewStatus = async (id: number, newStatus: Review['status']) => {
    try {
      const res = await apiFetch(`/api/admin/reviews/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        toast.success(`Review ${newStatus}`);
        fetchReviews();
      }
    } catch (error) {
      toast.error('Failed to update review');
    }
  };

  const deleteReview = async (id: number) => {
    try {
      const res = await apiFetch(`/api/admin/reviews/${id}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        toast.success('Review deleted');
        fetchReviews();
      }
    } catch (error) {
      toast.error('Failed to delete review');
    }
  };

  const filteredReviews = reviews.filter(review => {
    const matchesTab = activeTab === 'all' || review.status === activeTab;
    const matchesSearch = review.product_name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         review.user_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         review.comment.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRating = selectedRating === 'all' || review.rating === selectedRating;
    return matchesTab && matchesSearch && matchesRating;
  });

  const getStatusStyles = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-50 text-green-600 border-green-100';
      case 'pending': return 'bg-yellow-50 text-yellow-600 border-yellow-100';
      case 'rejected': return 'bg-red-50 text-red-600 border-red-100';
      case 'reported': return 'bg-orange-50 text-orange-600 border-orange-100';
      case 'spam': return 'bg-gray-50 text-gray-600 border-gray-100';
      default: return 'bg-gray-50 text-gray-600 border-gray-100';
    }
  };

  return (
    <div className="flex min-h-screen bg-[#F5F7F9]">
      <AdminSidebar />
      
      <div className="flex-1 ml-64">
        {/* Topbar */}
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 sticky top-0 z-40">
          <h1 className="text-lg font-bold text-gray-900">Review Management</h1>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input 
                type="text" 
                placeholder="Search reviews, products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 w-64 transition-all"
              />
            </div>
            <div className="relative group">
              <button className="flex items-center space-x-2 px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-xs font-bold text-gray-600 hover:bg-gray-100 transition-colors">
                <Star className="w-4 h-4" />
                <span>Rating: {selectedRating === 'all' ? 'All' : `${selectedRating} Stars`}</span>
                <ChevronDown className="w-3 h-3" />
              </button>
              <div className="absolute right-0 top-full mt-1 w-40 bg-white border border-gray-200 rounded-xl shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50 py-1">
                <button onClick={() => setSelectedRating('all')} className="w-full px-4 py-2 text-left text-xs font-bold text-gray-600 hover:bg-gray-50">All Ratings</button>
                {[5, 4, 3, 2, 1].map(num => (
                  <button 
                    key={num} 
                    onClick={() => setSelectedRating(num)}
                    className="w-full px-4 py-2 text-left text-xs font-bold text-gray-600 hover:bg-gray-50 flex items-center space-x-2"
                  >
                    <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                    <span>{num} Stars</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </header>

        <main className="p-8 space-y-6">
          {/* Tabs */}
          <div className="flex items-center space-x-1 bg-white p-1 rounded-xl border border-gray-200 w-fit">
            {TABS.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${
                  activeTab === tab.id 
                    ? 'bg-teal-600 text-white shadow-sm' 
                    : 'text-gray-500 hover:bg-gray-50'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Reviews Table */}
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  <th className="px-6 py-4 w-10">
                    <input type="checkbox" className="rounded border-gray-300 text-teal-600 focus:ring-teal-500" />
                  </th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Product</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Customer</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Rating</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Review</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredReviews.map((review) => (
                  <tr key={review.id} className="hover:bg-gray-50/50 transition-colors group">
                    <td className="px-6 py-4">
                      <input type="checkbox" className="rounded border-gray-300 text-teal-600 focus:ring-teal-500" />
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-lg bg-gray-100 overflow-hidden flex-shrink-0">
                          <img src={review.product_image} alt="" className="w-full h-full object-cover" />
                        </div>
                        <p className="text-sm font-bold text-gray-900 truncate max-w-[120px]">{review.product_name}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-sm font-bold text-gray-900">{review.user_name}</p>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-0.5">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`w-3 h-3 ${i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-200'}`} 
                          />
                        ))}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-xs text-gray-600 line-clamp-2 max-w-[250px] leading-relaxed">
                        {review.comment}
                      </p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                        {new Date(review.created_at).toLocaleDateString()}
                      </p>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded-lg text-[10px] font-bold uppercase border ${getStatusStyles(review.status)}`}>
                        {review.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        {review.status === 'pending' && (
                          <>
                            <button 
                              onClick={() => updateReviewStatus(review.id, 'approved')}
                              className="p-2 hover:bg-green-50 text-gray-400 hover:text-green-600 rounded-lg transition-all"
                              title="Approve"
                            >
                              <CheckCircle className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={() => updateReviewStatus(review.id, 'rejected')}
                              className="p-2 hover:bg-red-50 text-gray-400 hover:text-red-600 rounded-lg transition-all"
                              title="Reject"
                            >
                              <XCircle className="w-4 h-4" />
                            </button>
                          </>
                        )}
                        <div className="relative group/menu">
                          <button className="p-2 hover:bg-gray-100 text-gray-400 rounded-lg transition-all">
                            <MoreVertical className="w-4 h-4" />
                          </button>
                          <div className="absolute right-0 top-full mt-1 w-40 bg-white border border-gray-200 rounded-xl shadow-xl opacity-0 invisible group-hover/menu:opacity-100 group-hover/menu:visible transition-all z-50 py-1">
                            <button className="w-full px-4 py-2 text-left text-xs font-bold text-gray-600 hover:bg-gray-50 flex items-center space-x-2">
                              <MessageSquare className="w-3 h-3" />
                              <span>Reply</span>
                            </button>
                            <button 
                              onClick={() => updateReviewStatus(review.id, 'spam')}
                              className="w-full px-4 py-2 text-left text-xs font-bold text-orange-600 hover:bg-orange-50 flex items-center space-x-2"
                            >
                              <AlertTriangle className="w-3 h-3" />
                              <span>Mark as Spam</span>
                            </button>
                            <div className="h-px bg-gray-100 my-1"></div>
                            <button 
                              onClick={() => deleteReview(review.id)}
                              className="w-full px-4 py-2 text-left text-xs font-bold text-red-600 hover:bg-red-50 flex items-center space-x-2"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>Delete</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            
            {filteredReviews.length === 0 && (
              <div className="p-12 text-center">
                <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Star className="w-8 h-8 text-gray-300" />
                </div>
                <p className="text-gray-500 font-medium">No reviews found matching your criteria</p>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
