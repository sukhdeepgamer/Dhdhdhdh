import React, { useState, useEffect } from 'react';
import { Truck, Save, Info, MapPin, Clock, IndianRupee } from 'lucide-react';
import AdminSidebar from '../../components/AdminSidebar';
import { DeliverySettings } from '../../types';
import toast from 'react-hot-toast';
import { apiFetch } from '../../utils/api';

export default function AdminDeliverySettings() {
  const [settings, setSettings] = useState<DeliverySettings>({
    flatFee: 40,
    freeDeliveryThreshold: 500,
    radiusType: 'all_india',
    minHandlingTime: 1,
    maxHandlingTime: 3
  });

  useEffect(() => {
    apiFetch('/api/admin/settings')
      .then(res => res.json())
      .then(data => {
        if (data && data.delivery_settings) {
          setSettings(JSON.parse(data.delivery_settings));
        }
      });
  }, []);

  const handleSave = async () => {
    try {
      const res = await apiFetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ delivery_settings: JSON.stringify(settings) })
      });
      if (res.ok) {
        toast.success('Delivery settings saved successfully');
      } else {
        toast.error('Failed to save settings');
      }
    } catch (err) {
      toast.error('Something went wrong');
    }
  };

  return (
    <div className="flex min-h-screen bg-[#F5F7F9]">
      <AdminSidebar />
      <div className="flex-1 ml-64">
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 sticky top-0 z-40">
          <div className="flex items-center space-x-3">
            <Truck className="w-6 h-6 text-teal-600" />
            <h1 className="text-lg font-bold text-gray-900">Delivery Settings</h1>
          </div>
          <button 
            onClick={handleSave}
            className="flex items-center space-x-2 px-4 py-2 bg-teal-600 text-white rounded-lg text-sm font-bold hover:bg-teal-700 transition-all shadow-lg shadow-teal-100"
          >
            <Save className="w-4 h-4" />
            <span>Save Settings</span>
          </button>
        </header>

        <main className="p-8 max-w-4xl mx-auto space-y-8">
          {/* Info Banner */}
          <div className="bg-blue-50 border border-blue-100 rounded-2xl p-6 flex items-start space-x-4">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Info className="w-5 h-5 text-blue-600" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-blue-900">Delivery Configuration</h3>
              <p className="text-xs text-blue-700 leading-relaxed">
                Configure how you charge for delivery and set expectations for your customers. 
                These settings will be automatically applied during the checkout process.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Fees Section */}
            <section className="bg-white p-8 rounded-3xl border border-gray-200 shadow-sm space-y-6">
              <div className="flex items-center space-x-3 mb-2">
                <div className="p-2 bg-teal-50 rounded-lg">
                  <IndianRupee className="w-5 h-5 text-teal-600" />
                </div>
                <h2 className="text-md font-bold text-gray-900">Delivery Fees</h2>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Flat Delivery Fee (₹)</label>
                  <input 
                    type="number" 
                    value={settings.flatFee}
                    onChange={(e) => setSettings({...settings, flatFee: Number(e.target.value)})}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Free Delivery Above (₹)</label>
                  <input 
                    type="number" 
                    value={settings.freeDeliveryThreshold}
                    onChange={(e) => setSettings({...settings, freeDeliveryThreshold: Number(e.target.value)})}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  />
                </div>
              </div>
            </section>

            {/* Radius Section */}
            <section className="bg-white p-8 rounded-3xl border border-gray-200 shadow-sm space-y-6">
              <div className="flex items-center space-x-3 mb-2">
                <div className="p-2 bg-blue-50 rounded-lg">
                  <MapPin className="w-5 h-5 text-blue-600" />
                </div>
                <h2 className="text-md font-bold text-gray-900">Delivery Radius</h2>
              </div>

              <div className="space-y-4">
                <div className="flex flex-col space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Service Area</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button 
                      onClick={() => setSettings({...settings, radiusType: 'local'})}
                      className={`py-3 rounded-xl text-xs font-bold border transition-all ${settings.radiusType === 'local' ? 'bg-teal-600 text-white border-teal-600' : 'bg-gray-50 text-gray-500 border-gray-200'}`}
                    >
                      Local Only
                    </button>
                    <button 
                      onClick={() => setSettings({...settings, radiusType: 'all_india'})}
                      className={`py-3 rounded-xl text-xs font-bold border transition-all ${settings.radiusType === 'all_india' ? 'bg-teal-600 text-white border-teal-600' : 'bg-gray-50 text-gray-500 border-gray-200'}`}
                    >
                      All India
                    </button>
                  </div>
                </div>
              </div>
            </section>

            {/* Handling Time Section */}
            <section className="bg-white p-8 rounded-3xl border border-gray-200 shadow-sm space-y-6 md:col-span-2">
              <div className="flex items-center space-x-3 mb-2">
                <div className="p-2 bg-orange-50 rounded-lg">
                  <Clock className="w-5 h-5 text-orange-600" />
                </div>
                <h2 className="text-md font-bold text-gray-900">Handling & Delivery Time</h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Min Handling Time (Days)</label>
                  <input 
                    type="number" 
                    value={settings.minHandlingTime}
                    onChange={(e) => setSettings({...settings, minHandlingTime: Number(e.target.value)})}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Max Handling Time (Days)</label>
                  <input 
                    type="number" 
                    value={settings.maxHandlingTime}
                    onChange={(e) => setSettings({...settings, maxHandlingTime: Number(e.target.value)})}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                  />
                </div>
              </div>
              <p className="text-[10px] text-gray-400 font-medium italic">
                * Estimated delivery shown to customers: {settings.minHandlingTime + 2}-{settings.maxHandlingTime + 4} business days.
              </p>
            </section>
          </div>
        </main>
      </div>
    </div>
  );
}
