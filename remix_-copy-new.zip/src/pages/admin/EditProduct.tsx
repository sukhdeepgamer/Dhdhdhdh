import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { 
  ArrowLeft, 
  Upload, 
  X, 
  Plus, 
  Info, 
  ChevronDown, 
  Check,
  Bold,
  Italic,
  List,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Trash2,
  TrendingUp,
  Package
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import AdminSidebar from '../../components/AdminSidebar';
import toast from 'react-hot-toast';
import { apiFetch } from '../../utils/api';

interface Variant {
  id: string;
  color: string;
  colorCode?: string;
  size: string;
  mrp: string;
  price: string;
  stock: string;
  sku: string;
  images: { file?: File; preview: string; url?: string }[];
}

export default function EditProduct() {
  const { id } = useParams();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const sizeChartRef = useRef<HTMLInputElement>(null);
  const variantImageRefs = useRef<{ [key: string]: HTMLInputElement | null }>({});

  // Form State
  const [images, setImages] = useState<{ file?: File; preview: string; url?: string }[]>([]);
  const [productName, setProductName] = useState('');
  const [description, setDescription] = useState('');
  const [mrp, setMrp] = useState('');
  const [sellingPrice, setSellingPrice] = useState('');
  const [businessCategory, setBusinessCategory] = useState('');
  const [productCategory, setProductCategory] = useState('');
  const [quantity, setQuantity] = useState('');
  const [sku, setSku] = useState('');
  const [pdpTemplate, setPdpTemplate] = useState('Default');
  const [hsnCode, setHsnCode] = useState('');
  const [isBestseller, setIsBestseller] = useState(false);
  const [color, setColor] = useState('');
  const [colorCode, setColorCode] = useState('#000000');
  const [size, setSize] = useState('');
  const [variants, setVariants] = useState<Variant[]>([]);
  const [sizeChart, setSizeChart] = useState<{ file?: File; name: string; url?: string } | null>(null);

  // Bulk Variant State
  const [bulkColors, setBulkColors] = useState('');
  const [bulkSizes, setBulkSizes] = useState('');

  // SEO State
  const [seoTitle, setSeoTitle] = useState('');
  const [seoDescription, setSeoDescription] = useState('');
  const [seoKeywords, setSeoKeywords] = useState('');
  const [seoSlug, setSeoSlug] = useState('');

  // UI State
  const [categories, setCategories] = useState<string[]>([]);
  const [businessCategories, setBusinessCategories] = useState<string[]>(['Electronics', 'Fashion', 'Home & Kitchen', 'Beauty', 'Books']);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch categories
        const catRes = await apiFetch('/api/categories');
        const catData = await catRes.json();
        setCategories(catData || ['Mobiles', 'Laptops', 'Audio', 'Wearables', 'Tablets', 'Gaming', 'Cameras', 'Drones', 'Home Appliances', 'Jewelry', 'Fashion']);

        // Fetch product details
        const prodRes = await apiFetch(`/api/admin/products/${id}`);
        if (!prodRes.ok) throw new Error('Failed to fetch product');
        const product = await prodRes.json();

        setProductName(product.name || '');
        setDescription(product.description || '');
        setSellingPrice(product.price?.toString() || '');
        setMrp(product.mrp?.toString() || '');
        setProductCategory(product.category || '');
        setBusinessCategory(product.business_category || '');
        setQuantity(product.stock?.toString() || '');
        setSku(product.sku || '');
        setPdpTemplate(product.pdp_template || 'Default');
        setHsnCode(product.hsn_code || '');
        setIsBestseller(product.is_bestseller || false);
        
        if (product.image_url) {
          setImages([{ preview: product.image_url, url: product.image_url }]);
        }
        
        if (product.seo) {
          const seo = typeof product.seo === 'string' ? JSON.parse(product.seo) : product.seo;
          setSeoTitle(seo.title || '');
          setSeoDescription(seo.description || '');
          setSeoKeywords(seo.keywords || '');
          setSeoSlug(seo.slug || '');
        }

        if (product.variants) {
          const variantsData = typeof product.variants === 'string' ? JSON.parse(product.variants) : product.variants;
          setVariants(variantsData.map((v: any) => ({
            ...v,
            images: v.images?.map((img: string) => ({ preview: img, url: img })) || []
          })));
        }

        if (product.size_chart_url) {
          setSizeChart({ name: 'Current Size Chart', url: product.size_chart_url });
        }

      } catch (err) {
        toast.error('Failed to load product data');
        navigate('/admin/products');
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [id, navigate]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const newImages = files.map((file: File) => ({
      file,
      preview: URL.createObjectURL(file)
    }));
    setImages(prev => [...prev, ...newImages]);
  };

  const handleVariantImageUpload = (variantId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const newImages = files.map((file: File) => ({
      file,
      preview: URL.createObjectURL(file)
    }));
    
    setVariants(prev => prev.map(v => 
      v.id === variantId ? { ...v, images: [...v.images, ...newImages] } : v
    ));
  };

  const removeVariantImage = (variantId: string, index: number) => {
    setVariants(prev => prev.map(v => {
      if (v.id === variantId) {
        const updatedImages = [...v.images];
        if (updatedImages[index].preview.startsWith('blob:')) {
          URL.revokeObjectURL(updatedImages[index].preview);
        }
        updatedImages.splice(index, 1);
        return { ...v, images: updatedImages };
      }
      return v;
    }));
  };

  const removeImage = (index: number) => {
    setImages(prev => {
      const updated = [...prev];
      if (updated[index].preview.startsWith('blob:')) {
        URL.revokeObjectURL(updated[index].preview);
      }
      updated.splice(index, 1);
      return updated;
    });
  };

  const addVariant = () => {
    const newVariant: Variant = {
      id: Math.random().toString(36).substr(2, 9),
      color: color || '',
      colorCode: colorCode || '#000000',
      size: size || '',
      mrp: mrp || '',
      price: sellingPrice || '',
      stock: quantity || '',
      sku: sku || '',
      images: []
    };
    setVariants(prev => [...prev, newVariant]);
  };

  const generateBulkVariants = () => {
    const colors = bulkColors.split(',').map(c => c.trim()).filter(c => c);
    const sizes = bulkSizes.split(',').map(s => s.trim()).filter(s => s);

    if (colors.length === 0 && sizes.length === 0) {
      toast.error('Please enter colors or sizes for bulk generation');
      return;
    }

    const newVariants: Variant[] = [];
    
    if (colors.length > 0 && sizes.length === 0) {
      colors.forEach(c => {
        newVariants.push({
          id: Math.random().toString(36).substr(2, 9),
          color: c,
          colorCode: '#000000',
          size: '',
          mrp: mrp || '',
          price: sellingPrice || '',
          stock: quantity || '',
          sku: `${sku}-${c}`.toUpperCase(),
          images: []
        });
      });
    } else if (sizes.length > 0 && colors.length === 0) {
      sizes.forEach(s => {
        newVariants.push({
          id: Math.random().toString(36).substr(2, 9),
          color: '',
          colorCode: '#000000',
          size: s,
          mrp: mrp || '',
          price: sellingPrice || '',
          stock: quantity || '',
          sku: `${sku}-${s}`.toUpperCase(),
          images: []
        });
      });
    } else {
      colors.forEach(c => {
        sizes.forEach(s => {
          newVariants.push({
            id: Math.random().toString(36).substr(2, 9),
            color: c,
            colorCode: '#000000',
            size: s,
            mrp: mrp || '',
            price: sellingPrice || '',
            stock: quantity || '',
            sku: `${sku}-${c}-${s}`.toUpperCase(),
            images: []
          });
        });
      });
    }

    setVariants(prev => [...prev, ...newVariants]);
    setBulkColors('');
    setBulkSizes('');
    toast.success(`Generated ${newVariants.length} variants`);
  };

  const removeVariant = (id: string) => {
    setVariants(prev => prev.filter(v => v.id !== id));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!productName || !sellingPrice || !productCategory) {
      toast.error('Please fill in all required fields');
      return;
    }

    setIsSubmitting(true);
    const formData = new FormData();
    formData.append('name', productName);
    formData.append('description', description);
    formData.append('price', sellingPrice);
    formData.append('mrp', mrp);
    formData.append('category', productCategory);
    formData.append('business_category', businessCategory);
    formData.append('stock', quantity);
    formData.append('sku', sku);
    formData.append('pdp_template', pdpTemplate);
    formData.append('hsn_code', hsnCode);
    formData.append('is_bestseller', isBestseller.toString());
    
    // SEO Data
    formData.append('seo', JSON.stringify({
      title: seoTitle,
      description: seoDescription,
      keywords: seoKeywords,
      slug: seoSlug
    }));

    // Variants Data
    const variantsData = variants.map(v => ({
      ...v,
      images: v.images.map((img, i) => img.file ? `variant_${v.id}_image_${i}` : img.url)
    }));
    formData.append('variants', JSON.stringify(variantsData));

    // Main Images
    images.forEach((img, i) => {
      if (img.file) {
        formData.append(`image_${i}`, img.file);
      } else if (img.url) {
        formData.append(`existing_image_${i}`, img.url);
      }
    });

    // Variant Images
    variants.forEach(v => {
      v.images.forEach((img, i) => {
        if (img.file) {
          formData.append(`variant_${v.id}_image_${i}`, img.file);
        }
      });
    });

    if (sizeChart?.file) {
      formData.append('size_chart', sizeChart.file);
    } else if (sizeChart?.url) {
      formData.append('existing_size_chart', sizeChart.url);
    }

    try {
      const res = await apiFetch(`/api/admin/products/${id}`, {
        method: 'PUT',
        body: formData
      });

      if (res.ok) {
        toast.success('Product updated successfully');
        navigate('/admin/products');
      } else {
        const error = await res.json();
        toast.error(error.error || 'Failed to update product');
      }
    } catch (err) {
      toast.error('Something went wrong');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-[#F5F7F9]">
        <AdminSidebar />
        <div className="flex-1 ml-64 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-[#F5F7F9]">
      <AdminSidebar />
      
      <div className="flex-1 ml-64">
        {/* Topbar */}
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 sticky top-0 z-40">
          <div className="flex items-center space-x-4">
            <button 
              onClick={() => navigate('/admin/products')}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
            <h1 className="text-lg font-bold text-gray-900">Edit Product</h1>
          </div>
          
          <div className="flex items-center space-x-3">
            <button 
              onClick={() => navigate('/admin/products')}
              className="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button 
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="px-6 py-2 bg-teal-600 text-white text-sm font-bold rounded-lg hover:bg-teal-700 transition-all shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </header>

        <main className="p-8 max-w-5xl mx-auto space-y-8">
          {/* Product Media Section */}
          <section className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-lg font-bold text-gray-900">Product Media</h2>
            </div>
            <div className="p-6 space-y-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Upload Product Images</label>
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-gray-200 rounded-xl p-8 flex flex-col items-center justify-center space-y-3 hover:border-teal-500 hover:bg-teal-50/30 transition-all cursor-pointer group"
              >
                <div className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center group-hover:bg-teal-100 transition-colors">
                  <Upload className="w-6 h-6 text-gray-400 group-hover:text-teal-600" />
                </div>
                <div className="text-center">
                  <p className="text-sm font-semibold text-gray-900">Click to upload or drag and drop</p>
                  <p className="text-xs text-gray-500 mt-1">Recommended size: 1000 x 1000 px. Max size: 5MB.</p>
                </div>
                <input 
                  type="file" 
                  ref={fileInputRef}
                  onChange={handleImageUpload}
                  multiple 
                  accept="image/*"
                  className="hidden" 
                />
              </div>

              {images.length > 0 && (
                <div className="grid grid-cols-4 sm:grid-cols-6 gap-4 mt-6">
                  {images.map((img, index) => (
                    <div key={index} className="relative aspect-square rounded-lg border border-gray-200 overflow-hidden group">
                      <img src={img.preview} alt="" className="w-full h-full object-cover" />
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          removeImage(index);
                        }}
                        className="absolute top-1 right-1 p-1 bg-white/80 backdrop-blur-sm rounded-full text-red-500 opacity-0 group-hover:opacity-100 transition-opacity shadow-sm"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>

          {/* Product Information Section */}
          <section className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-lg font-bold text-gray-900">Product Information</h2>
            </div>
            <div className="p-6 space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">Product Name <span className="text-red-500">*</span></label>
                <input 
                  type="text" 
                  value={productName}
                  onChange={(e) => setProductName(e.target.value)}
                  placeholder="Enter product name"
                  maxLength={200}
                  className="w-full px-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">Description</label>
                <div className="border border-gray-200 rounded-lg overflow-hidden">
                  <div className="bg-gray-50 border-b border-gray-200 p-2 flex items-center space-x-1">
                    <button className="p-1.5 hover:bg-white rounded transition-colors"><Bold className="w-4 h-4 text-gray-600" /></button>
                    <button className="p-1.5 hover:bg-white rounded transition-colors"><Italic className="w-4 h-4 text-gray-600" /></button>
                    <div className="w-px h-4 bg-gray-300 mx-1"></div>
                    <button className="p-1.5 hover:bg-white rounded transition-colors"><List className="w-4 h-4 text-gray-600" /></button>
                    <div className="w-px h-4 bg-gray-300 mx-1"></div>
                    <button className="p-1.5 hover:bg-white rounded transition-colors"><AlignLeft className="w-4 h-4 text-gray-600" /></button>
                    <button className="p-1.5 hover:bg-white rounded transition-colors"><AlignCenter className="w-4 h-4 text-gray-600" /></button>
                    <button className="p-1.5 hover:bg-white rounded transition-colors"><AlignRight className="w-4 h-4 text-gray-600" /></button>
                  </div>
                  <textarea 
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Describe your product..."
                    className="w-full px-4 py-3 text-sm focus:outline-none min-h-[150px] resize-y"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">MRP (Maximum Retail Price)</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-medium">₹</span>
                    <input 
                      type="number" 
                      value={mrp}
                      onChange={(e) => setMrp(e.target.value)}
                      className="w-full pl-8 pr-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Selling Price <span className="text-red-500">*</span></label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-medium">₹</span>
                    <input 
                      type="number" 
                      value={sellingPrice}
                      onChange={(e) => setSellingPrice(e.target.value)}
                      className="w-full pl-8 pr-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Business Category</label>
                  <select 
                    value={businessCategory}
                    onChange={(e) => setBusinessCategory(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all appearance-none"
                  >
                    <option value="">Select Category</option>
                    {businessCategories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Product Category <span className="text-red-500">*</span></label>
                  <select 
                    value={productCategory}
                    onChange={(e) => setProductCategory(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all appearance-none"
                  >
                    <option value="">Select Category</option>
                    {categories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Quantity</label>
                  <input 
                    type="number" 
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Custom SKU</label>
                  <input 
                    type="text" 
                    value={sku}
                    onChange={(e) => setSku(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">PDP Template</label>
                  <select 
                    value={pdpTemplate}
                    onChange={(e) => setPdpTemplate(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all appearance-none"
                  >
                    <option value="Default">Default</option>
                    <option value="Minimal">Minimal</option>
                    <option value="Detailed">Detailed</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">HSN Code</label>
                  <input 
                    type="text" 
                    value={hsnCode}
                    onChange={(e) => setHsnCode(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all"
                  />
                </div>
                <div className="flex items-center space-x-3 pt-8">
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={isBestseller}
                      onChange={(e) => setIsBestseller(e.target.checked)}
                      className="sr-only peer" 
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-teal-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-teal-600"></div>
                  </label>
                  <span className="text-sm font-bold text-gray-700">Mark as Bestseller</span>
                </div>
              </div>
            </div>
          </section>

          {/* Features Section */}
          <section className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-lg font-bold text-gray-900">Features & Variants</h2>
            </div>
            <div className="p-6 space-y-8">
              {/* Bulk Generator */}
              <div className="p-6 bg-teal-50/50 rounded-2xl border border-teal-100 space-y-4">
                <div className="flex items-center space-x-2 mb-2">
                  <TrendingUp className="w-5 h-5 text-teal-600" />
                  <h3 className="text-sm font-bold text-teal-900">Bulk Variant Generator</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-teal-700 uppercase tracking-wider">Colors (Comma separated)</label>
                    <input 
                      type="text" 
                      value={bulkColors}
                      onChange={(e) => setBulkColors(e.target.value)}
                      placeholder="Red, Blue, Green"
                      className="w-full px-4 py-2.5 bg-white border border-teal-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-teal-700 uppercase tracking-wider">Sizes (Comma separated)</label>
                    <input 
                      type="text" 
                      value={bulkSizes}
                      onChange={(e) => setBulkSizes(e.target.value)}
                      placeholder="S, M, L, XL"
                      className="w-full px-4 py-2.5 bg-white border border-teal-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                    />
                  </div>
                </div>
                <button 
                  type="button"
                  onClick={generateBulkVariants}
                  className="w-full py-2.5 bg-teal-600 text-white text-sm font-bold rounded-lg hover:bg-teal-700 transition-all shadow-sm"
                >
                  Generate All Combinations
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Color Name</label>
                  <input 
                    type="text" 
                    value={color}
                    onChange={(e) => setColor(e.target.value)}
                    placeholder="e.g. Midnight Black"
                    className="w-full px-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Color Hex Code</label>
                  <div className="flex items-center space-x-2">
                    <input 
                      type="color" 
                      value={colorCode}
                      onChange={(e) => setColorCode(e.target.value)}
                      className="w-10 h-10 rounded-lg cursor-pointer border-none p-0"
                    />
                    <input 
                      type="text" 
                      value={colorCode}
                      onChange={(e) => setColorCode(e.target.value)}
                      className="flex-1 px-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm uppercase"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Size</label>
                  <input 
                    type="text" 
                    value={size}
                    onChange={(e) => setSize(e.target.value)}
                    placeholder="e.g. 128GB"
                    className="w-full px-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-bold text-gray-700">Variants List</label>
                  <button 
                    type="button"
                    onClick={addVariant}
                    className="flex items-center space-x-2 text-sm font-bold text-teal-600 hover:text-teal-700 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Single Variant</span>
                  </button>
                </div>

                {variants.length > 0 ? (
                  <div className="space-y-6">
                    {variants.map((variant) => (
                      <div key={variant.id} className="p-6 border border-gray-100 rounded-2xl space-y-4 bg-gray-50/30">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div 
                              className="w-4 h-4 rounded-full border border-gray-200"
                              style={{ backgroundColor: variant.colorCode || '#000000' }}
                            />
                            <h3 className="text-sm font-bold text-gray-900">
                              {variant.color || 'No Color'} {variant.size ? `/ ${variant.size}` : ''}
                            </h3>
                          </div>
                          <button 
                            onClick={() => removeVariant(variant.id)}
                            className="p-1.5 text-gray-400 hover:text-red-500 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold uppercase text-gray-400">Color Name</label>
                            <input 
                              type="text" 
                              value={variant.color}
                              onChange={(e) => {
                                const updated = variants.map(v => v.id === variant.id ? { ...v, color: e.target.value } : v);
                                setVariants(updated);
                              }}
                              className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold uppercase text-gray-400">Hex Code</label>
                            <div className="flex items-center space-x-2">
                              <input 
                                type="color" 
                                value={variant.colorCode || '#000000'}
                                onChange={(e) => {
                                  const updated = variants.map(v => v.id === variant.id ? { ...v, colorCode: e.target.value } : v);
                                  setVariants(updated);
                                }}
                                className="w-8 h-8 rounded cursor-pointer border-none p-0"
                              />
                              <input 
                                type="text" 
                                value={variant.colorCode || '#000000'}
                                onChange={(e) => {
                                  const updated = variants.map(v => v.id === variant.id ? { ...v, colorCode: e.target.value } : v);
                                  setVariants(updated);
                                }}
                                className="flex-1 px-3 py-2 bg-white border border-gray-200 rounded-lg text-xs uppercase"
                              />
                            </div>
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold uppercase text-gray-400">Size</label>
                            <input 
                              type="text" 
                              value={variant.size}
                              onChange={(e) => {
                                const updated = variants.map(v => v.id === variant.id ? { ...v, size: e.target.value } : v);
                                setVariants(updated);
                              }}
                              className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold uppercase text-gray-400">MRP</label>
                            <input 
                              type="number" 
                              value={variant.mrp}
                              onChange={(e) => {
                                const updated = variants.map(v => v.id === variant.id ? { ...v, mrp: e.target.value } : v);
                                setVariants(updated);
                              }}
                              className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold uppercase text-gray-400">Price</label>
                            <input 
                              type="number" 
                              value={variant.price}
                              onChange={(e) => {
                                const updated = variants.map(v => v.id === variant.id ? { ...v, price: e.target.value } : v);
                                setVariants(updated);
                              }}
                              className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold uppercase text-gray-400">Stock</label>
                            <input 
                              type="number" 
                              value={variant.stock}
                              onChange={(e) => {
                                const updated = variants.map(v => v.id === variant.id ? { ...v, stock: e.target.value } : v);
                                setVariants(updated);
                              }}
                              className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold uppercase text-gray-400">SKU</label>
                            <input 
                              type="text" 
                              value={variant.sku}
                              onChange={(e) => {
                                const updated = variants.map(v => v.id === variant.id ? { ...v, sku: e.target.value } : v);
                                setVariants(updated);
                              }}
                              className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-bold uppercase text-gray-400">Variant Images</label>
                          <div className="flex flex-wrap gap-3">
                            {variant.images.map((img, idx) => (
                              <div key={idx} className="relative w-16 h-16 rounded-lg border border-gray-200 overflow-hidden group">
                                <img src={img.preview} alt="" className="w-full h-full object-cover" />
                                <button 
                                  onClick={() => removeVariantImage(variant.id, idx)}
                                  className="absolute top-0.5 right-0.5 p-0.5 bg-white/80 rounded-full text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                                >
                                  <X className="w-3 h-3" />
                                </button>
                              </div>
                            ))}
                            <button 
                              type="button"
                              onClick={() => variantImageRefs.current[variant.id]?.click()}
                              className="w-16 h-16 rounded-lg border-2 border-dashed border-gray-200 flex items-center justify-center hover:border-teal-500 hover:bg-teal-50 transition-all"
                            >
                              <Plus className="w-4 h-4 text-gray-400" />
                            </button>
                            <input 
                              type="file"
                              ref={el => variantImageRefs.current[variant.id] = el}
                              onChange={(e) => handleVariantImageUpload(variant.id, e)}
                              multiple
                              accept="image/*"
                              className="hidden"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-8 border border-dashed border-gray-200 rounded-xl flex flex-col items-center justify-center text-center space-y-2">
                    <Package className="w-6 h-6 text-gray-300" />
                    <p className="text-sm text-gray-500">No variants added yet. Add variants for different colors or sizes.</p>
                  </div>
                )}
              </div>
            </div>
          </section>

          {/* SEO Section */}
          <section className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-lg font-bold text-gray-900">SEO Settings</h2>
            </div>
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Meta Title</label>
                  <input 
                    type="text" 
                    value={seoTitle}
                    onChange={(e) => setSeoTitle(e.target.value)}
                    placeholder="Enter meta title"
                    className="w-full px-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">URL Handle (Slug)</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-xs">/products/</span>
                    <input 
                      type="text" 
                      value={seoSlug}
                      onChange={(e) => setSeoSlug(e.target.value.toLowerCase().replace(/ /g, '-'))}
                      placeholder="product-url-handle"
                      className="w-full pl-20 pr-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all"
                    />
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">Meta Description</label>
                <textarea 
                  value={seoDescription}
                  onChange={(e) => setSeoDescription(e.target.value)}
                  placeholder="Enter meta description"
                  className="w-full px-4 py-3 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all min-h-[100px] resize-y"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">Keywords</label>
                <input 
                  type="text" 
                  value={seoKeywords}
                  onChange={(e) => setSeoKeywords(e.target.value)}
                  placeholder="e.g. mobile, smartphone, electronics"
                  className="w-full px-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all"
                />
              </div>
            </div>
          </section>

          {/* Advanced Information Section */}
          <section className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-lg font-bold text-gray-900">Advanced Information</h2>
            </div>
            <div className="p-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">Size Chart</label>
                <div 
                  onClick={() => sizeChartRef.current?.click()}
                  className="border-2 border-dashed border-gray-200 rounded-xl p-6 flex items-center space-x-4 hover:border-teal-500 hover:bg-teal-50/30 transition-all cursor-pointer group"
                >
                  <div className="w-10 h-10 bg-gray-50 rounded-lg flex items-center justify-center group-hover:bg-teal-100 transition-colors">
                    <Upload className="w-5 h-5 text-gray-400 group-hover:text-teal-600" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-gray-900">
                      {sizeChart ? sizeChart.name : 'Upload Size Chart'}
                    </p>
                    <p className="text-xs text-gray-500">PDF, JPG or PNG. Max 2MB.</p>
                  </div>
                  {sizeChart && (
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setSizeChart(null);
                      }}
                      className="p-2 hover:bg-white rounded-full text-red-500"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                  <input 
                    type="file" 
                    ref={sizeChartRef}
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) setSizeChart({ file, name: file.name });
                    }}
                    accept=".pdf,image/*"
                    className="hidden" 
                  />
                </div>
              </div>
            </div>
          </section>

          {/* Bottom Actions */}
          <div className="flex items-center justify-end space-x-4 pt-4 pb-12">
            <button 
              onClick={() => navigate('/admin/products')}
              className="px-8 py-3 text-sm font-bold text-gray-600 hover:bg-gray-100 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button 
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="px-12 py-3 bg-teal-600 text-white text-sm font-bold rounded-xl hover:bg-teal-700 transition-all shadow-lg shadow-teal-100 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? 'Saving Product...' : 'Save Changes'}
            </button>
          </div>
        </main>
      </div>
    </div>
  );
}
