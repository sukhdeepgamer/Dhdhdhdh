import React, { useState, useEffect } from 'react';
import { Percent, Plus, Trash2, Save, Calendar, Tag, ShoppingCart, Gift, MoreVertical, CheckCircle, XCircle, Clock } from 'lucide-react';
import AdminSidebar from '../../components/AdminSidebar';
import { Offer } from '../../types';
import toast from 'react-hot-toast';
import { apiFetch } from '../../utils/api';

export default function AdminOffers() {
  const [offers, setOffers] = useState<Offer[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [loading, setLoading] = useState(true);
  const [newOffer, setNewOffer] = useState<Partial<Offer>>({
    name: '',
    type: 'product',
    logic: '',
    discountType: 'percentage',
    discountValue: 0,
    autoApply: true,
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    usedCount: 0,
    status: 'active'
  });

  useEffect(() => {
    fetchOffers();
  }, []);

  const fetchOffers = async () => {
    setLoading(true);
    try {
      const res = await apiFetch('/api/admin/offers');
      const data = await res.json();
      setOffers(data || []);
    } catch (error) {
      console.error('Failed to fetch offers:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveOffer = async () => {
    if (!newOffer.name || !newOffer.discountValue) {
      toast.error('Please fill in all required fields');
      return;
    }
    
    try {
      const res = await apiFetch('/api/admin/offers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newOffer)
      });
      if (res.ok) {
        toast.success('Offer created successfully');
        setIsAdding(false);
        fetchOffers();
      }
    } catch (error) {
      toast.error('Failed to create offer');
    }
  };

  const deleteOffer = async (id: string) => {
    try {
      const res = await apiFetch(`/api/admin/offers/${id}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        toast.success('Offer deleted');
        fetchOffers();
      }
    } catch (error) {
      toast.error('Failed to delete offer');
    }
  };

  return (
    <div className="flex min-h-screen bg-[#F5F7F9]">
      <AdminSidebar />
      <div className="flex-1 ml-64">
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 sticky top-0 z-40">
          <div className="flex items-center space-x-3">
            <Percent className="w-6 h-6 text-teal-600" />
            <h1 className="text-lg font-bold text-gray-900">Offers & Discounts</h1>
          </div>
          <button 
            onClick={() => setIsAdding(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-teal-600 text-white rounded-lg text-sm font-bold hover:bg-teal-700 transition-all shadow-lg shadow-teal-100"
          >
            <Plus className="w-4 h-4" />
            <span>Create New Offer</span>
          </button>
        </header>

        <main className="p-8 max-w-6xl mx-auto space-y-8">
          {isAdding && (
            <div className="bg-white border-2 border-teal-500 rounded-3xl p-8 shadow-xl shadow-teal-500/5 space-y-8 animate-in fade-in slide-in-from-top-4 duration-300">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900">New Offer Configuration</h3>
                <button onClick={() => setIsAdding(false)} className="text-gray-400 hover:text-gray-600">
                  <XCircle className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Offer Name</label>
                    <input 
                      type="text" 
                      placeholder="e.g., Summer Sale 2024"
                      value={newOffer.name}
                      onChange={(e) => setNewOffer({...newOffer, name: e.target.value})}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Offer Type</label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: 'product', icon: Tag, label: 'Product' },
                        { id: 'cart', icon: ShoppingCart, label: 'Cart' },
                        { id: 'bogo', icon: Gift, label: 'BOGO' },
                      ].map(type => (
                        <button
                          key={type.id}
                          onClick={() => setNewOffer({...newOffer, type: type.id as any})}
                          className={`flex flex-col items-center justify-center p-3 rounded-xl border-2 transition-all ${
                            newOffer.type === type.id 
                              ? 'border-teal-600 bg-teal-50 text-teal-600' 
                              : 'border-gray-100 bg-gray-50 text-gray-400 hover:border-gray-200'
                          }`}
                        >
                          <type.icon className="w-5 h-5 mb-1" />
                          <span className="text-[10px] font-bold uppercase">{type.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Discount Type</label>
                      <select 
                        value={newOffer.discountType}
                        onChange={(e) => setNewOffer({...newOffer, discountType: e.target.value as any})}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                      >
                        <option value="percentage">Percentage (%)</option>
                        <option value="fixed">Fixed Amount (₹)</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Value</label>
                      <input 
                        type="number" 
                        value={newOffer.discountValue}
                        onChange={(e) => setNewOffer({...newOffer, discountValue: Number(e.target.value)})}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Start Date</label>
                      <input 
                        type="date" 
                        value={newOffer.startDate}
                        onChange={(e) => setNewOffer({...newOffer, startDate: e.target.value})}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">End Date</label>
                      <input 
                        type="date" 
                        value={newOffer.endDate}
                        onChange={(e) => setNewOffer({...newOffer, endDate: e.target.value})}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Coupon Code (Optional)</label>
                    <input 
                      type="text" 
                      placeholder="e.g., WELCOME50"
                      value={newOffer.couponCode}
                      onChange={(e) => setNewOffer({...newOffer, couponCode: e.target.value.toUpperCase()})}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl border border-gray-100">
                    <div className="space-y-1">
                      <p className="text-sm font-bold text-gray-900">Auto-Apply Offer</p>
                      <p className="text-[10px] text-gray-500">Apply automatically if conditions are met</p>
                    </div>
                    <button 
                      onClick={() => setNewOffer({...newOffer, autoApply: !newOffer.autoApply})}
                      className={`w-12 h-6 rounded-full transition-all relative ${newOffer.autoApply ? 'bg-teal-600' : 'bg-gray-300'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${newOffer.autoApply ? 'right-1' : 'left-1'}`} />
                    </button>
                  </div>

                  <button 
                    onClick={handleSaveOffer}
                    className="w-full py-4 bg-teal-600 text-white rounded-2xl font-bold hover:bg-teal-700 transition-all shadow-lg shadow-teal-100"
                  >
                    Create Offer
                  </button>
                </div>
              </div>
            </div>
          )}

          <div className="bg-white rounded-3xl border border-gray-200 shadow-sm overflow-hidden">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Offer Details</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Type</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Discount</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Schedule</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {offers.map((offer) => (
                  <tr key={offer.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex flex-col">
                        <span className="text-sm font-bold text-gray-900">{offer.name}</span>
                        {offer.couponCode && (
                          <span className="text-[10px] font-bold text-teal-600 uppercase tracking-widest mt-1">Code: {offer.couponCode}</span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-xs font-medium text-gray-600 bg-gray-100 px-2 py-1 rounded-lg capitalize">
                        {offer.type}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm font-bold text-gray-900">
                        {offer.discountType === 'percentage' ? `${offer.discountValue}%` : `₹${offer.discountValue}`}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col text-[10px] text-gray-500 font-bold uppercase">
                        <span>{new Date(offer.startDate).toLocaleDateString()}</span>
                        <span className="text-gray-300">to</span>
                        <span>{new Date(offer.endDate).toLocaleDateString()}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded-lg text-[10px] font-bold uppercase border ${
                        offer.status === 'active' ? 'bg-green-50 text-green-600 border-green-100' :
                        offer.status === 'scheduled' ? 'bg-blue-50 text-blue-600 border-blue-100' :
                        'bg-gray-50 text-gray-400 border-gray-100'
                      }`}>
                        {offer.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button 
                        onClick={() => deleteOffer(offer.id)}
                        className="p-2 text-gray-300 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {offers.length === 0 && !isAdding && (
              <div className="p-12 text-center space-y-4">
                <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto">
                  <Percent className="w-8 h-8 text-gray-300" />
                </div>
                <p className="text-gray-500 font-medium">No active offers or discounts</p>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
