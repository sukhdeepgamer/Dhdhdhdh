import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  Plus, 
  Trash2, 
  Save, 
  RotateCcw, 
  ChevronDown, 
  CheckCircle2, 
  XCircle, 
  Info,
  MapPin,
  Package,
  Layers,
  Settings2,
  AlertCircle
} from 'lucide-react';
import AdminSidebar from '../../components/AdminSidebar';
import { RTORule, Product } from '../../types';
import toast from 'react-hot-toast';

const CATEGORIES = ['Mobiles', 'Laptops', 'Audio', 'Wearables', 'Accessories'];

export default function AdminRTO() {
  const [rules, setRules] = useState<RTORule[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [newRule, setNewRule] = useState<Partial<RTORule>>({
    name: '',
    type: 'product',
    targetIds: [],
    locations: [],
    paymentRules: {
      allowCOD: true,
      requireAdvance: false,
      advanceType: 'fixed',
      advanceValue: 0
    },
    priority: 1
  });

  useEffect(() => {
    // Load existing rules from localStorage
    const savedRules = localStorage.getItem('rto_rules');
    if (savedRules) {
      setRules(JSON.parse(savedRules));
    }

    // Fetch products for selection
    fetch('/api/products')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) setProducts(data);
      })
      .catch(err => console.error('Failed to fetch products:', err));
  }, []);

  const saveRules = (updatedRules: RTORule[]) => {
    localStorage.setItem('rto_rules', JSON.stringify(updatedRules));
    setRules(updatedRules);
    toast.success('Rules updated successfully');
  };

  const handleAddRule = () => {
    if (!newRule.name) {
      toast.error('Please enter a rule name');
      return;
    }
    const rule: RTORule = {
      ...newRule as RTORule,
      id: Date.now().toString(),
      priority: newRule.type === 'variant' ? 4 : newRule.type === 'product' ? 3 : newRule.type === 'category' ? 2 : 1
    };
    const updated = [...rules, rule].sort((a, b) => b.priority - a.priority);
    saveRules(updated);
    setIsAdding(false);
    setNewRule({
      name: '',
      type: 'product',
      targetIds: [],
      locations: [],
      paymentRules: {
        allowCOD: true,
        requireAdvance: false,
        advanceType: 'fixed',
        advanceValue: 0
      },
      priority: 1
    });
  };

  const deleteRule = (id: string) => {
    const updated = rules.filter(r => r.id !== id);
    saveRules(updated);
  };

  return (
    <div className="flex min-h-screen bg-[#F5F7F9]">
      <AdminSidebar />
      
      <div className="flex-1 ml-64">
        {/* Topbar */}
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 sticky top-0 z-40">
          <div className="flex items-center space-x-3">
            <ShieldAlert className="w-6 h-6 text-teal-600" />
            <h1 className="text-lg font-bold text-gray-900">Advanced RTO & Payment Control</h1>
          </div>
          <div className="flex items-center space-x-3">
            <button 
              onClick={() => setIsAdding(true)}
              className="flex items-center space-x-2 px-4 py-2 bg-teal-600 text-white rounded-lg text-sm font-bold hover:bg-teal-700 transition-all shadow-lg shadow-teal-100"
            >
              <Plus className="w-4 h-4" />
              <span>Create New Rule</span>
            </button>
          </div>
        </header>

        <main className="p-8 space-y-8 max-w-6xl mx-auto">
          {/* Info Banner */}
          <div className="bg-blue-50 border border-blue-100 rounded-2xl p-6 flex items-start space-x-4">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Info className="w-5 h-5 text-blue-600" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-blue-900">Rule Priority Engine</h3>
              <p className="text-xs text-blue-700 leading-relaxed">
                Rules are applied based on priority: <strong>Variant Level (Highest)</strong> &gt; <strong>Product Level</strong> &gt; <strong>Category Level</strong> &gt; <strong>Global Settings (Lowest)</strong>. 
                If multiple rules apply, the highest priority rule will override others.
              </p>
            </div>
          </div>

          {/* Rules List */}
          <div className="space-y-4">
            <h2 className="text-sm font-bold text-gray-400 uppercase tracking-wider">Active Payment Rules</h2>
            
            {rules.length === 0 && !isAdding && (
              <div className="bg-white border border-dashed border-gray-300 rounded-3xl p-12 text-center space-y-4">
                <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto">
                  <Settings2 className="w-8 h-8 text-gray-300" />
                </div>
                <div className="space-y-1">
                  <p className="text-gray-900 font-bold">No rules configured yet</p>
                  <p className="text-xs text-gray-500">Create rules to control COD and advance payments at various levels.</p>
                </div>
                <button 
                  onClick={() => setIsAdding(true)}
                  className="px-6 py-2 bg-teal-50 text-teal-600 rounded-xl text-sm font-bold hover:bg-teal-100 transition-all"
                >
                  Configure First Rule
                </button>
              </div>
            )}

            {/* Add Rule Form */}
            {isAdding && (
              <div className="bg-white border-2 border-teal-500 rounded-3xl p-8 shadow-xl shadow-teal-500/5 space-y-8 animate-in fade-in slide-in-from-top-4 duration-300">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold text-gray-900">New Payment Rule</h3>
                  <button onClick={() => setIsAdding(false)} className="text-gray-400 hover:text-gray-600">
                    <RotateCcw className="w-5 h-5" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-8">
                  {/* Left Column: Target Selection */}
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Rule Name</label>
                      <input 
                        type="text" 
                        placeholder="e.g., High Value Product COD Block"
                        value={newRule.name}
                        onChange={(e) => setNewRule({...newRule, name: e.target.value})}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Target Level</label>
                      <div className="grid grid-cols-4 gap-2">
                        {[
                          { id: 'location', icon: MapPin, label: 'Location' },
                          { id: 'category', icon: Layers, label: 'Category' },
                          { id: 'product', icon: Package, label: 'Product' },
                          { id: 'variant', icon: Settings2, label: 'Variant' },
                        ].map(type => (
                          <button
                            key={type.id}
                            onClick={() => setNewRule({...newRule, type: type.id as any, targetIds: []})}
                            className={`flex flex-col items-center justify-center p-3 rounded-xl border-2 transition-all ${
                              newRule.type === type.id 
                                ? 'border-teal-600 bg-teal-50 text-teal-600' 
                                : 'border-gray-100 bg-gray-50 text-gray-400 hover:border-gray-200'
                            }`}
                          >
                            <type.icon className="w-5 h-5 mb-1" />
                            <span className="text-[10px] font-bold uppercase">{type.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {newRule.type === 'category' && (
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Select Categories</label>
                        <div className="flex flex-wrap gap-2">
                          {CATEGORIES.map(cat => (
                            <button
                              key={cat}
                              onClick={() => {
                                const ids = newRule.targetIds || [];
                                const next = ids.includes(cat) ? ids.filter(i => i !== cat) : [...ids, cat];
                                setNewRule({...newRule, targetIds: next});
                              }}
                              className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                                newRule.targetIds?.includes(cat)
                                  ? 'bg-teal-600 text-white border-teal-600'
                                  : 'bg-white text-gray-600 border-gray-200 hover:border-teal-600'
                              }`}
                            >
                              {cat}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {newRule.type === 'product' && (
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Select Products</label>
                        <div className="max-h-48 overflow-y-auto border border-gray-200 rounded-xl divide-y divide-gray-100">
                          {products.map(p => (
                            <div 
                              key={p.id} 
                              onClick={() => {
                                const ids = newRule.targetIds || [];
                                const next = ids.includes(p.id.toString()) ? ids.filter(i => i !== p.id.toString()) : [...ids, p.id.toString()];
                                setNewRule({...newRule, targetIds: next});
                              }}
                              className="flex items-center space-x-3 p-3 cursor-pointer hover:bg-gray-50"
                            >
                              <div className={`w-4 h-4 rounded border flex items-center justify-center ${newRule.targetIds?.includes(p.id.toString()) ? 'bg-teal-600 border-teal-600' : 'border-gray-300'}`}>
                                {newRule.targetIds?.includes(p.id.toString()) && <Plus className="w-3 h-3 text-white" />}
                              </div>
                              <span className="text-sm text-gray-700">{p.name}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {newRule.type === 'location' && (
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Enter PIN Codes / States</label>
                        <textarea 
                          placeholder="Enter comma separated PINs or States (e.g., 500001, Maharashtra, 400001)"
                          className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 h-24"
                          onChange={(e) => setNewRule({...newRule, locations: e.target.value.split(',').map(s => s.trim())})}
                        />
                      </div>
                    )}
                  </div>

                  {/* Right Column: Rule Logic */}
                  <div className="space-y-6">
                    <div className="space-y-4 p-6 bg-gray-50 rounded-2xl border border-gray-100">
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <h4 className="text-sm font-bold text-gray-900">COD Availability</h4>
                          <p className="text-[10px] text-gray-500">Enable or disable Cash on Delivery</p>
                        </div>
                        <button 
                          onClick={() => setNewRule({
                            ...newRule, 
                            paymentRules: { ...newRule.paymentRules!, allowCOD: !newRule.paymentRules?.allowCOD }
                          })}
                          className={`w-12 h-6 rounded-full transition-all relative ${newRule.paymentRules?.allowCOD ? 'bg-teal-600' : 'bg-gray-300'}`}
                        >
                          <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${newRule.paymentRules?.allowCOD ? 'right-1' : 'left-1'}`} />
                        </button>
                      </div>

                      <div className="h-px bg-gray-200" />

                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <h4 className="text-sm font-bold text-gray-900">Advance Payment</h4>
                            <p className="text-[10px] text-gray-500">Require partial payment upfront</p>
                          </div>
                          <button 
                            onClick={() => setNewRule({
                              ...newRule, 
                              paymentRules: { ...newRule.paymentRules!, requireAdvance: !newRule.paymentRules?.requireAdvance }
                            })}
                            className={`w-12 h-6 rounded-full transition-all relative ${newRule.paymentRules?.requireAdvance ? 'bg-teal-600' : 'bg-gray-300'}`}
                          >
                            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${newRule.paymentRules?.requireAdvance ? 'right-1' : 'left-1'}`} />
                          </button>
                        </div>

                        {newRule.paymentRules?.requireAdvance && (
                          <div className="space-y-3 animate-in fade-in slide-in-from-top-2 duration-200">
                            <div className="flex items-center space-x-2">
                              <button 
                                onClick={() => setNewRule({...newRule, paymentRules: {...newRule.paymentRules!, advanceType: 'fixed'}})}
                                className={`flex-1 py-2 rounded-lg text-[10px] font-bold uppercase border transition-all ${newRule.paymentRules?.advanceType === 'fixed' ? 'bg-teal-600 text-white border-teal-600' : 'bg-white text-gray-500 border-gray-200'}`}
                              >
                                Fixed (₹)
                              </button>
                              <button 
                                onClick={() => setNewRule({...newRule, paymentRules: {...newRule.paymentRules!, advanceType: 'percentage'}})}
                                className={`flex-1 py-2 rounded-lg text-[10px] font-bold uppercase border transition-all ${newRule.paymentRules?.advanceType === 'percentage' ? 'bg-teal-600 text-white border-teal-600' : 'bg-white text-gray-500 border-gray-200'}`}
                              >
                                Percentage (%)
                              </button>
                            </div>
                            <input 
                              type="number" 
                              placeholder={newRule.paymentRules?.advanceType === 'fixed' ? "Enter amount in ₹" : "Enter percentage %"}
                              className="w-full px-4 py-2 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                              onChange={(e) => setNewRule({...newRule, paymentRules: {...newRule.paymentRules!, advanceValue: Number(e.target.value)}})}
                            />
                            <p className="text-[10px] text-teal-600 font-medium">
                              {newRule.paymentRules?.advanceType === 'fixed' 
                                ? `Customers will pay ₹${newRule.paymentRules?.advanceValue || 0} upfront.` 
                                : `Customers will pay ${newRule.paymentRules?.advanceValue || 0}% of order value upfront.`}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 pt-4">
                      <button 
                        onClick={handleAddRule}
                        className="flex-1 py-3 bg-teal-600 text-white rounded-xl text-sm font-bold hover:bg-teal-700 transition-all shadow-lg shadow-teal-100 flex items-center justify-center space-x-2"
                      >
                        <Save className="w-4 h-4" />
                        <span>Save Rule</span>
                      </button>
                      <button 
                        onClick={() => setIsAdding(false)}
                        className="flex-1 py-3 bg-white border border-gray-200 text-gray-500 rounded-xl text-sm font-bold hover:bg-gray-50 transition-all"
                      >
                        Discard
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Rules Display */}
            <div className="grid grid-cols-1 gap-4">
              {rules.map((rule) => (
                <div key={rule.id} className="bg-white border border-gray-200 rounded-2xl p-6 hover:shadow-md transition-all group">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-4">
                      <div className={`p-3 rounded-xl ${
                        rule.type === 'variant' ? 'bg-purple-50 text-purple-600' :
                        rule.type === 'product' ? 'bg-blue-50 text-blue-600' :
                        rule.type === 'category' ? 'bg-teal-50 text-teal-600' :
                        'bg-orange-50 text-orange-600'
                      }`}>
                        {rule.type === 'variant' ? <Settings2 className="w-5 h-5" /> :
                         rule.type === 'product' ? <Package className="w-5 h-5" /> :
                         rule.type === 'category' ? <Layers className="w-5 h-5" /> :
                         <MapPin className="w-5 h-5" />}
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <h3 className="text-sm font-bold text-gray-900">{rule.name}</h3>
                          <span className="text-[10px] font-bold uppercase px-2 py-0.5 bg-gray-100 text-gray-500 rounded tracking-wider">
                            Priority: {rule.priority}
                          </span>
                        </div>
                        <div className="flex items-center space-x-2 text-[10px] text-gray-400 font-bold uppercase tracking-wider">
                          <span>Target: {rule.type}</span>
                          <span>•</span>
                          <span>{rule.targetIds.length || rule.locations?.length || 0} Items</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-6">
                      <div className="flex items-center space-x-4 pr-6 border-r border-gray-100">
                        <div className="flex flex-col items-end">
                          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">COD</span>
                          <div className="flex items-center space-x-1">
                            {rule.paymentRules.allowCOD ? (
                              <CheckCircle2 className="w-4 h-4 text-green-500" />
                            ) : (
                              <XCircle className="w-4 h-4 text-red-500" />
                            )}
                            <span className={`text-xs font-bold ${rule.paymentRules.allowCOD ? 'text-green-600' : 'text-red-600'}`}>
                              {rule.paymentRules.allowCOD ? 'Enabled' : 'Blocked'}
                            </span>
                          </div>
                        </div>

                        <div className="flex flex-col items-end">
                          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Advance</span>
                          <div className="flex items-center space-x-1">
                            {rule.paymentRules.requireAdvance ? (
                              <CheckCircle2 className="w-4 h-4 text-teal-500" />
                            ) : (
                              <XCircle className="w-4 h-4 text-gray-300" />
                            )}
                            <span className={`text-xs font-bold ${rule.paymentRules.requireAdvance ? 'text-teal-600' : 'text-gray-400'}`}>
                              {rule.paymentRules.requireAdvance ? 
                                `${rule.paymentRules.advanceType === 'fixed' ? '₹' : ''}${rule.paymentRules.advanceValue}${rule.paymentRules.advanceType === 'percentage' ? '%' : ''}` : 
                                'None'}
                            </span>
                          </div>
                        </div>
                      </div>

                      <button 
                        onClick={() => deleteRule(rule.id)}
                        className="p-2 text-gray-300 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Rule Details Summary */}
                  <div className="mt-4 flex flex-wrap gap-2">
                    {rule.targetIds.map(id => (
                      <span key={id} className="text-[10px] font-medium text-gray-500 bg-gray-50 px-2 py-1 rounded border border-gray-100">
                        {id}
                      </span>
                    ))}
                    {rule.locations?.map(loc => (
                      <span key={loc} className="text-[10px] font-medium text-orange-600 bg-orange-50 px-2 py-1 rounded border border-orange-100">
                        {loc}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Global Settings Placeholder */}
          <div className="bg-white rounded-3xl border border-gray-200 p-8 space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <h2 className="text-lg font-bold text-gray-900">Global Payment Settings</h2>
                <p className="text-xs text-gray-500">Default behavior for all orders when no specific rules apply.</p>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold text-gray-400 uppercase">Status:</span>
                <span className="px-3 py-1 bg-green-50 text-green-600 text-[10px] font-bold rounded-full uppercase tracking-wider">Active</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="p-6 bg-gray-50 rounded-2xl border border-gray-100 flex items-center justify-between">
                <div className="space-y-1">
                  <h4 className="text-sm font-bold text-gray-900">Default COD</h4>
                  <p className="text-[10px] text-gray-500">Allow COD for all orders</p>
                </div>
                <div className="w-12 h-6 bg-teal-600 rounded-full relative">
                  <div className="absolute top-1 right-1 w-4 h-4 bg-white rounded-full" />
                </div>
              </div>

              <div className="p-6 bg-gray-50 rounded-2xl border border-gray-100 flex items-center justify-between">
                <div className="space-y-1">
                  <h4 className="text-sm font-bold text-gray-900">Risk-Based Blocking</h4>
                  <p className="text-[10px] text-gray-500">Auto-block COD for high-risk users</p>
                </div>
                <div className="w-12 h-6 bg-teal-600 rounded-full relative">
                  <div className="absolute top-1 right-1 w-4 h-4 bg-white rounded-full" />
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
