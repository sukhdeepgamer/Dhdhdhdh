import React, { useState, useEffect } from 'react';
import { Receipt, Plus, Trash2, Save, Info, CheckCircle2, XCircle, Percent, Layers, Package } from 'lucide-react';
import AdminSidebar from '../../components/AdminSidebar';
import { TaxRule } from '../../types';
import toast from 'react-hot-toast';

export default function AdminTaxes() {
  const [taxes, setTaxes] = useState<TaxRule[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [newTax, setNewTax] = useState<Partial<TaxRule>>({
    name: '',
    percentage: 0,
    applyTo: 'all',
    includeInPrice: false,
    type: 'gst'
  });

  useEffect(() => {
    const saved = localStorage.getItem('tax_rules');
    if (saved) setTaxes(JSON.parse(saved));
  }, []);

  const handleSaveTax = () => {
    if (!newTax.name || !newTax.percentage) {
      toast.error('Please fill in all required fields');
      return;
    }
    const tax: TaxRule = {
      ...newTax as TaxRule,
      id: Date.now().toString()
    };
    const updated = [...taxes, tax];
    localStorage.setItem('tax_rules', JSON.stringify(updated));
    setTaxes(updated);
    setIsAdding(false);
    toast.success('Tax rule created successfully');
  };

  const deleteTax = (id: string) => {
    const updated = taxes.filter(t => t.id !== id);
    localStorage.setItem('tax_rules', JSON.stringify(updated));
    setTaxes(updated);
    toast.success('Tax rule deleted');
  };

  return (
    <div className="flex min-h-screen bg-[#F5F7F9]">
      <AdminSidebar />
      <div className="flex-1 ml-64">
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 sticky top-0 z-40">
          <div className="flex items-center space-x-3">
            <Receipt className="w-6 h-6 text-teal-600" />
            <h1 className="text-lg font-bold text-gray-900">Tax Management</h1>
          </div>
          <button 
            onClick={() => setIsAdding(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-teal-600 text-white rounded-lg text-sm font-bold hover:bg-teal-700 transition-all shadow-lg shadow-teal-100"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Tax</span>
          </button>
        </header>

        <main className="p-8 max-w-6xl mx-auto space-y-8">
          {/* Info Banner */}
          <div className="bg-blue-50 border border-blue-100 rounded-2xl p-6 flex items-start space-x-4">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Info className="w-5 h-5 text-blue-600" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-blue-900">Tax Configuration</h3>
              <p className="text-xs text-blue-700 leading-relaxed">
                Configure GST and other additional charges. Taxes are calculated based on the order of: 
                <strong> Product Price &gt; Discounts &gt; Taxes &gt; Shipping</strong>.
              </p>
            </div>
          </div>

          {isAdding && (
            <div className="bg-white border-2 border-teal-500 rounded-3xl p-8 shadow-xl shadow-teal-500/5 space-y-8 animate-in fade-in slide-in-from-top-4 duration-300">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900">New Tax Rule</h3>
                <button onClick={() => setIsAdding(false)} className="text-gray-400 hover:text-gray-600">
                  <XCircle className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Tax Name</label>
                    <input 
                      type="text" 
                      placeholder="e.g., GST 18%"
                      value={newTax.name}
                      onChange={(e) => setNewTax({...newTax, name: e.target.value})}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Tax Type</label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { id: 'gst', label: 'GST' },
                        { id: 'extra_charge', label: 'Extra Charge' },
                      ].map(type => (
                        <button
                          key={type.id}
                          onClick={() => setNewTax({...newTax, type: type.id as any})}
                          className={`py-3 rounded-xl text-xs font-bold border transition-all ${
                            newTax.type === type.id 
                              ? 'border-teal-600 bg-teal-50 text-teal-600' 
                              : 'border-gray-100 bg-gray-50 text-gray-400 hover:border-gray-200'
                          }`}
                        >
                          <span className="text-[10px] font-bold uppercase">{type.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Tax Percentage (%)</label>
                    <div className="relative">
                      <input 
                        type="number" 
                        value={newTax.percentage}
                        onChange={(e) => setNewTax({...newTax, percentage: Number(e.target.value)})}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                      />
                      <Percent className="absolute right-4 top-3.5 w-4 h-4 text-gray-400" />
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Apply To</label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: 'all', icon: CheckCircle2, label: 'All' },
                        { id: 'category', icon: Layers, label: 'Category' },
                        { id: 'product', icon: Package, label: 'Product' },
                      ].map(target => (
                        <button
                          key={target.id}
                          onClick={() => setNewTax({...newTax, applyTo: target.id as any})}
                          className={`flex flex-col items-center justify-center p-3 rounded-xl border-2 transition-all ${
                            newTax.applyTo === target.id 
                              ? 'border-teal-600 bg-teal-50 text-teal-600' 
                              : 'border-gray-100 bg-gray-50 text-gray-400 hover:border-gray-200'
                          }`}
                        >
                          <target.icon className="w-5 h-5 mb-1" />
                          <span className="text-[10px] font-bold uppercase">{target.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl border border-gray-100">
                    <div className="space-y-1">
                      <p className="text-sm font-bold text-gray-900">Include in Price</p>
                      <p className="text-[10px] text-gray-500">Price shown to customer includes this tax</p>
                    </div>
                    <button 
                      onClick={() => setNewTax({...newTax, includeInPrice: !newTax.includeInPrice})}
                      className={`w-12 h-6 rounded-full transition-all relative ${newTax.includeInPrice ? 'bg-teal-600' : 'bg-gray-300'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${newTax.includeInPrice ? 'right-1' : 'left-1'}`} />
                    </button>
                  </div>

                  <button 
                    onClick={handleSaveTax}
                    className="w-full py-4 bg-teal-600 text-white rounded-2xl font-bold hover:bg-teal-700 transition-all shadow-lg shadow-teal-100"
                  >
                    Save Tax Rule
                  </button>
                </div>
              </div>
            </div>
          )}

          <div className="bg-white rounded-3xl border border-gray-200 shadow-sm overflow-hidden">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Tax Name</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Type</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Percentage</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Apply To</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Inclusive</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {taxes.map((tax) => (
                  <tr key={tax.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-6 py-4">
                      <span className="text-sm font-bold text-gray-900">{tax.name}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-[10px] font-bold text-teal-600 bg-teal-50 px-2 py-1 rounded uppercase tracking-wider">
                        {tax.type === 'gst' ? 'GST' : 'Extra Charge'}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm font-bold text-gray-900">{tax.percentage}%</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-xs font-medium text-gray-600 bg-gray-100 px-2 py-1 rounded capitalize">
                        {tax.applyTo}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      {tax.includeInPrice ? (
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                      ) : (
                        <XCircle className="w-4 h-4 text-gray-300" />
                      )}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button 
                        onClick={() => deleteTax(tax.id)}
                        className="p-2 text-gray-300 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {taxes.length === 0 && !isAdding && (
              <div className="p-12 text-center space-y-4">
                <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto">
                  <Receipt className="w-8 h-8 text-gray-300" />
                </div>
                <p className="text-gray-500 font-medium">No tax rules configured</p>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
