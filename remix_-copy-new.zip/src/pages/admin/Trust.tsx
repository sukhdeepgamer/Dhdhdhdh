import AdminSidebar from '../../components/AdminSidebar';
import { ShieldCheck } from 'lucide-react';

export default function AdminTrust() {
  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar />
      <div className="flex-1 ml-64 p-8">
        <div className="flex items-center space-x-3 mb-8">
          <ShieldCheck className="w-8 h-8 text-teal-600" />
          <h1 className="text-2xl font-bold text-gray-900">Trust Markers</h1>
        </div>
        <div className="bg-white p-8 rounded-2xl border border-gray-200 shadow-sm h-96 flex items-center justify-center">
          <p className="text-gray-400">Trust badges and certifications will appear here.</p>
        </div>
      </div>
    </div>
  );
}
