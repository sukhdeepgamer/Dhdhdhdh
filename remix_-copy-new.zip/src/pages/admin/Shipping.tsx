import React, { useState, useEffect } from 'react';
import { Globe, Save, Info, CheckCircle2, XCircle, ExternalLink, Truck, ShieldCheck, Key } from 'lucide-react';
import AdminSidebar from '../../components/AdminSidebar';
import { ShippingIntegration } from '../../types';
import toast from 'react-hot-toast';

export default function AdminShipping() {
  const [integration, setIntegration] = useState<ShippingIntegration>({
    method: 'manual',
    enabled: true
  });

  useEffect(() => {
    const saved = localStorage.getItem('shipping_integration');
    if (saved) setIntegration(JSON.parse(saved));
  }, []);

  const handleSave = () => {
    localStorage.setItem('shipping_integration', JSON.stringify(integration));
    toast.success('Shipping configuration saved');
  };

  return (
    <div className="flex min-h-screen bg-[#F5F7F9]">
      <AdminSidebar />
      <div className="flex-1 ml-64">
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 sticky top-0 z-40">
          <div className="flex items-center space-x-3">
            <Globe className="w-6 h-6 text-teal-600" />
            <h1 className="text-lg font-bold text-gray-900">Shipping Integration</h1>
          </div>
          <button 
            onClick={handleSave}
            className="flex items-center space-x-2 px-4 py-2 bg-teal-600 text-white rounded-lg text-sm font-bold hover:bg-teal-700 transition-all shadow-lg shadow-teal-100"
          >
            <Save className="w-4 h-4" />
            <span>Save Configuration</span>
          </button>
        </header>

        <main className="p-8 max-w-4xl mx-auto space-y-8">
          {/* Info Banner */}
          <div className="bg-blue-50 border border-blue-100 rounded-2xl p-6 flex items-start space-x-4">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Info className="w-5 h-5 text-blue-600" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-blue-900">Shipping Strategy</h3>
              <p className="text-xs text-blue-700 leading-relaxed">
                Choose between automated shipping via Shiprocket or manual entry. 
                Automated shipping provides real-time tracking IDs and label printing.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-8">
            {/* Method Selection */}
            <section className="bg-white p-8 rounded-3xl border border-gray-200 shadow-sm space-y-8">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-teal-50 rounded-lg">
                    <Truck className="w-5 h-5 text-teal-600" />
                  </div>
                  <h2 className="text-md font-bold text-gray-900">Shipping Method</h2>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-bold text-gray-400 uppercase">Status:</span>
                  <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${integration.enabled ? 'bg-green-50 text-green-600' : 'bg-gray-50 text-gray-400'}`}>
                    {integration.enabled ? 'Enabled' : 'Disabled'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <button 
                  onClick={() => setIntegration({...integration, method: 'manual'})}
                  className={`p-6 rounded-2xl border-2 text-left transition-all relative ${integration.method === 'manual' ? 'border-teal-600 bg-teal-50' : 'border-gray-100 hover:border-teal-200'}`}
                >
                  <div className="flex items-center space-x-3 mb-2">
                    <ShieldCheck className={`w-5 h-5 ${integration.method === 'manual' ? 'text-teal-600' : 'text-gray-400'}`} />
                    <h3 className="font-bold text-gray-900">Manual Shipping</h3>
                  </div>
                  <p className="text-xs text-gray-500 leading-relaxed">Enter courier name and tracking ID manually for each order.</p>
                  {integration.method === 'manual' && <CheckCircle2 className="absolute top-4 right-4 w-5 h-5 text-teal-600" />}
                </button>

                <button 
                  onClick={() => setIntegration({...integration, method: 'shiprocket'})}
                  className={`p-6 rounded-2xl border-2 text-left transition-all relative ${integration.method === 'shiprocket' ? 'border-teal-600 bg-teal-50' : 'border-gray-100 hover:border-teal-200'}`}
                >
                  <div className="flex items-center space-x-3 mb-2">
                    <Globe className={`w-5 h-5 ${integration.method === 'shiprocket' ? 'text-teal-600' : 'text-gray-400'}`} />
                    <h3 className="font-bold text-gray-900">Shiprocket API</h3>
                  </div>
                  <p className="text-xs text-gray-500 leading-relaxed">Automate order sync, real-time rates, and tracking ID generation.</p>
                  {integration.method === 'shiprocket' && <CheckCircle2 className="absolute top-4 right-4 w-5 h-5 text-teal-600" />}
                </button>
              </div>

              {integration.method === 'shiprocket' && (
                <div className="space-y-6 pt-6 border-t border-gray-100 animate-in fade-in slide-in-from-top-4 duration-300">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-gray-900 flex items-center space-x-2">
                      <Key className="w-4 h-4 text-teal-600" />
                      <span>API Credentials</span>
                    </h3>
                    <a href="https://app.shiprocket.in/api-user" target="_blank" rel="noopener noreferrer" className="text-[10px] font-bold text-teal-600 flex items-center space-x-1 hover:underline">
                      <span>Get API Keys</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">API Key</label>
                      <input 
                        type="password" 
                        value={integration.apiKey}
                        onChange={(e) => setIntegration({...integration, apiKey: e.target.value})}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                        placeholder="••••••••••••••••"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">API Secret</label>
                      <input 
                        type="password" 
                        value={integration.apiSecret}
                        onChange={(e) => setIntegration({...integration, apiSecret: e.target.value})}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
                        placeholder="••••••••••••••••"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between p-6 bg-gray-50 rounded-2xl border border-gray-100">
                <div className="space-y-1">
                  <p className="text-sm font-bold text-gray-900">Enable Integration</p>
                  <p className="text-[10px] text-gray-500">Activate this shipping method for all new orders</p>
                </div>
                <button 
                  onClick={() => setIntegration({...integration, enabled: !integration.enabled})}
                  className={`w-12 h-6 rounded-full transition-all relative ${integration.enabled ? 'bg-teal-600' : 'bg-gray-300'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${integration.enabled ? 'right-1' : 'left-1'}`} />
                </button>
              </div>
            </section>
          </div>
        </main>
      </div>
    </div>
  );
}
