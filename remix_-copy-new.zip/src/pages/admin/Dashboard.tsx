import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  TrendingUp, 
  ShoppingBag, 
  Users, 
  DollarSign, 
  HelpCircle, 
  Bell, 
  ChevronDown, 
  ExternalLink, 
  Eye,
  Calendar,
  ArrowUpRight,
  Info,
  Megaphone,
  BarChart3
} from 'lucide-react';
import AdminSidebar from '../../components/AdminSidebar';
import { AnalyticsData } from '../../types';
import { apiFetch } from '../../utils/api';

export default function AdminDashboard() {
  const [stats, setStats] = useState<Partial<AnalyticsData> | null>(null);
  const [startDate, setStartDate] = useState('2026-03-01');
  const [endDate, setEndDate] = useState('2026-03-18');

  useEffect(() => {
    apiFetch('/api/admin/stats')
      .then(res => res.json())
      .then(setStats);
  }, []);

  const performanceCards = [
    { title: 'Order Value', value: `₹${stats?.totalSales?.toLocaleString() || '2.0K'}`, trend: 'neutral', icon: DollarSign },
    { title: 'Total Orders', value: stats?.totalOrders || '2', trend: 'neutral', icon: ShoppingBag },
    { title: 'Website Visits', value: '21', trend: '+10.5%', icon: Users },
    { title: 'Conversion Rate', value: 'No data', trend: 'NA', icon: TrendingUp },
  ];

  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar />
      
      <div className="flex-1 ml-64">
        {/* Topbar */}
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 sticky top-0 z-40">
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium text-gray-500 uppercase tracking-wider">SmartBiz</span>
          </div>
          
          <div className="flex items-center space-x-6">
            <button className="text-gray-400 hover:text-gray-600">
              <HelpCircle className="w-5 h-5" />
            </button>
            <button className="text-gray-400 hover:text-gray-600 relative">
              <Bell className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
            <div className="flex items-center space-x-3 pl-6 border-l border-gray-200 cursor-pointer group">
              <div className="w-8 h-8 bg-teal-100 rounded-full flex items-center justify-center text-teal-700 font-bold text-xs">
                VS
              </div>
              <div className="flex items-center space-x-1">
                <span className="text-sm font-semibold text-gray-700">V STORE ONLINE</span>
                <ChevronDown className="w-4 h-4 text-gray-400 group-hover:text-gray-600" />
              </div>
            </div>
          </div>
        </header>

        <main className="p-8 space-y-8 max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <h1 className="text-2xl font-bold text-gray-900">Welcome, V STORE ONLINE</h1>
              <p className="text-sm text-gray-500">Here's what's happening with your store today.</p>
            </div>
            <div className="flex items-center space-x-3">
              <button className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
                <ExternalLink className="w-4 h-4" />
                <span>View Your Website</span>
              </button>
              <button className="p-2 bg-white border border-gray-200 rounded-lg text-gray-500 hover:bg-gray-50 transition-colors">
                <Eye className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Date Filter */}
          <div className="bg-white p-4 rounded-xl border border-gray-200 flex flex-wrap items-center gap-4">
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <Calendar className="w-4 h-4" />
              <span>Filter by date:</span>
            </div>
            <div className="flex items-center space-x-2">
              <input 
                type="date" 
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
              />
              <span className="text-gray-400">to</span>
              <input 
                type="date" 
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500"
              />
            </div>
          </div>

          {/* Performance Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {performanceCards.map((card, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="p-2 bg-teal-50 rounded-lg">
                    <card.icon className="w-5 h-5 text-teal-600" />
                  </div>
                  {card.trend !== 'neutral' && card.trend !== 'NA' && (
                    <div className="flex items-center space-x-1 text-xs font-bold text-green-600 bg-green-50 px-2 py-1 rounded-full">
                      <ArrowUpRight className="w-3 h-3" />
                      <span>{card.trend}</span>
                    </div>
                  )}
                  {card.trend === 'neutral' && (
                    <span className="text-xs font-medium text-gray-400 bg-gray-50 px-2 py-1 rounded-full">Neutral</span>
                  )}
                  {card.trend === 'NA' && (
                    <span className="text-xs font-medium text-gray-400 bg-gray-50 px-2 py-1 rounded-full">N/A</span>
                  )}
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500 mb-1">{card.title}</p>
                  <p className="text-2xl font-bold text-gray-900">{card.value}</p>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content Area */}
            <div className="lg:col-span-2 space-y-8">
              <div className="bg-white p-8 rounded-2xl border border-gray-200 shadow-sm h-96 flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center">
                  <BarChart3 className="w-8 h-8 text-gray-300" />
                </div>
                <div>
                  <p className="text-lg font-semibold text-gray-900">Sales Overview</p>
                  <p className="text-sm text-gray-500 max-w-xs mx-auto">Detailed sales analytics will appear here once you have more order data.</p>
                </div>
              </div>
            </div>

            {/* Sidebar Content Area */}
            <div className="space-y-8">
              {/* Announcement Panel */}
              <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
                <div className="p-4 bg-teal-50 border-b border-teal-100 flex items-center space-x-2">
                  <Megaphone className="w-4 h-4 text-teal-600" />
                  <h3 className="font-bold text-teal-900 text-sm">Announcement</h3>
                </div>
                <div className="p-6 space-y-6">
                  <div className="space-y-2">
                    <p className="text-sm font-semibold text-gray-900">Check for updates and new features</p>
                    <p className="text-xs text-gray-500 leading-relaxed">We've just released a new set of growth tools to help you scale your business faster.</p>
                  </div>
                  
                  <div className="relative rounded-xl overflow-hidden aspect-video group cursor-pointer">
                    <img 
                      src="https://picsum.photos/seed/webinar/400/225" 
                      alt="Webinar" 
                      className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex flex-col justify-end p-4">
                      <p className="text-white font-bold text-sm">Upcoming Webinar</p>
                      <p className="text-white/80 text-xs">Learn how to reduce RTO</p>
                    </div>
                  </div>

                  <div className="p-4 bg-blue-50 rounded-xl flex items-start space-x-3">
                    <Info className="w-4 h-4 text-blue-600 mt-0.5" />
                    <p className="text-xs text-blue-700 leading-relaxed">
                      Complete your store configuration to unlock more features and trust markers.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
