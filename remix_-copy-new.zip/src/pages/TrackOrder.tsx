import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Package, Truck, CheckCircle, Clock, AlertCircle, ChevronRight, MapPin, Calendar, CreditCard, ArrowLeft, Zap } from 'lucide-react';
import { Order } from '../types';
import toast from 'react-hot-toast';

const STEPS = [
  { status: 'pending', label: 'Order Placed', icon: Clock },
  { status: 'accepted', label: 'Order Confirmed', icon: CheckCircle },
  { status: 'shipped', label: 'Order Shipped', icon: Truck },
  { status: 'pickup_ready', label: 'Out for Delivery', icon: Package },
  { status: 'fulfilled', label: 'Delivered', icon: CheckCircle },
];

const RETURN_STEPS = [
  { status: 'return_initiated', label: 'Return Initiated', icon: Clock },
  { status: 'pickup_scheduled', label: 'Pickup Scheduled', icon: Calendar },
  { status: 'pickup_completed', label: 'Pickup Completed', icon: Truck },
  { status: 'return_successful', label: 'Return Successful', icon: CheckCircle },
  { status: 'refund_processed', label: 'Refund Processed', icon: CreditCard },
];

export default function TrackOrder() {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query) return;

    // Validation
    if (/^\d+$/.test(query) && query.length !== 10) {
      toast.error('Mobile number must be 10 digits');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`/api/orders/track?query=${encodeURIComponent(query)}`);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || 'Failed to track order');
      }
      const data = await res.json();
      setOrders(data);
      if (data.length === 1) {
        setSelectedOrder(data[0]);
      } else {
        setSelectedOrder(null);
      }
    } catch (err: any) {
      toast.error(err.message);
      setOrders(null);
      setSelectedOrder(null);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIndex = (status: string, steps: typeof STEPS) => {
    return steps.findIndex(s => s.status === status);
  };

  const isReturnFlow = (status: string) => {
    return RETURN_STEPS.some(s => s.status === status);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 sm:px-6 lg:px-8 space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-gray-900 tracking-tight">Track Your Order</h1>
        <p className="text-gray-500 max-w-md mx-auto">Enter your Order ID or Mobile Number to see real-time status updates.</p>
      </div>

      <section className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
        <form onSubmit={handleTrack} className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Enter Mobile Number or Order ID (e.g. ORD-000001)"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all font-medium"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="px-8 py-4 bg-teal-600 text-white rounded-2xl font-bold hover:bg-teal-700 transition-all shadow-lg shadow-teal-100 disabled:opacity-50 flex items-center justify-center space-x-2 min-w-[160px]"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <span>Track Order</span>
            )}
          </button>
        </form>
      </section>

      <AnimatePresence mode="wait">
        {orders && !selectedOrder && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-4"
          >
            <h2 className="text-lg font-bold text-gray-900 px-2">Found {orders.length} orders</h2>
            <div className="grid grid-cols-1 gap-4">
              {orders.map((order) => (
                <button
                  key={order.id}
                  onClick={() => setSelectedOrder(order)}
                  className="flex items-center justify-between p-6 bg-white rounded-3xl border border-gray-100 hover:border-teal-500 hover:shadow-md transition-all text-left group"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-teal-50 rounded-2xl flex items-center justify-center text-teal-600">
                      <Package className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-bold text-gray-900">#ORD-{order.id.toString().padStart(6, '0')}</p>
                      <p className="text-xs text-gray-500">{new Date(order.created_at).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-right hidden sm:block">
                      <p className="text-sm font-bold text-gray-900 uppercase">{order.delivery_status.replace(/_/g, ' ')}</p>
                      <p className="text-xs text-gray-500">₹{order.total_amount.toFixed(0)}</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-300 group-hover:text-teal-500 transition-colors" />
                  </div>
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {selectedOrder && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-8"
          >
            {orders && orders.length > 1 && (
              <button
                onClick={() => setSelectedOrder(null)}
                className="flex items-center space-x-2 text-sm font-bold text-teal-600 hover:text-teal-700 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to results</span>
              </button>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Order Info */}
              <div className="lg:col-span-2 space-y-8">
                <section className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 space-y-8">
                  <div className="flex flex-wrap justify-between items-start gap-4">
                    <div className="space-y-1">
                      <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Order Status</p>
                      <h2 className="text-2xl font-bold text-gray-900 uppercase">
                        {selectedOrder.delivery_status.replace(/_/g, ' ')}
                      </h2>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Order ID</p>
                      <p className="text-lg font-mono font-bold text-teal-600">#ORD-{selectedOrder.id.toString().padStart(6, '0')}</p>
                    </div>
                  </div>

                  {/* Vertical Timeline */}
                  <div className="relative pl-8 space-y-8">
                    <div className="absolute left-[15px] top-2 bottom-2 w-0.5 bg-gray-100" />
                    
                    {(isReturnFlow(selectedOrder.delivery_status) ? RETURN_STEPS : STEPS).map((step, idx) => {
                      const currentIdx = getStatusIndex(selectedOrder.delivery_status, isReturnFlow(selectedOrder.delivery_status) ? RETURN_STEPS : STEPS);
                      const isCompleted = idx <= currentIdx;
                      const isCurrent = idx === currentIdx;
                      const Icon = step.icon;

                      return (
                        <div key={step.status} className="relative flex items-start space-x-4">
                          <div className={cn(
                            "absolute -left-8 w-8 h-8 rounded-full border-4 border-white flex items-center justify-center z-10 transition-all duration-500",
                            isCompleted ? "bg-teal-600 text-white" : "bg-gray-100 text-gray-400"
                          )}>
                            <Icon className={cn("w-4 h-4", isCurrent && "animate-pulse")} />
                          </div>
                          <div className="space-y-1">
                            <p className={cn(
                              "font-bold transition-colors",
                              isCompleted ? "text-gray-900" : "text-gray-400"
                            )}>
                              {step.label}
                            </p>
                            {isCurrent && (
                              <p className="text-xs text-teal-600 font-medium">Your order is currently here</p>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </section>

                {/* Items */}
                <section className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 space-y-6">
                  <h3 className="text-lg font-bold text-gray-900">Order Items</h3>
                  <div className="space-y-4">
                    {selectedOrder.items?.map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl border border-gray-100">
                        <div className="flex items-center space-x-4">
                          <img src={item.product_image} alt={item.product_name} className="w-16 h-16 rounded-xl object-cover border border-gray-200" />
                          <div>
                            <p className="font-bold text-gray-900">{item.product_name}</p>
                            <p className="text-sm text-gray-500">Qty: {item.quantity}</p>
                          </div>
                        </div>
                        <p className="font-bold text-gray-900">₹{item.price.toFixed(0)}</p>
                      </div>
                    ))}
                  </div>
                </section>
              </div>

              {/* Sidebar Info */}
              <div className="space-y-8">
                {/* Tracking Details */}
                {(selectedOrder as any).tracking_id && (
                  <section className="bg-teal-600 p-8 rounded-3xl shadow-lg shadow-teal-100 text-white space-y-6">
                    <div className="flex items-center space-x-3">
                      <Truck className="w-6 h-6" />
                      <h3 className="text-lg font-bold">Tracking Details</h3>
                    </div>
                    <div className="space-y-4">
                      <div>
                        <p className="text-xs font-bold text-teal-200 uppercase tracking-wider">Courier Partner</p>
                        <p className="font-bold">{(selectedOrder as any).courier_name || 'Shiprocket'}</p>
                      </div>
                      <div>
                        <p className="text-xs font-bold text-teal-200 uppercase tracking-wider">Tracking ID</p>
                        <p className="font-mono font-bold">{(selectedOrder as any).tracking_id}</p>
                      </div>
                      {(selectedOrder as any).estimated_delivery_date && (
                        <div>
                          <p className="text-xs font-bold text-teal-200 uppercase tracking-wider">Estimated Delivery</p>
                          <p className="font-bold">{new Date((selectedOrder as any).estimated_delivery_date).toLocaleDateString()}</p>
                        </div>
                      )}
                    </div>
                  </section>
                )}

                {/* Delivery Address */}
                <section className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 space-y-4">
                  <div className="flex items-center space-x-3 text-gray-400">
                    <MapPin className="w-5 h-5" />
                    <h3 className="text-sm font-bold uppercase tracking-wider">Delivery Address</h3>
                  </div>
                  <p className="text-sm text-gray-600 leading-relaxed font-medium">
                    {selectedOrder.address}
                  </p>
                </section>

                {/* Payment Info */}
                <section className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 space-y-4">
                  <div className="flex items-center space-x-3 text-gray-400">
                    <CreditCard className="w-5 h-5" />
                    <h3 className="text-sm font-bold uppercase tracking-wider">Payment Details</h3>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Method</span>
                      <span className="font-bold text-gray-900 uppercase">{selectedOrder.payment_method}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Status</span>
                      <span className={cn(
                        "font-bold uppercase",
                        selectedOrder.payment_status === 'paid' ? "text-green-600" : "text-orange-600"
                      )}>{selectedOrder.payment_status}</span>
                    </div>
                    <div className="flex justify-between text-lg font-bold text-gray-900 pt-2 border-t border-gray-50">
                      <span>Total</span>
                      <span>₹{selectedOrder.total_amount.toFixed(0)}</span>
                    </div>
                  </div>
                </section>

                {/* Refund Info */}
                {selectedOrder.delivery_status === 'refund_processed' && (
                  <section className="bg-green-50 p-6 rounded-3xl border border-green-100 space-y-3">
                    <div className="flex items-center space-x-2 text-green-600">
                      <CheckCircle className="w-5 h-5" />
                      <h3 className="font-bold">Refund Processed</h3>
                    </div>
                    <p className="text-xs text-green-700 leading-relaxed">
                      Your refund has been processed. 
                      {selectedOrder.payment_method === 'COD' ? 
                        ' It has been credited to your bank account/wallet.' : 
                        ' It will reflect in your original payment method within 5-7 business days.'}
                    </p>
                  </section>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {!orders && !loading && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-12">
          {[
            { icon: ShieldCheck, title: 'Secure Tracking', desc: 'Real-time updates from our courier partners.' },
            { icon: Zap, title: 'Fast Updates', desc: 'Get notified via SMS and Email at every step.' },
            { icon: AlertCircle, title: 'Easy Returns', desc: 'Track your returns and refunds in one place.' }
          ].map((feature, idx) => (
            <div key={idx} className="p-8 bg-white rounded-3xl border border-gray-100 text-center space-y-4">
              <div className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center text-teal-600 mx-auto">
                <feature.icon className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-gray-900">{feature.title}</h3>
              <p className="text-sm text-gray-500">{feature.desc}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}

function ShieldCheck(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
      <path d="m9 12 2 2 4-4" />
    </svg>
  );
}
