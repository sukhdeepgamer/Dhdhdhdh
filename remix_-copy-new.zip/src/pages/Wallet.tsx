import React, { useState, useEffect } from 'react';
import { 
  Wallet, 
  ArrowUpRight, 
  ArrowDownRight, 
  History, 
  Info, 
  ChevronRight,
  CreditCard,
  Gift,
  ShieldCheck
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { WalletTransaction } from '../types';
import { motion } from 'motion/react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { apiFetch } from '../utils/api';

export default function UserWallet() {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchTransactions();
    }
  }, [user]);

  const fetchTransactions = async () => {
    setLoading(true);
    try {
      const res = await apiFetch('/api/user/wallet/transactions');
      const data = await res.json();
      setTransactions(data || []);
    } catch (error) {
      console.error('Failed to fetch transactions:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-500">Please login to view your wallet.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <Navbar />
      
      <main className="max-w-4xl mx-auto px-4 py-12 space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <h1 className="text-3xl font-bold text-gray-900">V Wallet</h1>
            <p className="text-sm text-gray-500">Manage your points and view transaction history.</p>
          </div>
          <div className="flex items-center space-x-2 px-4 py-2 bg-teal-50 rounded-full text-teal-700 text-xs font-bold border border-teal-100">
            <ShieldCheck className="w-4 h-4" />
            <span>100% Secure & Verified</span>
          </div>
        </div>

        {/* Wallet Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden bg-teal-600 rounded-[32px] p-8 text-white shadow-2xl shadow-teal-100"
        >
          {/* Abstract Background Shapes */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-teal-400/20 rounded-full translate-y-1/2 -translate-x-1/2 blur-2xl" />

          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
            <div className="space-y-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center">
                  <Wallet className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-xs font-bold text-teal-100 uppercase tracking-widest">Available Balance</p>
                  <p className="text-4xl font-black tracking-tight">₹{user.walletBalance || 0}</p>
                </div>
              </div>
              <div className="flex items-center space-x-6">
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-teal-100 uppercase tracking-widest">Points Value</p>
                  <p className="text-lg font-bold">{user.walletBalance || 0} Points</p>
                </div>
                <div className="w-px h-8 bg-white/20" />
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-teal-100 uppercase tracking-widest">Conversion</p>
                  <p className="text-lg font-bold">1 Pt = ₹1</p>
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-3">
              <button className="px-8 py-4 bg-white text-teal-600 rounded-2xl font-bold text-sm hover:bg-teal-50 transition-colors shadow-lg shadow-black/5">
                Redeem for Orders
              </button>
              <p className="text-[10px] text-teal-100 text-center font-medium">Use points during checkout to get discounts</p>
            </div>
          </div>
        </motion.div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow cursor-pointer group">
            <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Gift className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="font-bold text-gray-900 mb-1">Earn Rewards</h3>
            <p className="text-xs text-gray-500">Complete tasks and earn more V points.</p>
          </div>
          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow cursor-pointer group">
            <div className="w-12 h-12 bg-purple-50 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <CreditCard className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="font-bold text-gray-900 mb-1">Refer & Earn</h3>
            <p className="text-xs text-gray-500">Invite friends and get ₹50 per referral.</p>
          </div>
          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow cursor-pointer group">
            <div className="w-12 h-12 bg-orange-50 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Info className="w-6 h-6 text-orange-600" />
            </div>
            <h3 className="font-bold text-gray-900 mb-1">Wallet Policy</h3>
            <p className="text-xs text-gray-500">Understand how V Wallet points work.</p>
          </div>
        </div>

        {/* Transaction History */}
        <div className="bg-white rounded-[32px] border border-gray-100 shadow-sm overflow-hidden">
          <div className="p-8 border-b border-gray-50 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center">
                <History className="w-5 h-5 text-gray-400" />
              </div>
              <h2 className="text-lg font-bold text-gray-900">Transaction History</h2>
            </div>
            <button className="text-xs font-bold text-teal-600 hover:text-teal-700 uppercase tracking-widest">Download Statement</button>
          </div>

          <div className="divide-y divide-gray-50">
            {loading ? (
              <div className="p-12 text-center space-y-4">
                <div className="w-12 h-12 border-4 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto" />
                <p className="text-sm text-gray-500 font-medium">Fetching your history...</p>
              </div>
            ) : transactions.length === 0 ? (
              <div className="p-12 text-center space-y-4">
                <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto">
                  <Wallet className="w-8 h-8 text-gray-300" />
                </div>
                <div>
                  <p className="text-lg font-bold text-gray-900">No transactions yet</p>
                  <p className="text-sm text-gray-500">Your wallet activity will appear here.</p>
                </div>
              </div>
            ) : (
              transactions.map((transaction) => (
                <div key={transaction.id} className="p-6 flex items-center justify-between hover:bg-gray-50/50 transition-colors group">
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-105 ${
                      transaction.type === 'credit' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'
                    }`}>
                      {transaction.type === 'credit' ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownRight className="w-5 h-5" />}
                    </div>
                    <div>
                      <p className="font-bold text-gray-900">{transaction.reason}</p>
                      <p className="text-xs text-gray-500 font-medium">
                        {new Date(transaction.createdAt).toLocaleDateString('en-IN', { 
                          day: 'numeric', 
                          month: 'short', 
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                        {transaction.orderId && ` • Order #${transaction.orderId}`}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-lg font-black ${
                      transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {transaction.type === 'credit' ? '+' : ''}{transaction.amount}
                    </p>
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Points</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* FAQ Section */}
        <div className="bg-teal-50 rounded-3xl p-8 border border-teal-100">
          <h3 className="text-sm font-bold text-teal-900 mb-6 uppercase tracking-widest">Frequently Asked Questions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-2">
              <p className="text-sm font-bold text-teal-800">How do I use my points?</p>
              <p className="text-xs text-teal-600 leading-relaxed">You can apply your V Wallet points during the checkout process. Simply select the "Use V Wallet Balance" option before proceeding to payment.</p>
            </div>
            <div className="space-y-2">
              <p className="text-sm font-bold text-teal-800">Do points expire?</p>
              <p className="text-xs text-teal-600 leading-relaxed">V Wallet points earned through purchases or rewards are valid for 365 days from the date of credit. Bonus points may have different expiry dates.</p>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
