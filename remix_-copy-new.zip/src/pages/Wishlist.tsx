import { motion } from 'motion/react';
import { ShoppingCart, Heart, Trash2, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useWishlist } from '../contexts/WishlistContext';
import { useCart } from '../contexts/CartContext';

export default function Wishlist() {
  const { wishlist, removeFromWishlist } = useWishlist();
  const { addToCart } = useCart();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="space-y-2 mb-12">
        <h1 className="text-4xl font-black tracking-tighter text-black">My Wishlist</h1>
        <p className="text-gray-500 font-medium">Items you've saved for later</p>
      </div>

      {wishlist.length === 0 ? (
        <div className="text-center py-32 bg-white rounded-3xl border border-gray-100 shadow-sm">
          <div className="max-w-xs mx-auto space-y-6">
            <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mx-auto">
              <Heart className="w-10 h-10 text-gray-200" />
            </div>
            <div className="space-y-2">
              <h3 className="text-2xl font-black tracking-tight text-black">Your wishlist is empty</h3>
              <p className="text-gray-500 font-medium">Start adding items you love to your wishlist!</p>
            </div>
            <Link
              to="/products"
              className="inline-flex items-center space-x-2 px-8 py-3 bg-black text-white rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-gray-800 transition-all"
            >
              <span>Explore Tech</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {wishlist.map((product) => (
            <motion.div
              key={product.id}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="group bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500"
            >
              <div className="relative aspect-[4/5] overflow-hidden bg-gray-50">
                <img
                  src={product.image_url}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <button
                  onClick={() => removeFromWishlist(product.id)}
                  className="absolute top-6 right-6 p-3 bg-white/80 backdrop-blur-xl text-red-500 rounded-2xl hover:bg-red-500 hover:text-white transition-all shadow-xl"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
              <div className="p-8 space-y-4">
                <div className="space-y-1">
                  <div className="text-[10px] font-black text-gray-300 uppercase tracking-[0.2em]">
                    {product.category}
                  </div>
                  <h3 className="font-bold text-black text-xl leading-tight group-hover:text-gray-600 transition-colors">
                    {product.name}
                  </h3>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="text-2xl font-black text-black">
                      ₹{(product.price * (1 - product.discount / 100)).toLocaleString()}
                    </span>
                    {product.discount > 0 && (
                      <span className="text-sm text-gray-300 line-through font-medium">₹{product.price.toLocaleString()}</span>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => addToCart(product)}
                  className="w-full py-4 bg-black text-white rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-gray-800 transition-all flex items-center justify-center space-x-2"
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>Add to Cart</span>
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
