import { useState, useEffect, useRef, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ShoppingCart, Star, Zap, Clock, Search, ArrowRight, Smartphone, Laptop, Headphones, Watch, Heart, Loader2, Home as HomeIcon, Gem, Shirt, Tv } from 'lucide-react';
import { Product } from '../types';
import { useCart } from '../contexts/CartContext';
import { useWishlist } from '../contexts/WishlistContext';
import Carousel from '../components/Carousel';
import ProductCard from '../components/ProductCard';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function Home() {
  const [products, setProducts] = useState<Product[]>([]);
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [offset, setOffset] = useState(0);
  const [categories, setCategories] = useState<string[]>([]);
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const limit = 8;

  const observer = useRef<IntersectionObserver | null>(null);
  const lastProductElementRef = useCallback((node: HTMLDivElement | null) => {
    if (loading || loadingMore) return;
    if (observer.current) observer.current.disconnect();
    observer.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) {
        setOffset(prev => prev + limit);
      }
    });
    if (node) observer.current.observe(node);
  }, [loading, loadingMore, hasMore]);

  useEffect(() => {
    fetch('/api/categories')
      .then(res => res.json())
      .then(data => setCategories(data));

    // Fetch all products for category sections
    fetch('/api/products')
      .then(res => res.json())
      .then(data => {
        if (data && Array.isArray(data.products)) {
          setAllProducts(data.products);
        } else {
          setAllProducts([]);
        }
      })
      .catch(() => setAllProducts([]));
  }, []);

  useEffect(() => {
    const fetchProducts = async () => {
      const isInitial = offset === 0;
      if (isInitial) setLoading(true);
      else setLoadingMore(true);

      try {
        const res = await fetch(`/api/products?limit=${limit}&offset=${offset}`);
        const data = await res.json();
        
        const newProducts = Array.isArray(data.products) ? data.products : [];
        setProducts(prev => isInitial ? newProducts : [...prev, ...newProducts]);
        setHasMore(newProducts.length === limit);
      } catch (error) {
        console.error('Error fetching products:', error);
      } finally {
        setLoading(false);
        setLoadingMore(false);
      }
    };

    fetchProducts();
  }, [offset]);

  const getProductsByCategory = (category: string) => {
    return allProducts.filter(p => p.category === category).slice(0, 4);
  };

  const categoryIcons: Record<string, any> = {
    'Mobiles': Smartphone,
    'Laptops': Laptop,
    'Audio': Headphones,
    'Wearables': Watch,
    'Home Appliances': Tv,
    'Jewelry': Gem,
    'Fashion': Shirt
  };

  const [searchQuery, setSearchQuery] = useState('');

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-16 pb-20 bg-gray-50/50">
      {/* Hero Carousel */}
      <Carousel />

      {/* Categories Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-3xl font-black tracking-tighter text-black">Shop by Category</h2>
            <p className="text-gray-500 font-medium">Explore our premium collections</p>
          </div>
          <Link to="/products" className="group flex items-center space-x-2 text-xs font-black uppercase tracking-widest text-black hover:text-gray-600 transition-colors">
            <span>See All</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
          {['Mobiles', 'Laptops', 'Gaming', 'Audio', 'Home Appliances', 'Jewelry', 'Fashion'].map((cat) => {
            const Icon = categoryIcons[cat] || Smartphone;
            return (
              <Link
                key={cat}
                to={`/products?category=${cat}`}
                className="group relative h-40 bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-2xl hover:-translate-y-2 transition-all duration-500"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-gray-50 to-white group-hover:from-black group-hover:to-gray-800 transition-colors duration-500" />
                <div className="relative h-full flex flex-col items-center justify-center space-y-3">
                  <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center group-hover:bg-white/10 transition-colors">
                    <Icon className="w-6 h-6 text-black group-hover:text-white transition-colors" />
                  </div>
                  <span className="text-[10px] font-black uppercase tracking-widest text-gray-400 group-hover:text-white transition-colors text-center px-2">
                    {cat}
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { icon: Zap, title: 'Express Delivery', desc: 'Tech at your door in 24 hours', color: 'bg-yellow-400' },
            { icon: Star, title: 'Official Warranty', desc: '100% genuine products guaranteed', color: 'bg-blue-500' },
            { icon: Clock, title: '24/7 Support', desc: 'Expert tech assistance anytime', color: 'bg-emerald-500' },
          ].map((feature, i) => (
            <div key={i} className="p-8 bg-white rounded-[2.5rem] border border-gray-100 shadow-sm flex items-center space-x-6 hover:shadow-xl transition-all">
              <div className={cn("p-4 rounded-2xl text-white shadow-lg", feature.color)}>
                <feature.icon className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-black text-lg text-black">{feature.title}</h3>
                <p className="text-gray-500 text-sm font-medium">{feature.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex justify-between items-end">
          <div>
            <h2 className="text-3xl font-black tracking-tighter text-black">Featured Collection</h2>
            <p className="text-gray-500 font-medium">Discover our latest arrivals</p>
          </div>
          <Link to="/products" className="group flex items-center space-x-2 text-xs font-black uppercase tracking-widest text-black hover:text-gray-600 transition-colors">
            <span>See All</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {loading && offset === 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="animate-pulse bg-white rounded-2xl h-[400px] border border-gray-100" />
            ))}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {products.map((product, index) => (
                <ProductCard 
                  key={product.id}
                  product={product}
                  refElement={index === products.length - 1 ? lastProductElementRef : undefined}
                />
              ))}
            </div>

            {/* Loader for Infinite Scroll */}
            {loadingMore && (
              <div className="flex justify-center py-12">
                <div className="flex items-center space-x-3 text-gray-400">
                  <Loader2 className="w-6 h-6 animate-spin" />
                  <span className="text-xs font-black uppercase tracking-widest">Loading more...</span>
                </div>
              </div>
            )}

            {!hasMore && products.length > 0 && (
              <div className="text-center py-12">
                <p className="text-xs font-black uppercase tracking-widest text-gray-300">You've reached the end of the collection</p>
              </div>
            )}
          </>
        )}
      </section>

      {/* Category Wise Sections */}
      {['Home Appliances', 'Jewelry', 'Mobiles', 'Laptops'].map((cat) => {
        const catProducts = getProductsByCategory(cat);
        if (catProducts.length === 0) return null;
        return (
          <section key={cat} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
            <div className="flex justify-between items-end">
              <div>
                <h2 className="text-3xl font-black tracking-tighter text-black">{cat}</h2>
                <p className="text-gray-500 font-medium">Top picks in {cat}</p>
              </div>
              <Link to={`/products?category=${cat}`} className="group flex items-center space-x-2 text-xs font-black uppercase tracking-widest text-black hover:text-gray-600 transition-colors">
                <span>See All</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {catProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </section>
        );
      })}

      {/* Newsletter / Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative h-96 bg-black rounded-[3rem] overflow-hidden flex items-center px-12">
          <div className="absolute inset-0 opacity-50">
            <img 
              src="https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=2000" 
              alt="Tech Banner" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="relative max-w-xl space-y-6">
            <h2 className="text-5xl font-black tracking-tighter text-white leading-none">
              Join the <br /> Tech Revolution.
            </h2>
            <p className="text-gray-400 font-medium text-lg">
              Subscribe to get early access to new drops and exclusive member-only tech deals.
            </p>
            <div className="flex space-x-2">
              <input 
                type="email" 
                placeholder="Enter your email" 
                className="flex-1 bg-white/10 border border-white/20 rounded-2xl px-6 py-4 text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-white/50 transition-all"
              />
              <button className="px-8 py-4 bg-white text-black rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-gray-200 transition-colors">
                Join
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
