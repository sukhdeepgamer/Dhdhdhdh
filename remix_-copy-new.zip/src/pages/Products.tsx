import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingCart, Search, Filter, SlidersHorizontal, ChevronRight, Smartphone, Laptop, Headphones, Watch, Tablet, Gamepad2, Camera, Drone, Loader2, Heart } from 'lucide-react';
import { Product } from '../types';
import { useCart } from '../contexts/CartContext';
import { useWishlist } from '../contexts/WishlistContext';
import { useSearchParams } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function Products() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [offset, setOffset] = useState(0);
  const [categories, setCategories] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [maxPrice, setMaxPrice] = useState(200000);
  const selectedCategory = searchParams.get('category') || 'All';
  const limit = 12;

  const observer = useRef<IntersectionObserver | null>(null);
  const lastProductElementRef = useCallback((node: HTMLDivElement | null) => {
    if (loading || loadingMore) return;
    if (observer.current) observer.current.disconnect();
    observer.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) {
        setOffset(prev => prev + limit);
      }
    });
    if (node) observer.current.observe(node);
  }, [loading, loadingMore, hasMore]);

  useEffect(() => {
    fetch('/api/get-categories')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setCategories(['All', ...data]);
        } else {
          setCategories(['All']);
        }
      })
      .catch(() => setCategories(['All']));
  }, []);

  useEffect(() => {
    setLoading(true);
    setOffset(0);
    setProducts([]);
    setHasMore(true);
  }, [selectedCategory, searchQuery, maxPrice]);

  useEffect(() => {
    const fetchProducts = async () => {
      const isInitial = offset === 0;
      if (isInitial) setLoading(true);
      else setLoadingMore(true);

      try {
        const params = new URLSearchParams({
          limit: limit.toString(),
          offset: offset.toString(),
          maxPrice: maxPrice.toString(),
          ...(selectedCategory !== 'All' && { category: selectedCategory }),
          ...(searchQuery && { search: searchQuery })
        });

        const res = await fetch(`/api/get-products?${params}`);
        const data = await res.json();
        
        const newProducts = Array.isArray(data.products) ? data.products : [];
        setProducts(prev => isInitial ? newProducts : [...prev, ...newProducts]);
        setHasMore(newProducts.length === limit);
      } catch (error) {
        console.error('Error fetching products:', error);
      } finally {
        setLoading(false);
        setLoadingMore(false);
      }
    };

    fetchProducts();
  }, [offset, selectedCategory, searchQuery, maxPrice]);

  const categoryIcons: Record<string, any> = {
    'Mobiles': Smartphone,
    'Laptops': Laptop,
    'Audio': Headphones,
    'Wearables': Watch,
    'Tablets': Tablet,
    'Gaming': Gamepad2,
    'Cameras': Camera,
    'Drones': Drone
  };

  const handleCategoryChange = (cat: string) => {
    if (cat === 'All') {
      searchParams.delete('category');
    } else {
      searchParams.set('category', cat);
    }
    setSearchParams(searchParams);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col lg:flex-row gap-12">
        {/* Sidebar Filters */}
        <aside className="lg:w-64 flex-shrink-0 space-y-10">
          <div className="space-y-6">
            <h3 className="text-xs font-black uppercase tracking-[0.2em] text-gray-400">Categories</h3>
            <div className="space-y-2">
              {categories.map((cat) => {
                const Icon = categoryIcons[cat] || Smartphone;
                const isActive = selectedCategory === cat;
                return (
                  <button
                    key={cat}
                    onClick={() => handleCategoryChange(cat)}
                    className={cn(
                      "w-full flex items-center justify-between px-4 py-3 rounded-2xl transition-all duration-300 group",
                      isActive ? "bg-black text-white shadow-xl shadow-black/10" : "hover:bg-gray-100 text-gray-600"
                    )}
                  >
                    <div className="flex items-center space-x-3">
                      {cat !== 'All' && <Icon className={cn("w-4 h-4", isActive ? "text-white" : "text-gray-400 group-hover:text-black")} />}
                      <span className="text-sm font-bold">{cat}</span>
                    </div>
                    {isActive && <ChevronRight className="w-4 h-4" />}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="space-y-6">
            <h3 className="text-xs font-black uppercase tracking-[0.2em] text-gray-400">Price Range</h3>
            <div className="space-y-4">
              <input 
                type="range" 
                min="0" 
                max="500000" 
                step="1000"
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-full accent-black cursor-pointer" 
              />
              <div className="flex justify-between text-xs font-black text-gray-400">
                <span>₹0</span>
                <span className="text-black">Up to ₹{maxPrice.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
            <div>
              <h1 className="text-4xl font-black tracking-tighter text-black">
                {selectedCategory === 'All' ? 'All Products' : selectedCategory}
              </h1>
              <p className="text-gray-500 font-medium">Discover the future of technology</p>
            </div>

            <div className="relative group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5 group-focus-within:text-black transition-colors" />
              <input
                type="text"
                placeholder="Search tech..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full sm:w-64 pl-12 pr-4 py-3 bg-gray-100 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-black focus:bg-white transition-all font-medium"
              />
            </div>
          </div>

          {loading && offset === 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-8">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="animate-pulse bg-white rounded-2xl h-[300px] sm:h-[450px] border border-gray-100 shadow-sm" />
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-32 bg-white rounded-3xl border border-gray-100 shadow-sm">
              <div className="max-w-xs mx-auto space-y-6">
                <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mx-auto">
                  <Search className="w-10 h-10 text-gray-200" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-2xl font-black tracking-tight text-black">No tech found</h3>
                  <p className="text-gray-500 font-medium">Try adjusting your filters or search query.</p>
                </div>
                <button
                  onClick={() => { setSearchQuery(''); handleCategoryChange('All'); }}
                  className="px-8 py-3 bg-black text-white rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-gray-800 transition-all"
                >
                  Clear all filters
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-8">
                {products.map((product, index) => (
                  <ProductCard 
                    key={product.id}
                    product={product}
                    refElement={index === products.length - 1 ? lastProductElementRef : undefined}
                  />
                ))}
              </div>

              {/* Loader for Infinite Scroll */}
              {loadingMore && (
                <div className="flex justify-center py-12">
                  <div className="flex items-center space-x-3 text-gray-400">
                    <Loader2 className="w-6 h-6 animate-spin" />
                    <span className="text-xs font-black uppercase tracking-widest">Loading more tech...</span>
                  </div>
                </div>
              )}

              {!hasMore && products.length > 0 && (
                <div className="text-center py-12">
                  <p className="text-xs font-black uppercase tracking-widest text-gray-300">You've reached the end of the collection</p>
                </div>
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
