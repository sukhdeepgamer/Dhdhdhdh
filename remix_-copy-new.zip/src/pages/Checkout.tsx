import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, CreditCard, Truck, CheckCircle, User, AlertCircle, ShieldCheck, Info, Tag, Percent, Receipt, Plus, Home, Briefcase, MoreHorizontal, Edit2, Trash2, ChevronRight, Wallet } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { RTORule, DeliverySettings, Offer, TaxRule, Address } from '../types';
import AddressForm from '../components/AddressForm';
import toast from 'react-hot-toast';
import { apiFetch } from '../utils/api';

declare const Razorpay: any;

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}

export default function Checkout() {
  const { items, clearCart } = useCart();
  const { user, refreshUser } = useAuth();
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [selectedAddressId, setSelectedAddressId] = useState<string | null>(null);
  const [showAddressForm, setShowAddressForm] = useState(false);
  const [editingAddress, setEditingAddress] = useState<Address | null>(null);
  const [guestInfo, setGuestInfo] = useState({ name: '', email: '', phone: '' });
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'cod'>('cod');
  const [isProcessing, setIsProcessing] = useState(false);
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Offer | null>(null);
  const [useWallet, setUseWallet] = useState(false);
  const [walletAmount, setWalletAmount] = useState(0);
  const navigate = useNavigate();

  // Settings & Rules State
  const [deliverySettings, setDeliverySettings] = useState<DeliverySettings | null>(null);
  const [offers, setOffers] = useState<Offer[]>([]);
  const [taxRules, setTaxRules] = useState<TaxRule[]>([]);
  const [activeRule, setActiveRule] = useState<RTORule | null>(null);

  useEffect(() => {
    apiFetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data && data.delivery_settings) setDeliverySettings(JSON.parse(data.delivery_settings));
        if (data && data.tax_rules) setTaxRules(JSON.parse(data.tax_rules));
        if (data && data.rto_rules) {
          const rules = JSON.parse(data.rto_rules);
          // Just pick the first active rule for now or implement logic
          if (rules.length > 0) setActiveRule(rules[0]);
        }
      });

    apiFetch('/api/get-offers')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) setOffers(data);
      });

    const savedAddresses = localStorage.getItem('user_addresses');
    if (savedAddresses) {
      const parsed = JSON.parse(savedAddresses);
      setAddresses(parsed);
      const defaultAddr = parsed.find((a: Address) => a.isDefault);
      if (defaultAddr) setSelectedAddressId(defaultAddr.id);
      else if (parsed.length > 0) setSelectedAddressId(parsed[0].id);
    } else if (!user) {
      setShowAddressForm(true);
    }
  }, [user]);

  const selectedAddress = useMemo(() => 
    addresses.find(a => a.id === selectedAddressId), 
  [addresses, selectedAddressId]);

  const addressString = useMemo(() => {
    if (!selectedAddress) return '';
    const { houseNumber, street, area, city, state, pincode, landmark } = selectedAddress;
    return `${houseNumber}, ${street}, ${area}, ${landmark ? landmark + ', ' : ''}${city}, ${state} - ${pincode}`;
  }, [selectedAddress]);

  // 1. Subtotal Calculation
  const subtotal = useMemo(() => {
    return items.reduce((sum, item) => {
      const price = item.selectedVariant ? item.selectedVariant.price : item.price * (1 - item.discount / 100);
      return sum + (price * item.quantity);
    }, 0);
  }, [items]);

  // 2. Discount Calculation
  const discountInfo = useMemo(() => {
    let totalDiscount = 0;
    let appliedOfferName = '';

    // Check for auto-apply offers first
    const autoOffers = offers.filter(o => o.autoApply && o.status === 'active');
    
    // Simple logic: pick the highest discount
    let bestOffer: Offer | null = null;
    let maxDiscount = 0;

    const allPotentialOffers = appliedCoupon ? [...autoOffers, appliedCoupon] : autoOffers;

    allPotentialOffers.forEach(offer => {
      let currentDiscount = 0;
      if (offer.type === 'cart') {
        if (offer.discountType === 'percentage') {
          currentDiscount = (subtotal * offer.discountValue) / 100;
        } else {
          currentDiscount = offer.discountValue;
        }
      } else if (offer.type === 'product') {
        if (offer.discountType === 'percentage') {
          currentDiscount = (subtotal * offer.discountValue) / 100;
        } else {
          currentDiscount = offer.discountValue;
        }
      }

      if (currentDiscount > maxDiscount) {
        maxDiscount = currentDiscount;
        bestOffer = offer;
      }
    });

    return { amount: maxDiscount, name: bestOffer ? (bestOffer as any).name : '' };
  }, [subtotal, offers, appliedCoupon]);

  const amountAfterDiscount = subtotal - discountInfo.amount;

  // 3. Tax Calculation
  const taxInfo = useMemo(() => {
    return taxRules.reduce((acc, rule) => {
      const amount = (amountAfterDiscount * rule.percentage) / 100;
      return {
        total: acc.total + amount,
        details: [...acc.details, { name: rule.name, amount }]
      };
    }, { total: 0, details: [] as { name: string, amount: number }[] });
  }, [amountAfterDiscount, taxRules]);

  // 4. Shipping Calculation
  const shippingFee = useMemo(() => {
    if (!deliverySettings) return 0;
    if (deliverySettings.freeDeliveryThreshold && amountAfterDiscount >= deliverySettings.freeDeliveryThreshold) {
      return 0;
    }
    return deliverySettings.flatFee || 0;
  }, [deliverySettings, amountAfterDiscount]);

  // 5. Final Total
  const finalTotalBeforeWallet = amountAfterDiscount + taxInfo.total + shippingFee;

  // 6. Wallet Deduction
  const appliedWalletAmount = useMemo(() => {
    if (!useWallet || !user) return 0;
    return Math.min(user.walletBalance || 0, finalTotalBeforeWallet, walletAmount || 0);
  }, [useWallet, user, finalTotalBeforeWallet, walletAmount]);

  const finalTotal = finalTotalBeforeWallet - appliedWalletAmount;

  // RTO & Payment Rules Logic
  const evaluateRules = () => {
    const savedRules = localStorage.getItem('rto_rules');
    if (!savedRules) return;

    const rules: RTORule[] = JSON.parse(savedRules);
    const sortedRules = [...rules].sort((a, b) => b.priority - a.priority);

    for (const rule of sortedRules) {
      let applies = false;

      if (rule.type === 'location') {
        const addrStr = addressString.toLowerCase();
        applies = rule.locations?.some(loc => addrStr.includes(loc.toLowerCase())) || false;
      } else if (rule.type === 'category') {
        applies = items.some(item => rule.targetIds.includes(item.category));
      } else if (rule.type === 'product') {
        applies = items.some(item => rule.targetIds.includes(item.id.toString()));
      } else if (rule.type === 'variant') {
        applies = items.some(item => item.selectedVariant && rule.targetIds.includes(item.selectedVariant.id));
      }

      if (applies) {
        setActiveRule(rule);
        if (!rule.paymentRules.allowCOD && paymentMethod === 'cod') {
          setPaymentMethod('upi');
        }
        return;
      }
    }
    setActiveRule(null);
  };

  useEffect(() => {
    evaluateRules();
  }, [items, addressString]);

  const advanceAmount = useMemo(() => {
    if (!activeRule?.paymentRules.requireAdvance) return 0;
    const { advanceType, advanceValue } = activeRule.paymentRules;
    if (advanceType === 'fixed') return advanceValue || 0;
    if (advanceType === 'percentage') return (finalTotal * (advanceValue || 0)) / 100;
    return 0;
  }, [activeRule, finalTotal]);

  const handleApplyCoupon = () => {
    const offer = offers.find(o => o.couponCode === couponCode.toUpperCase() && o.status === 'active');
    if (offer) {
      setAppliedCoupon(offer);
      toast.success('Coupon applied!');
    } else {
      toast.error('Invalid or expired coupon');
    }
  };

  const handleAddressSubmit = (newAddress: Address) => {
    let updatedAddresses;
    if (editingAddress) {
      updatedAddresses = addresses.map(a => a.id === newAddress.id ? newAddress : a);
    } else {
      updatedAddresses = [...addresses, newAddress];
    }

    if (newAddress.isDefault) {
      updatedAddresses = updatedAddresses.map(a => a.id === newAddress.id ? a : { ...a, isDefault: false });
    }

    setAddresses(updatedAddresses);
    localStorage.setItem('user_addresses', JSON.stringify(updatedAddresses));
    setSelectedAddressId(newAddress.id);
    setShowAddressForm(false);
    setEditingAddress(null);
    toast.success(editingAddress ? 'Address updated' : 'Address added');
  };

  const handleDeleteAddress = (id: string, e: any) => {
    e.stopPropagation();
    const updated = addresses.filter(a => a.id !== id);
    setAddresses(updated);
    localStorage.setItem('user_addresses', JSON.stringify(updated));
    if (selectedAddressId === id) {
      setSelectedAddressId(updated[0]?.id || null);
    }
    toast.success('Address deleted');
  };

  const handlePlaceOrder = async () => {
    if (!selectedAddressId) {
      toast.error('Please select a delivery address');
      return;
    }

    if (!user && (!guestInfo.name || !guestInfo.email || !guestInfo.phone)) {
      toast.error('Please provide your name, email and phone number');
      return;
    }

    if (guestInfo.phone && guestInfo.phone.length !== 10) {
      toast.error('Mobile number must be 10 digits');
      return;
    }

    setIsProcessing(true);
    try {
      const actualPaymentMethod = activeRule?.paymentRules.requireAdvance ? 'partial_advance' : paymentMethod;
      
      const res = await apiFetch('/api/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          address: addressString,
          payment_method: actualPaymentMethod,
          cart_items: items,
          guest_name: user ? null : guestInfo.name,
          guest_email: user ? null : guestInfo.email,
          user_phone: selectedAddress?.mobileNumber || guestInfo.phone,
          advance_paid: activeRule?.paymentRules.requireAdvance ? advanceAmount : 0,
          total_amount: finalTotal,
          wallet_amount: appliedWalletAmount,
          discount_amount: discountInfo.amount,
          tax_amount: taxInfo.total,
          shipping_fee: shippingFee,
          shipping_type: 'Standard'
        })
      });

      const data = await res.json();

      if ((paymentMethod === 'upi' || activeRule?.paymentRules.requireAdvance) && data.rzpOrder) {
        const options = {
          key: import.meta.env.VITE_RAZORPAY_KEY_ID || 'rzp_test_dummy',
          amount: data.rzpOrder.amount,
          currency: 'INR',
          name: 'SmartBiz Store',
          description: activeRule?.paymentRules.requireAdvance ? 'Advance Payment' : 'Full Payment',
          order_id: data.rzpOrder.id,
          handler: async function (response: any) {
            await apiFetch(`/api/orders/${data.orderId}/pay`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ razorpay_payment_id: response.razorpay_payment_id })
            });
            toast.success(activeRule?.paymentRules.requireAdvance ? 'Advance Paid! Order Confirmed.' : 'Payment Successful!');
            clearCart();
            if (appliedWalletAmount > 0) await refreshUser();
            if (user) {
              navigate('/thank-you', { state: { orderId: data.orderId } });
            } else {
              navigate('/thank-you', { state: { orderId: data.orderId } });
            }
          },
          prefill: {
            name: user?.name || guestInfo.name,
            email: user?.email || guestInfo.email
          },
          theme: { color: '#0D9488' }
        };
        const rzp = new Razorpay(options);
        rzp.open();
      } else {
        toast.success('Order placed successfully!');
        clearCart();
        if (appliedWalletAmount > 0) await refreshUser();
        if (user) {
          navigate('/thank-you', { state: { orderId: data.orderId } });
        } else {
          navigate('/thank-you', { state: { orderId: data.orderId } });
        }
      }
    } catch (err) {
      toast.error('Failed to place order');
    } finally {
      setIsProcessing(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="h-[calc(100vh-64px)] flex flex-col items-center justify-center space-y-4">
        <CheckCircle className="w-16 h-16 text-green-500" />
        <h2 className="text-2xl font-bold">Your cart is empty</h2>
        <button onClick={() => navigate('/')} className="text-purple-600 font-bold">Go Shopping</button>
      </div>
    );
  }

  const getAddressIcon = (type: string) => {
    switch (type) {
      case 'home': return Home;
      case 'work': return Briefcase;
      default: return MoreHorizontal;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Left: Forms */}
        <div className="space-y-8">
          {!user && (
            <section className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 space-y-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-purple-50 rounded-lg text-purple-600">
                  <User className="w-6 h-6" />
                </div>
                <h2 className="text-xl font-bold">Contact Information</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Full Name"
                  value={guestInfo.name}
                  onChange={(e) => setGuestInfo({ ...guestInfo, name: e.target.value })}
                  className="w-full p-4 bg-gray-50 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                />
                <input
                  type="email"
                  placeholder="Email Address"
                  value={guestInfo.email}
                  onChange={(e) => setGuestInfo({ ...guestInfo, email: e.target.value })}
                  className="w-full p-4 bg-gray-50 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                />
                <input
                  type="tel"
                  placeholder="Mobile Number (10 digits)"
                  value={guestInfo.phone}
                  onChange={(e) => setGuestInfo({ ...guestInfo, phone: e.target.value.replace(/\D/g, '').slice(0, 10) })}
                  className="w-full p-4 bg-gray-50 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all md:col-span-2"
                />
              </div>
            </section>
          )}

          <section className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-purple-50 rounded-lg text-purple-600">
                  <MapPin className="w-6 h-6" />
                </div>
                <h2 className="text-xl font-bold">Delivery Address</h2>
              </div>
              {!showAddressForm && (
                <button
                  onClick={() => { setEditingAddress(null); setShowAddressForm(true); }}
                  className="flex items-center space-x-1 text-xs font-bold uppercase tracking-widest text-purple-600 hover:text-purple-700 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add New</span>
                </button>
              )}
            </div>

            <AnimatePresence mode="wait">
              {showAddressForm ? (
                <motion.div
                  key="address-form"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                >
                  <AddressForm 
                    initialAddress={editingAddress || undefined}
                    onSubmit={handleAddressSubmit}
                    onCancel={() => { setShowAddressForm(false); setEditingAddress(null); }}
                  />
                </motion.div>
              ) : (
                <motion.div
                  key="address-list"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-4"
                >
                  {addresses.length === 0 ? (
                    <div className="text-center py-8 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
                      <MapPin className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                      <p className="text-sm text-gray-500">No addresses saved yet</p>
                      <button
                        onClick={() => setShowAddressForm(true)}
                        className="mt-4 text-xs font-bold uppercase tracking-widest text-purple-600"
                      >
                        Add your first address
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 gap-4">
                      {addresses.map((addr) => {
                        const Icon = getAddressIcon(addr.type);
                        const isSelected = selectedAddressId === addr.id;
                        return (
                          <div
                            key={addr.id}
                            onClick={() => setSelectedAddressId(addr.id)}
                            className={cn(
                              "relative p-4 rounded-2xl border-2 transition-all cursor-pointer group",
                              isSelected ? "border-black bg-black/5" : "border-gray-100 hover:border-gray-200"
                            )}
                          >
                            <div className="flex items-start justify-between">
                              <div className="flex items-start space-x-3">
                                <div className={cn(
                                  "p-2 rounded-lg",
                                  isSelected ? "bg-black text-white" : "bg-gray-100 text-gray-500"
                                )}>
                                  <Icon className="w-4 h-4" />
                                </div>
                                <div className="space-y-1">
                                  <div className="flex items-center space-x-2">
                                    <span className="font-bold text-gray-900">{addr.fullName}</span>
                                    {addr.isDefault && (
                                      <span className="px-1.5 py-0.5 bg-gray-100 text-gray-500 text-[8px] font-bold uppercase rounded">Default</span>
                                    )}
                                  </div>
                                  <p className="text-xs text-gray-500 leading-relaxed">
                                    {addr.houseNumber}, {addr.street}, {addr.area}<br />
                                    {addr.city}, {addr.state} - {addr.pincode}
                                  </p>
                                  <p className="text-xs font-medium text-gray-900">{addr.mobileNumber}</p>
                                </div>
                              </div>
                              <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button
                                  onClick={(e) => { e.stopPropagation(); setEditingAddress(addr); setShowAddressForm(true); }}
                                  className="p-2 hover:bg-white rounded-lg text-gray-400 hover:text-black transition-colors"
                                >
                                  <Edit2 className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={(e) => handleDeleteAddress(addr.id, e)}
                                  className="p-2 hover:bg-white rounded-lg text-gray-400 hover:text-red-500 transition-colors"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                            {isSelected && (
                              <div className="absolute top-4 right-4 text-black">
                                <CheckCircle className="w-5 h-5 fill-current" />
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </section>

          <section className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-teal-50 rounded-lg text-teal-600">
                  <Wallet className="w-6 h-6" />
                </div>
                <h2 className="text-xl font-bold">V Wallet Balance</h2>
              </div>
              {user && (
                <div className="text-right">
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Available</p>
                  <p className="text-sm font-bold text-teal-600">₹{user.walletBalance || 0}</p>
                </div>
              )}
            </div>

            {user ? (
              <div className={cn(
                "p-6 rounded-2xl border-2 transition-all",
                useWallet ? "border-teal-600 bg-teal-50" : "border-gray-100 bg-gray-50/50"
              )}>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center transition-colors",
                      useWallet ? "bg-teal-600 text-white" : "bg-gray-200 text-gray-400"
                    )}>
                      <Wallet className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-gray-900">Use V Wallet Points</p>
                      <p className="text-xs text-gray-500">Redeem points to reduce cart value</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => {
                      setUseWallet(!useWallet);
                      if (!useWallet) setWalletAmount(Math.min(user.walletBalance || 0, finalTotalBeforeWallet));
                    }}
                    className={cn(
                      "w-12 h-6 rounded-full relative transition-colors",
                      useWallet ? "bg-teal-600" : "bg-gray-300"
                    )}
                  >
                    <div className={cn(
                      "absolute top-1 w-4 h-4 bg-white rounded-full transition-all",
                      useWallet ? "left-7" : "left-1"
                    )} />
                  </button>
                </div>

                <AnimatePresence>
                  {useWallet && (
                    <motion.div 
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="space-y-4 pt-4 border-t border-teal-100"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="flex-1 relative">
                          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold">₹</span>
                          <input 
                            type="number" 
                            value={walletAmount}
                            onChange={(e) => {
                              const val = parseFloat(e.target.value) || 0;
                              setWalletAmount(Math.min(val, user.walletBalance || 0, finalTotalBeforeWallet));
                            }}
                            className="w-full pl-8 pr-4 py-3 bg-white border border-teal-200 rounded-xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                          />
                        </div>
                        <button 
                          onClick={() => setWalletAmount(Math.min(user.walletBalance || 0, finalTotalBeforeWallet))}
                          className="px-4 py-3 bg-teal-100 text-teal-700 rounded-xl text-xs font-bold hover:bg-teal-200 transition-colors"
                        >
                          Use Max
                        </button>
                      </div>
                      <p className="text-[10px] text-teal-600 font-bold uppercase tracking-wider">
                        You will save ₹{appliedWalletAmount.toFixed(0)} on this order
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <div className="p-6 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200 text-center">
                <p className="text-sm text-gray-500">Login to use your V Wallet points and save on this order.</p>
                <button onClick={() => navigate('/login')} className="mt-3 text-xs font-bold text-teal-600 uppercase tracking-widest">Login Now</button>
              </div>
            )}
          </section>

          <section className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-teal-50 rounded-lg text-teal-600">
                  <CreditCard className="w-6 h-6" />
                </div>
                <h2 className="text-xl font-bold">Payment Method</h2>
              </div>
              {activeRule && (
                <div className="flex items-center space-x-1 px-2 py-1 bg-teal-50 text-teal-600 rounded-lg text-[10px] font-bold uppercase tracking-wider">
                  <ShieldCheck className="w-3 h-3" />
                  <span>Rule Applied: {activeRule.name}</span>
                </div>
              )}
            </div>

            <AnimatePresence>
              {activeRule && !activeRule.paymentRules.allowCOD && (
                <motion.div 
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 bg-orange-50 border border-orange-100 rounded-2xl flex items-start space-x-3"
                >
                  <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-sm font-bold text-orange-900">COD is not available for this order</p>
                    <p className="text-xs text-orange-700">Due to store policy, this order requires a prepaid payment method.</p>
                  </div>
                </motion.div>
              )}

              {activeRule?.paymentRules.requireAdvance && (
                <motion.div 
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 bg-teal-50 border border-teal-100 rounded-2xl flex items-start space-x-3"
                >
                  <Info className="w-5 h-5 text-teal-600 mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-sm font-bold text-teal-900">Advance Payment Required</p>
                    <p className="text-xs text-teal-700">
                      To confirm this order, an advance of <strong>₹{advanceAmount.toFixed(0)}</strong> is required. 
                      The remaining <strong>₹{(finalTotal - advanceAmount).toFixed(0)}</strong> can be paid via COD.
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="grid grid-cols-2 gap-4">
              <button
                disabled={activeRule && !activeRule.paymentRules.allowCOD}
                onClick={() => setPaymentMethod('cod')}
                className={cn(
                  "p-4 rounded-2xl border-2 transition-all flex flex-col items-center space-y-2 relative",
                  paymentMethod === 'cod' ? 'border-teal-600 bg-teal-50' : 'border-gray-100 hover:border-teal-200',
                  activeRule && !activeRule.paymentRules.allowCOD && 'opacity-50 cursor-not-allowed bg-gray-50'
                )}
              >
                <Truck className={cn("w-6 h-6", paymentMethod === 'cod' ? 'text-teal-600' : 'text-gray-400')} />
                <span className="font-bold">Cash on Delivery</span>
                {activeRule?.paymentRules.requireAdvance && (
                  <span className="absolute -top-2 -right-2 px-2 py-1 bg-teal-600 text-white text-[8px] font-bold rounded-full uppercase">
                    + Advance
                  </span>
                )}
              </button>
              <button
                onClick={() => setPaymentMethod('upi')}
                className={cn(
                  "p-4 rounded-2xl border-2 transition-all flex flex-col items-center space-y-2",
                  paymentMethod === 'upi' ? 'border-teal-600 bg-teal-50' : 'border-gray-100 hover:border-teal-200'
                )}
              >
                <CreditCard className={cn("w-6 h-6", paymentMethod === 'upi' ? 'text-teal-600' : 'text-gray-400')} />
                <span className="font-bold">Full Prepaid</span>
              </button>
            </div>
          </section>
        </div>

        {/* Right: Summary */}
        <div className="space-y-8">
          <section className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 sticky top-24">
            <h2 className="text-xl font-bold mb-6">Order Summary</h2>
            
            {/* Coupon Section */}
            <div className="mb-6 space-y-3">
              <div className="flex items-center space-x-2">
                <div className="relative flex-1">
                  <Tag className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                  <input 
                    type="text" 
                    placeholder="Coupon Code"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                  />
                </div>
                <button 
                  onClick={handleApplyCoupon}
                  className="px-4 py-2.5 bg-gray-900 text-white rounded-xl text-sm font-bold hover:bg-black transition-all"
                >
                  Apply
                </button>
              </div>
              {appliedCoupon && (
                <div className="flex items-center justify-between px-3 py-2 bg-green-50 border border-green-100 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-xs font-bold text-green-700">{appliedCoupon.couponCode} Applied</span>
                  </div>
                  <button onClick={() => setAppliedCoupon(null)} className="text-xs text-green-600 hover:underline">Remove</button>
                </div>
              )}
            </div>

            <div className="space-y-4 mb-6 max-h-60 overflow-y-auto">
              {items.map((item) => (
                <div key={item.id} className="flex justify-between items-center">
                  <div className="flex items-center space-x-3">
                    <img src={item.image_url} alt={item.name} className="w-12 h-12 rounded-lg object-cover" />
                    <div>
                      <p className="font-semibold text-gray-900 truncate max-w-[150px]">{item.name}</p>
                      {item.selectedVariant && (
                        <p className="text-[10px] text-gray-400 uppercase font-bold">
                          {item.selectedVariant.color} / {item.selectedVariant.size}
                        </p>
                      )}
                      <p className="text-sm text-gray-500">Qty: {item.quantity}</p>
                    </div>
                  </div>
                  <span className="font-bold">
                    ₹{((item.selectedVariant ? item.selectedVariant.price : item.price * (1 - item.discount / 100)) * item.quantity).toFixed(0)}
                  </span>
                </div>
              ))}
            </div>

            <div className="border-t border-gray-100 pt-6 space-y-3">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span>₹{subtotal.toFixed(0)}</span>
              </div>
              
              {discountInfo.amount > 0 && (
                <div className="flex justify-between text-green-600 font-medium">
                  <div className="flex items-center space-x-1">
                    <Percent className="w-3 h-3" />
                    <span>Discount {discountInfo.name && `(${discountInfo.name})`}</span>
                  </div>
                  <span>-₹{discountInfo.amount.toFixed(0)}</span>
                </div>
              )}

              {taxInfo.details.map((tax, idx) => (
                <div key={idx} className="flex justify-between text-gray-600">
                  <div className="flex items-center space-x-1">
                    <Receipt className="w-3 h-3" />
                    <span>{tax.name}</span>
                  </div>
                  <span>₹{tax.amount.toFixed(0)}</span>
                </div>
              ))}

              <div className="flex justify-between text-gray-600">
                <div className="flex items-center space-x-1">
                  <Truck className="w-3 h-3" />
                  <span>Delivery Fee</span>
                </div>
                {shippingFee === 0 ? (
                  <span className="text-green-600 font-bold uppercase text-xs">Free</span>
                ) : (
                  <span>₹{shippingFee.toFixed(0)}</span>
                )}
              </div>

              {appliedWalletAmount > 0 && (
                <div className="flex justify-between text-teal-600 font-medium">
                  <div className="flex items-center space-x-1">
                    <Wallet className="w-3 h-3" />
                    <span>V Wallet Points</span>
                  </div>
                  <span>-₹{appliedWalletAmount.toFixed(0)}</span>
                </div>
              )}
              
              <AnimatePresence>
                {activeRule?.paymentRules.requireAdvance && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    className="space-y-3 pt-3 border-t border-dashed border-gray-100"
                  >
                    <div className="flex justify-between text-sm text-teal-600 font-bold">
                      <span>Advance to Pay Now</span>
                      <span>₹{advanceAmount.toFixed(0)}</span>
                    </div>
                    <div className="flex justify-between text-sm text-gray-500">
                      <span>Balance on Delivery</span>
                      <span>₹{(finalTotal - advanceAmount).toFixed(0)}</span>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="flex justify-between text-xl font-bold text-gray-900 pt-3 border-t border-gray-100">
                <span>Total</span>
                <span>₹{finalTotal.toFixed(0)}</span>
              </div>
            </div>
            <button
              onClick={handlePlaceOrder}
              disabled={isProcessing}
              className="w-full mt-8 py-4 bg-teal-600 text-white rounded-2xl font-bold hover:bg-teal-700 transition-all shadow-lg shadow-teal-100 disabled:opacity-50"
            >
              {isProcessing ? 'Processing...' : 
               activeRule?.paymentRules.requireAdvance && paymentMethod === 'cod' 
               ? `Pay Advance ₹${advanceAmount.toFixed(0)}` 
               : `Pay ₹${finalTotal.toFixed(0)}`}
            </button>
          </section>
        </div>
      </div>
    </div>
  );
}
