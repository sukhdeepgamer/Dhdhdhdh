import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database('icraft.db');

// Initialize tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT,
    role TEXT DEFAULT 'user',
    google_id TEXT,
    meta_id TEXT,
    wallet_balance REAL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS wallet_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    type TEXT NOT NULL,
    reason TEXT,
    order_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id),
    FOREIGN KEY (order_id) REFERENCES orders (id)
  );

  CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    user_name TEXT NOT NULL,
    rating INTEGER NOT NULL,
    comment TEXT,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products (id),
    FOREIGN KEY (user_id) REFERENCES users (id)
  );

  CREATE TABLE IF NOT EXISTS offers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    logic TEXT,
    discount_type TEXT NOT NULL,
    discount_value REAL NOT NULL,
    auto_apply BOOLEAN DEFAULT 1,
    start_date DATETIME,
    end_date DATETIME,
    used_count INTEGER DEFAULT 0,
    status TEXT DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    price REAL NOT NULL,
    mrp REAL,
    discount INTEGER DEFAULT 0,
    image_url TEXT,
    images TEXT, -- JSON array of image URLs
    category TEXT,
    business_category TEXT,
    stock INTEGER DEFAULT 0,
    sku TEXT,
    pdp_template TEXT,
    hsn_code TEXT,
    is_bestseller BOOLEAN DEFAULT 0,
    is_available BOOLEAN DEFAULT 1,
    seo TEXT, -- JSON object
    variants TEXT, -- JSON array
    size_chart TEXT, -- URL
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    guest_name TEXT,
    guest_email TEXT,
    user_phone TEXT,
    total_amount REAL NOT NULL,
    discount_amount REAL DEFAULT 0,
    tax_amount REAL DEFAULT 0,
    shipping_fee REAL DEFAULT 0,
    wallet_amount REAL DEFAULT 0,
    advance_paid REAL DEFAULT 0,
    payment_method TEXT NOT NULL,
    payment_status TEXT DEFAULT 'pending',
    delivery_status TEXT DEFAULT 'pending',
    address TEXT NOT NULL,
    shipping_type TEXT DEFAULT 'Standard',
    courier_name TEXT,
    tracking_id TEXT,
    estimated_delivery_date DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  );

  CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    price REAL NOT NULL,
    product_name TEXT,
    product_image TEXT,
    FOREIGN KEY (order_id) REFERENCES orders (id),
    FOREIGN KEY (product_id) REFERENCES products (id)
  );

  CREATE TABLE IF NOT EXISTS cart (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER DEFAULT 1,
    UNIQUE(user_id, product_id),
    FOREIGN KEY (user_id) REFERENCES users (id),
    FOREIGN KEY (product_id) REFERENCES products (id)
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  );
`);

// Ensure new columns exist for existing databases
const tables = ['products', 'orders'];
const columns: Record<string, string[]> = {
  products: [
    'mrp REAL',
    'images TEXT',
    'business_category TEXT',
    'sku TEXT',
    'pdp_template TEXT',
    'hsn_code TEXT',
    'is_bestseller BOOLEAN DEFAULT 0',
    'seo TEXT',
    'variants TEXT',
    'size_chart TEXT'
  ],
  orders: [
    'discount_amount REAL DEFAULT 0',
    'tax_amount REAL DEFAULT 0',
    'shipping_fee REAL DEFAULT 0',
    'wallet_amount REAL DEFAULT 0',
    'advance_paid REAL DEFAULT 0',
    'shipping_type TEXT DEFAULT "Standard"'
  ]
};

for (const table of tables) {
  const tableInfo = db.prepare(`PRAGMA table_info(${table})`).all() as any[];
  const existingColumns = tableInfo.map(c => c.name);
  
  for (const colDef of columns[table]) {
    const colName = colDef.split(' ')[0];
    if (!existingColumns.includes(colName)) {
      try {
        db.exec(`ALTER TABLE ${table} ADD COLUMN ${colDef}`);
      } catch (err) {
        console.error(`Failed to add column ${colName} to ${table}:`, err);
      }
    }
  }
}

// Seed settings if empty
const settingsCount = db.prepare('SELECT COUNT(*) as count FROM settings').get() as { count: number };
if (settingsCount.count === 0) {
  const insertSetting = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)');
  insertSetting.run('brand_name', 'iCraft Tech');
  insertSetting.run('contact_email', 'support@icraft-tech.com');
  insertSetting.run('contact_phone', '+1 (555) 123-4567');
  insertSetting.run('address', 'Tech Valley, Silicon City, CA');
  insertSetting.run('homepage_settings', JSON.stringify({
    announcementBar: {
      enabled: true,
      text: 'Free shipping on orders over ₹999!',
      backgroundColor: '#0D9488',
      textColor: '#FFFFFF',
      link: ''
    },
    banners: [
      {
        id: '1',
        type: 'image',
        url: 'https://picsum.photos/seed/banner1/1920/600',
        link: '/products',
        order: 0,
        isVisible: true
      }
    ]
  }));
}

// Seed initial products if empty
const productCount = db.prepare('SELECT COUNT(*) as count FROM products').get() as { count: number };
if (productCount.count === 0) {
  const insertProduct = db.prepare(`
    INSERT INTO products (name, description, price, discount, image_url, category, stock)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  const initialProducts = [
    ['iPhone 15 Pro', 'Titanium design, A17 Pro chip', 99900, 5, 'https://picsum.photos/seed/iphone15/800/800', 'Mobiles', 50],
    ['MacBook Air M3', 'Supercharged by M3 chip', 114900, 10, 'https://picsum.photos/seed/macbook/800/800', 'Laptops', 30],
    ['Sony WH-1000XM5', 'Industry-leading noise canceling', 29900, 15, 'https://picsum.photos/seed/sony/800/800', 'Audio', 100],
    ['Apple Watch Ultra 2', 'The most rugged and capable Apple Watch', 89900, 0, 'https://picsum.photos/seed/watch/800/800', 'Wearables', 40],
    ['iPad Pro M2', 'Mind-blowing performance, incredibly advanced displays', 79900, 8, 'https://picsum.photos/seed/ipad/800/800', 'Tablets', 60],
    ['Samsung S24 Ultra', 'Galaxy AI is here', 129900, 12, 'https://picsum.photos/seed/s24/800/800', 'Mobiles', 45],
    ['AirPods Pro 2', 'Magic like you’ve never heard', 24900, 5, 'https://picsum.photos/seed/airpods/800/800', 'Audio', 200],
    ['Dell XPS 13', 'Stunning design, powerful performance', 95000, 10, 'https://picsum.photos/seed/dell/800/800', 'Laptops', 25],
    ['Logitech G Pro X', 'Wireless gaming headset', 15900, 20, 'https://picsum.photos/seed/logitech/800/800', 'Gaming', 150],
    ['Nintendo Switch OLED', 'Vibrant OLED screen', 32000, 0, 'https://picsum.photos/seed/nintendo/800/800', 'Gaming', 75],
    ['Kindle Paperwhite', 'Now with a 6.8" display', 13900, 5, 'https://picsum.photos/seed/kindle/800/800', 'Tablets', 120],
    ['GoPro HERO12', 'The best HERO camera we’ve ever made', 38000, 10, 'https://picsum.photos/seed/gopro/800/800', 'Cameras', 40],
    ['DJI Mini 4 Pro', 'Mini to the Max', 65000, 5, 'https://picsum.photos/seed/dji/800/800', 'Drones', 15],
    ['Bose QuietComfort', 'Legendary noise cancellation', 25000, 15, 'https://picsum.photos/seed/bose/800/800', 'Audio', 80],
    ['Asus ROG Zephyrus', 'Power and portability', 145000, 10, 'https://picsum.photos/seed/asus/800/800', 'Laptops', 20],
    ['Google Pixel 8 Pro', 'The all-pro Google phone', 106000, 8, 'https://picsum.photos/seed/pixel8/800/800', 'Mobiles', 35],
    ['Canon EOS R5', 'Professional mirrorless redefined', 320000, 5, 'https://picsum.photos/seed/canon/800/800', 'Cameras', 10],
    ['Razer DeathAdder V3', 'For the pro', 12000, 15, 'https://picsum.photos/seed/razer/800/800', 'Gaming', 100],
    ['Fitbit Charge 6', 'Give your routine a routine', 14900, 10, 'https://picsum.photos/seed/fitbit/800/800', 'Wearables', 90],
    ['Marshall Emberton II', 'A heavy hitter with a small footprint', 17000, 5, 'https://picsum.photos/seed/marshall/800/800', 'Audio', 110],
    ['Samsung Neo QLED', 'More wow than ever', 145000, 15, 'https://picsum.photos/seed/tv/800/800', 'Home Appliances', 15],
    ['Dyson V15 Detect', 'The most powerful, intelligent cordless vacuum', 65000, 10, 'https://picsum.photos/seed/dyson/800/800', 'Home Appliances', 20],
    ['LG InstaView Fridge', 'Knock twice and see inside', 185000, 5, 'https://picsum.photos/seed/fridge/800/800', 'Home Appliances', 10],
    ['Diamond Solitaire Ring', '18K White Gold, 1 Carat', 250000, 10, 'https://picsum.photos/seed/ring/800/800', 'Jewelry', 5],
    ['Gold Cuban Link Chain', '24K Pure Gold, 50g', 320000, 5, 'https://picsum.photos/seed/chain/800/800', 'Jewelry', 8],
    ['Silver Tennis Bracelet', 'Sterling Silver with Zirconia', 15000, 20, 'https://picsum.photos/seed/bracelet/800/800', 'Jewelry', 25],
    ['Leather Biker Jacket', 'Premium Italian leather', 25000, 15, 'https://picsum.photos/seed/jacket/800/800', 'Fashion', 30],
    ['Designer Silk Scarf', 'Hand-painted floral design', 8500, 10, 'https://picsum.photos/seed/scarf/800/800', 'Fashion', 50],
    ['Luxury Chronograph Watch', 'Swiss movement, sapphire glass', 45000, 12, 'https://picsum.photos/seed/watch2/800/800', 'Fashion', 15],
    ['Smart Coffee Maker', 'Brew from your phone', 12000, 5, 'https://picsum.photos/seed/coffee/800/800', 'Home Appliances', 40],
    ['Air Purifier Pro', 'HEPA filter, ultra quiet', 18000, 10, 'https://picsum.photos/seed/air/800/800', 'Home Appliances', 60],
    ['Pearl Necklace', 'Akoya cultured pearls', 45000, 8, 'https://picsum.photos/seed/pearl/800/800', 'Jewelry', 12],
    ['Sapphire Earrings', 'Deep blue sapphires in white gold', 85000, 5, 'https://picsum.photos/seed/earrings/800/800', 'Jewelry', 7],
    ['Cashmere Sweater', 'Ultra soft Mongolian cashmere', 12000, 10, 'https://picsum.photos/seed/sweater/800/800', 'Fashion', 45],
    ['Denim Trucker Jacket', 'Classic fit, vintage wash', 5500, 20, 'https://picsum.photos/seed/denim/800/800', 'Fashion', 80],
    ['Smart Toaster', 'Touchscreen controls', 8000, 5, 'https://picsum.photos/seed/toaster/800/800', 'Home Appliances', 35],
    ['Robot Vacuum X1', 'Lidar navigation, self-emptying', 45000, 15, 'https://picsum.photos/seed/robot/800/800', 'Home Appliances', 25],
    ['Emerald Pendant', 'Vibrant green emerald', 65000, 10, 'https://picsum.photos/seed/emerald/800/800', 'Jewelry', 10],
    ['Platinum Wedding Band', 'Brushed finish, comfort fit', 35000, 5, 'https://picsum.photos/seed/band/800/800', 'Jewelry', 20],
    ['Linen Button-Down', 'Breathable summer essential', 3500, 15, 'https://picsum.photos/seed/linen/800/800', 'Fashion', 100],
    ['Chelsea Boots', 'Genuine suede, durable sole', 9500, 10, 'https://picsum.photos/seed/boots/800/800', 'Fashion', 60],
  ];

  for (const p of initialProducts) {
    insertProduct.run(...p);
  }
}

// Seed initial orders if empty
const orderCount = db.prepare('SELECT COUNT(*) as count FROM orders').get() as { count: number };
if (orderCount.count === 0) {
  const insertOrder = db.prepare(`
    INSERT INTO orders (user_id, guest_name, guest_email, total_amount, payment_method, payment_status, delivery_status, address)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const insertOrderItem = db.prepare(`
    INSERT INTO order_items (order_id, product_id, quantity, price, product_name, product_image)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  // Add a guest order
  const guestOrder = insertOrder.run(null, 'John Doe', 'john@example.com', 1249, 'cod', 'pending', 'pending', '123 Tech Street, Silicon Valley');
  insertOrderItem.run(guestOrder.lastInsertRowid, 1, 1, 999, 'iPhone 15 Pro', 'https://picsum.photos/seed/iphone15/800/800');
  insertOrderItem.run(guestOrder.lastInsertRowid, 7, 1, 250, 'AirPods Pro 2', 'https://picsum.photos/seed/airpods/800/800');

  // Add another guest order
  const guestOrder2 = insertOrder.run(null, 'Jane Smith', 'jane@example.com', 29900, 'online', 'paid', 'packed', '456 Design Road, Creative City');
  insertOrderItem.run(guestOrder2.lastInsertRowid, 3, 1, 29900, 'Sony WH-1000XM5', 'https://picsum.photos/seed/sony/800/800');
}

// Seed admin user if not exists
const adminExists = db.prepare('SELECT * FROM users WHERE email = ?').get('admin1001') as any;
if (!adminExists) {
  const bcrypt = await import('bcryptjs');
  const hashedPassword = await bcrypt.default.hash('Password123', 10);
  db.prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)').run('Admin User', 'admin1001', hashedPassword, 'admin');
}

export default db;
