import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const slides = [
  {
    id: 1,
    title: "Next-Gen Tech",
    subtitle: "Experience the future today with our latest gadgets.",
    image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?q=80&w=2070&auto=format&fit=crop",
    color: "from-blue-600 to-indigo-700"
  },
  {
    id: 2,
    title: "Premium Audio",
    subtitle: "Immerse yourself in crystal clear sound quality.",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=2070&auto=format&fit=crop",
    color: "from-purple-600 to-pink-600"
  },
  {
    id: 3,
    title: "Smart Living",
    subtitle: "Connect your home with the smartest devices available.",
    image: "https://images.unsplash.com/photo-1558002038-1055907df827?q=80&w=2070&auto=format&fit=crop",
    color: "from-emerald-600 to-teal-700"
  }
];

export default function Carousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);
  const [banners, setBanners] = useState<any[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data && data.homepage_settings) {
          const settings = JSON.parse(data.homepage_settings);
          const activeBanners = settings.banners.filter((b: any) => {
            if (!b.isVisible) return false;
            return true;
          });
          if (activeBanners.length > 0) {
            setBanners(activeBanners);
          } else {
            setBanners(slides);
          }
        } else {
          setBanners(slides);
        }
      })
      .catch(() => setBanners(slides));
  }, []);

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0
    })
  };

  const swipeConfidenceThreshold = 10000;
  const swipePower = (offset: number, velocity: number) => {
    return Math.abs(offset) * velocity;
  };

  const paginate = (newDirection: number) => {
    if (banners.length === 0) return;
    setDirection(newDirection);
    setCurrentIndex((prevIndex) => (prevIndex + newDirection + banners.length) % banners.length);
  };

  useEffect(() => {
    if (banners.length <= 1) return;
    timerRef.current = setInterval(() => {
      paginate(1);
    }, 5000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [currentIndex, banners]);

  if (banners.length === 0) return null;

  return (
    <div className="relative h-[400px] md:h-[600px] w-full overflow-hidden bg-gray-900 group">
      <AnimatePresence initial={false} custom={direction}>
        <motion.div
          key={currentIndex}
          custom={direction}
          variants={slideVariants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{
            x: { type: "spring", stiffness: 300, damping: 30 },
            opacity: { duration: 0.2 }
          }}
          drag="x"
          dragConstraints={{ left: 0, right: 0 }}
          dragElastic={1}
          onDragEnd={(e, { offset, velocity }) => {
            const swipe = swipePower(offset.x, velocity.x);
            if (swipe < -swipeConfidenceThreshold) {
              paginate(1);
            } else if (swipe > swipeConfidenceThreshold) {
              paginate(-1);
            }
          }}
          className="absolute inset-0"
        >
          <div className="absolute inset-0 bg-black/40 z-10" />
          {banners[currentIndex].type === 'video' ? (
            <video
              src={banners[currentIndex].image || banners[currentIndex].url}
              autoPlay
              muted
              loop
              playsInline
              className="h-full w-full object-cover"
            />
          ) : (
            <img
              src={banners[currentIndex].image || banners[currentIndex].url}
              alt={banners[currentIndex].title}
              className="h-full w-full object-cover"
              referrerPolicy="no-referrer"
            />
          )}
          <div className="absolute inset-0 z-20 flex flex-col items-center justify-center text-center px-4">
            <motion.h2
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-4xl md:text-7xl font-black text-white mb-4 tracking-tighter"
            >
              {banners[currentIndex].title}
            </motion.h2>
            <motion.p
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-lg md:text-2xl text-white/80 max-w-2xl font-medium"
            >
              {banners[currentIndex].subtitle}
            </motion.p>
            {banners[currentIndex].link && (
              <motion.button
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4 }}
                onClick={() => window.location.href = banners[currentIndex].link}
                className="mt-8 px-8 py-4 bg-white text-black rounded-full font-bold text-lg hover:bg-purple-600 hover:text-white transition-all shadow-2xl"
              >
                Shop Now
              </motion.button>
            )}
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation Buttons */}
      {banners.length > 1 && (
        <>
          <button
            className="absolute left-4 top-1/2 -translate-y-1/2 z-30 p-3 bg-white/10 backdrop-blur-md text-white rounded-full hover:bg-white/20 transition-all opacity-0 group-hover:opacity-100 hidden md:block"
            onClick={() => paginate(-1)}
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            className="absolute right-4 top-1/2 -translate-y-1/2 z-30 p-3 bg-white/10 backdrop-blur-md text-white rounded-full hover:bg-white/20 transition-all opacity-0 group-hover:opacity-100 hidden md:block"
            onClick={() => paginate(1)}
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </>
      )}

      {/* Indicators */}
      {banners.length > 1 && (
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-30 flex space-x-3">
          {banners.map((_, index) => (
            <button
              key={index}
              onClick={() => {
                setDirection(index > currentIndex ? 1 : -1);
                setCurrentIndex(index);
              }}
              className={`h-1.5 rounded-full transition-all ${
                index === currentIndex ? 'w-8 bg-white' : 'w-2 bg-white/40'
              }`}
            />
          ))}
        </div>
      )}
    </div>
  );
}
