import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Search, ShoppingBag, User, Heart } from 'lucide-react';
import { motion } from 'motion/react';
import { useCart } from '../contexts/CartContext';
import { useWishlist } from '../contexts/WishlistContext';
import { useAuth } from '../contexts/AuthContext';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function MobileNav() {
  const location = useLocation();
  const { wishlist } = useWishlist();
  const { user } = useAuth();

  const navItems = [
    { path: '/', icon: Home, label: 'Home' },
    { path: '/products', icon: Search, label: 'Search' },
    { path: '/wishlist', icon: Heart, label: 'Wishlist', badge: wishlist.length, showZero: true },
    { path: user ? (user.role === 'admin' ? '/admin' : '/orders') : '/login', icon: User, label: 'Profile' },
  ];

  const activeIndex = navItems.findIndex(item => 
    item.path === '/' ? location.pathname === '/' : location.pathname.startsWith(item.path)
  );

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-100">
      <nav className="relative flex items-center h-16 px-4">
        {navItems.map((item, idx) => {
          const isActive = activeIndex === idx;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "relative flex flex-col items-center justify-center w-1/4 h-full transition-all duration-300",
                isActive ? "text-gray-900 opacity-100" : "text-gray-900 opacity-40"
              )}
            >
              {/* Active Indicator Background */}
              {isActive && (
                <motion.div
                  layoutId="mobile-nav-indicator"
                  className="absolute inset-2 bg-violet-50 rounded-xl -z-10"
                  transition={{ type: 'tween', ease: "circOut", duration: 0.3 }}
                />
              )}

              <div className="relative z-10">
                <item.icon 
                  className={cn("w-5 h-5 transition-transform", isActive && "scale-110")} 
                  fill="none"
                />
                {(item.badge > 0 || item.showZero) && (
                  <span className="absolute -top-1 -right-2 bg-black text-white text-[8px] font-bold w-3.5 h-3.5 rounded-full flex items-center justify-center border border-white">
                    {item.badge}
                  </span>
                )}
              </div>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
