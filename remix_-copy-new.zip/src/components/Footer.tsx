import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  const [settings, setSettings] = useState({
    brand_name: 'Dairy Delight',
    contact_email: 'support@dairydelight.com',
    contact_phone: '+91 1800-CHOCO-LOVE',
    address: 'Chocolate Factory, Mumbai, India'
  });

  useEffect(() => {
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data && data.brand_name) {
          setSettings(data);
        }
      })
      .catch(() => {});
  }, []);

  return (
    <footer className="bg-black text-white border-t border-white/5 pt-16 pb-24 md:pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="space-y-6">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                <span className="text-black font-black text-lg">{settings.brand_name[0]}</span>
              </div>
              <span className="text-lg font-black tracking-tighter text-white">
                {settings.brand_name}
              </span>
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed font-medium">
              The ultimate destination for premium tech gadgets. Experience innovation at your fingertips.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="p-2 bg-white/5 text-gray-400 hover:text-white rounded-lg transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 bg-white/5 text-gray-400 hover:text-white rounded-lg transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 bg-white/5 text-gray-400 hover:text-white rounded-lg transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-black text-xs uppercase tracking-widest text-gray-500 mb-6">Quick Links</h4>
            <ul className="space-y-4 text-sm text-gray-400 font-medium">
              <li><Link to="/" className="hover:text-white transition-colors">Home</Link></li>
              <li><Link to="/products" className="hover:text-white transition-colors">Products</Link></li>
              <li><Link to="/wishlist" className="hover:text-white transition-colors">Wishlist</Link></li>
              <li><Link to="/orders" className="hover:text-white transition-colors">My Orders</Link></li>
              <li><Link to="/track-order" className="hover:text-white transition-colors">Track Order</Link></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-black text-xs uppercase tracking-widest text-gray-500 mb-6">Categories</h4>
            <ul className="space-y-4 text-sm text-gray-400 font-medium">
              <li><Link to="/products?category=Mobiles" className="hover:text-white transition-colors">Mobiles</Link></li>
              <li><Link to="/products?category=Laptops" className="hover:text-white transition-colors">Laptops</Link></li>
              <li><Link to="/products?category=Gaming" className="hover:text-white transition-colors">Gaming</Link></li>
              <li><Link to="/products?category=Audio" className="hover:text-white transition-colors">Audio</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-black text-xs uppercase tracking-widest text-gray-500 mb-6">Contact Us</h4>
            <ul className="space-y-4 text-sm text-gray-400 font-medium">
              <li className="flex items-center space-x-3">
                <Mail className="w-4 h-4 text-gray-500" />
                <span>{settings.contact_email}</span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="w-4 h-4 text-gray-500" />
                <span>{settings.contact_phone}</span>
              </li>
              <li className="flex items-center space-x-3">
                <MapPin className="w-4 h-4 text-gray-500" />
                <span>{settings.address}</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0 text-[10px] text-gray-500 font-black uppercase tracking-[0.2em]">
          <p>© {new Date().getFullYear()} {settings.brand_name}. All rights reserved.</p>
          <div className="flex space-x-8">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
