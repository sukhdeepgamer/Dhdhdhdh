import { useState, useEffect, FormEvent } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { ShoppingCart, User, LogOut, Search, Menu, X, ChevronDown, Smartphone, Laptop, Headphones, Watch, Tablet, Gamepad2, Camera, Drone, Heart, Wallet, Truck } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { useWishlist } from '../contexts/WishlistContext';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function Navbar() {
  const { user, logout } = useAuth();
  const { items, total, updateQuantity, removeFromCart } = useCart();
  const { wishlist } = useWishlist();
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [settings, setSettings] = useState({ brand_name: 'iCraft Tech' });
  const [categories, setCategories] = useState<string[]>([]);
  const [isScrolled, setIsScrolled] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [homepageSettings, setHomepageSettings] = useState<any>(null);
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [allProducts, setAllProducts] = useState<any[]>([]);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data && data.brand_name) setSettings(data);
        if (data && data.homepage_settings) {
          setHomepageSettings(JSON.parse(data.homepage_settings));
        }
      });
    
    fetch('/api/get-categories')
      .then(res => res.json())
      .then(data => setCategories(data));

    fetch('/api/get-products')
      .then(res => res.json())
      .then(data => setAllProducts(data.products));
  }, []);

  useEffect(() => {
    if (searchQuery.trim().length > 1) {
      const filtered = allProducts.filter(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 6);
      setSuggestions(filtered);
      setShowSuggestions(true);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  }, [searchQuery, allProducts]);

  const handleSearch = (e: FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${searchQuery}`);
      setShowSuggestions(false);
    }
  };

  const categoryIcons: Record<string, any> = {
    'Mobiles': Smartphone,
    'Laptops': Laptop,
    'Audio': Headphones,
    'Wearables': Watch,
    'Tablets': Tablet,
    'Gaming': Gamepad2,
    'Cameras': Camera,
    'Drones': Drone
  };

  return (
    <>
      {homepageSettings?.announcementBar?.enabled && (
        <div 
          className="py-2 px-4 text-center text-[10px] md:text-xs font-black uppercase tracking-[0.2em] transition-all relative z-[60]"
          style={{ 
            backgroundColor: homepageSettings.announcementBar.backgroundColor,
            color: homepageSettings.announcementBar.textColor
          }}
        >
          {homepageSettings.announcementBar.link ? (
            <Link to={homepageSettings.announcementBar.link} className="hover:opacity-80 transition-opacity">
              {homepageSettings.announcementBar.text}
            </Link>
          ) : (
            <span>{homepageSettings.announcementBar.text}</span>
          )}
        </div>
      )}
      <header className={cn(
        "z-50 transition-all duration-300",
        isScrolled ? "bg-white/80 backdrop-blur-xl shadow-lg sticky top-0" : "bg-white"
      )}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            {/* Hamburger Menu */}
            <button 
              onClick={() => setIsMenuOpen(true)}
              className="p-2 -ml-2 text-gray-900 hover:bg-gray-100 rounded-xl transition-colors md:hidden"
            >
              <Menu className="w-6 h-6" />
            </button>

            {/* Logo */}
            <Link to="/" className="flex items-center space-x-3 group">
              <div className="w-12 h-12 bg-black rounded-2xl flex items-center justify-center group-hover:rotate-12 transition-transform duration-300">
                <span className="text-white font-black text-2xl">{settings.brand_name[0]}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-black tracking-tighter text-black leading-none">
                  {settings.brand_name}
                </span>
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400">Premium Tech</span>
              </div>
            </Link>

            {/* Search Bar */}
            <div className="flex-1 max-w-xl mx-12 hidden lg:block relative">
              <form onSubmit={handleSearch} className="relative group">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5 group-focus-within:text-black transition-colors" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => searchQuery.trim().length > 1 && setShowSuggestions(true)}
                  placeholder="Search for the latest tech..."
                  className="w-full pl-12 pr-4 py-3 bg-gray-100 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-black focus:bg-white transition-all font-medium"
                />
              </form>

              {/* Search Suggestions */}
              <AnimatePresence>
                {showSuggestions && suggestions.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden z-[100]"
                  >
                    <div className="p-4 bg-gray-50 border-b border-gray-100">
                      <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">Quick Suggestions</span>
                    </div>
                    {suggestions.map((item) => (
                      <Link
                        key={item.id}
                        to={`/product/${item.id}`}
                        onClick={() => {
                          setShowSuggestions(false);
                          setSearchQuery('');
                        }}
                        className="flex items-center space-x-4 p-4 hover:bg-gray-50 transition-colors group"
                      >
                        <div className="w-12 h-12 rounded-xl overflow-hidden bg-gray-100 flex-shrink-0">
                          <img src={item.image_url} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="text-sm font-bold text-gray-900 truncate group-hover:text-black">{item.name}</h4>
                          <p className="text-xs text-gray-500">{item.category}</p>
                        </div>
                        <div className="text-sm font-black text-black">₹{item.price}</div>
                      </Link>
                    ))}
                    <Link
                      to={`/products?search=${searchQuery}`}
                      onClick={() => setShowSuggestions(false)}
                      className="block p-4 bg-black text-white text-center text-xs font-black uppercase tracking-widest hover:bg-gray-800 transition-colors"
                    >
                      View All Results
                    </Link>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Actions */}
            <div className="flex items-center space-x-6">
              {user ? (
                <div className="flex items-center space-x-6">
                  {user.role === 'admin' && (
                    <Link to="/admin" className="hidden md:block px-4 py-2 bg-black text-white rounded-xl text-xs font-bold uppercase hover:bg-gray-800 transition-all">
                      Admin
                    </Link>
                  )}
                  <Link to="/orders" className="text-gray-900 hover:scale-110 transition-transform">
                    <User className="w-6 h-6" />
                  </Link>
                  <Link to="/wallet" className="text-gray-900 hover:scale-110 transition-transform">
                    <Wallet className="w-6 h-6" />
                  </Link>
                  <Link to="/wishlist" className="group relative p-2 hover:bg-gray-100 rounded-xl transition-all">
                    <Heart className={cn(
                      "w-6 h-6 transition-all duration-300",
                      wishlist.length > 0 ? "text-red-500 fill-current scale-110" : "text-gray-900 group-hover:scale-110"
                    )} />
                    <span className="absolute -top-1 -right-1 bg-black text-white text-[8px] font-black w-4 h-4 rounded-full flex items-center justify-center border-2 border-white shadow-sm">
                      {wishlist.length}
                    </span>
                  </Link>
                  <button onClick={logout} className="text-gray-900 hover:text-red-600 transition-colors hover:scale-110 transition-transform">
                    <LogOut className="w-6 h-6" />
                  </button>
                </div>
              ) : (
                <Link to="/login" className="text-black font-black text-sm uppercase tracking-widest hover:text-gray-600 transition-colors">
                  Login
                </Link>
              )}

              {location.pathname === '/' && (
                <button
                  onClick={() => setIsCartOpen(true)}
                  className="relative p-3 bg-black text-white rounded-2xl hover:scale-110 transition-transform shadow-xl shadow-black/10"
                >
                  <ShoppingCart className="w-6 h-6" />
                  {items.length > 0 && (
                    <span className="absolute -top-2 -right-2 bg-red-500 text-white text-[10px] font-black w-6 h-6 rounded-full flex items-center justify-center border-4 border-white">
                      {items.length}
                    </span>
                  )}
                </button>
              )}
            </div>
          </div>
        </div>

      </header>

      {/* Secondary Menu - Amazon Style (Not Sticky) */}
      <div className="border-t border-gray-100 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-12 overflow-x-auto no-scrollbar whitespace-nowrap space-x-8">
              <div className="relative group h-full flex items-center flex-shrink-0">
                <button className="flex items-center space-x-2 text-sm font-black uppercase tracking-widest text-black hover:text-gray-600 transition-colors h-full">
                  <Menu className="w-5 h-5" />
                  <span>All</span>
                </button>
                
                {/* Mega Dropdown */}
                <div className="absolute top-full left-0 w-64 bg-white shadow-2xl rounded-b-3xl border-t border-gray-100 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-[60] py-4">
                  {categories.map((cat) => {
                    const Icon = categoryIcons[cat] || Smartphone;
                    return (
                      <Link
                        key={cat}
                        to={`/products?category=${cat}`}
                        className="flex items-center space-x-4 px-6 py-3 hover:bg-gray-50 transition-colors group/item"
                      >
                        <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center group-hover/item:bg-black group-hover/item:text-white transition-colors">
                          <Icon className="w-4 h-4" />
                        </div>
                        <span className="text-sm font-bold text-gray-700 group-hover/item:text-black">{cat}</span>
                      </Link>
                    );
                  })}
                </div>
              </div>

              <div className="h-4 w-px bg-gray-200 flex-shrink-0" />

              <nav className="flex items-center space-x-8 h-full">
                {['Mobiles', 'Laptops', 'Gaming', 'Audio', 'Wearables', 'Tablets', 'Cameras', 'Drones'].map((cat) => (
                  <div key={cat} className="relative group h-full flex items-center flex-shrink-0">
                    <Link
                      to={`/products?category=${cat}`}
                      className="text-xs font-black uppercase tracking-widest text-gray-400 hover:text-black transition-colors flex items-center space-x-1"
                    >
                      <span>{cat}</span>
                      <ChevronDown className="w-3 h-3 group-hover:rotate-180 transition-transform" />
                    </Link>
                    
                    {/* Sub-menu on hover */}
                    <div className="absolute top-full left-0 w-48 bg-white shadow-2xl rounded-b-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-[60] py-4 border-t border-gray-100">
                      <div className="px-6 py-2 text-[10px] font-black text-gray-300 uppercase tracking-widest mb-2">Featured</div>
                      <Link to="/products" className="block px-6 py-2 text-sm font-bold text-gray-600 hover:text-black hover:bg-gray-50">New Arrivals</Link>
                      <Link to="/products" className="block px-6 py-2 text-sm font-bold text-gray-600 hover:text-black hover:bg-gray-50">Best Sellers</Link>
                      <Link to="/products" className="block px-6 py-2 text-sm font-bold text-gray-600 hover:text-black hover:bg-gray-50">Special Offers</Link>
                    </div>
                  </div>
                ))}
                <Link to="/products" className="text-xs font-black uppercase tracking-widest text-red-500 hover:text-red-600 transition-colors flex-shrink-0">Deals</Link>
                <div className="h-4 w-px bg-gray-200 flex-shrink-0" />
                <Link 
                  to="/track-order" 
                  className="flex items-center space-x-2 text-xs font-black uppercase tracking-widest text-teal-600 hover:text-teal-700 transition-colors flex-shrink-0"
                >
                  <Truck className="w-4 h-4" />
                  <span>Track Order</span>
                </Link>
              </nav>
            </div>
          </div>
        </div>

      {/* Mobile Menu Drawer */}
      <AnimatePresence>
        {isMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMenuOpen(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60]"
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed left-0 top-0 h-full w-full max-w-xs bg-white z-[70] shadow-2xl flex flex-col"
            >
              <div className="p-6 border-b border-gray-100 flex justify-between items-center">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-black rounded-lg flex items-center justify-center">
                    <span className="text-white font-black text-sm">{settings.brand_name[0]}</span>
                  </div>
                  <span className="font-black tracking-tighter text-black">{settings.brand_name}</span>
                </div>
                <button onClick={() => setIsMenuOpen(false)} className="p-2 hover:bg-gray-100 rounded-full">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-8">
                <div className="space-y-4">
                  <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Categories</h3>
                  <div className="grid grid-cols-1 gap-2">
                    {categories.map((cat) => {
                      const Icon = categoryIcons[cat] || Smartphone;
                      return (
                        <Link
                          key={cat}
                          to={`/products?category=${cat}`}
                          onClick={() => setIsMenuOpen(false)}
                          className="flex items-center space-x-3 p-3 rounded-xl hover:bg-gray-50 transition-colors group"
                        >
                          <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center group-hover:bg-black group-hover:text-white transition-colors">
                            <Icon className="w-5 h-5" />
                          </div>
                          <span className="font-bold text-gray-900">{cat}</span>
                        </Link>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Account</h3>
                  <div className="space-y-2">
                    <Link to="/orders" onClick={() => setIsMenuOpen(false)} className="flex items-center space-x-3 p-3 rounded-xl hover:bg-gray-50 transition-colors">
                      <User className="w-5 h-5 text-gray-400" />
                      <span className="font-bold text-gray-900">My Orders</span>
                    </Link>
                    <Link to="/wallet" onClick={() => setIsMenuOpen(false)} className="flex items-center space-x-3 p-3 rounded-xl hover:bg-gray-50 transition-colors">
                      <Wallet className="w-5 h-5 text-gray-400" />
                      <span className="font-bold text-gray-900">V Wallet</span>
                    </Link>
                    <Link to="/wishlist" onClick={() => setIsMenuOpen(false)} className="flex items-center space-x-3 p-3 rounded-xl hover:bg-gray-50 transition-colors">
                      <Heart className="w-5 h-5 text-gray-400" />
                      <span className="font-bold text-gray-900">Wishlist</span>
                    </Link>
                    <Link to="/track-order" onClick={() => setIsMenuOpen(false)} className="flex items-center space-x-3 p-3 rounded-xl hover:bg-gray-50 transition-colors">
                      <Truck className="w-5 h-5 text-gray-400" />
                      <span className="font-bold text-gray-900">Track Order</span>
                    </Link>
                  </div>
                </div>
              </div>

              <div className="p-6 border-t border-gray-100">
                {user ? (
                  <button 
                    onClick={() => { logout(); setIsMenuOpen(false); }}
                    className="w-full py-4 bg-red-50 text-red-600 rounded-xl font-black uppercase tracking-widest text-xs hover:bg-red-100 transition-colors"
                  >
                    Logout
                  </button>
                ) : (
                  <Link 
                    to="/login" 
                    onClick={() => setIsMenuOpen(false)}
                    className="block w-full py-4 bg-black text-white text-center rounded-xl font-black uppercase tracking-widest text-xs hover:bg-gray-800 transition-colors"
                  >
                    Login / Sign Up
                  </Link>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Cart Drawer */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60]"
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 h-full w-full max-w-md bg-white z-[70] shadow-2xl flex flex-col"
            >
              <div className="p-6 border-b border-gray-100 flex justify-between items-center">
                <h2 className="text-xl font-bold text-gray-900">My Cart</h2>
                <button onClick={() => setIsCartOpen(false)} className="p-2 hover:bg-gray-100 rounded-full">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {items.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-gray-500 space-y-4">
                    <ShoppingCart className="w-16 h-16 opacity-20" />
                    <p className="text-lg">Your cart is empty</p>
                    <button
                      onClick={() => setIsCartOpen(false)}
                      className="text-purple-600 font-semibold hover:underline"
                    >
                      Start Shopping
                    </button>
                  </div>
                ) : (
                  items.map((item) => (
                    <div key={item.id} className="flex space-x-4">
                      <img
                        src={item.image_url}
                        alt={item.name}
                        className="w-20 h-20 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900">{item.name}</h3>
                        <p className="text-sm text-gray-500">₹{item.price * (1 - item.discount / 100)}</p>
                        <div className="flex items-center space-x-3 mt-2">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center hover:bg-gray-50"
                          >
                            -
                          </button>
                          <span className="font-medium">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center hover:bg-gray-50"
                          >
                            +
                          </button>
                        </div>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="text-gray-400 hover:text-red-500"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  ))
                )}
              </div>

              {items.length > 0 && (
                <div className="p-6 border-t border-gray-100 bg-gray-50">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-gray-600">Total Amount</span>
                    <span className="text-2xl font-bold text-gray-900">₹{total.toFixed(2)}</span>
                  </div>
                  <button
                    onClick={() => {
                      setIsCartOpen(false);
                      navigate('/checkout');
                    }}
                    className="w-full py-4 bg-purple-600 text-white rounded-xl font-bold hover:bg-purple-700 transition-all shadow-lg shadow-purple-200"
                  >
                    Proceed to Checkout
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
