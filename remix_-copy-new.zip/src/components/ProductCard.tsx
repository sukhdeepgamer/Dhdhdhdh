import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ShoppingCart, Heart, Star } from 'lucide-react';
import { Product } from '../types';
import { useCart } from '../contexts/CartContext';
import { useWishlist } from '../contexts/WishlistContext';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface ProductCardProps {
  product: Product;
  refElement?: (node: HTMLDivElement | null) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, refElement }) => {
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();

  const discountedPrice = product.price * (1 - product.discount / 100);

  return (
    <motion.div
      ref={refElement}
      whileHover={{ y: -8 }}
      className="group bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 flex flex-col h-full"
    >
      {/* Image Container */}
      <div className="relative aspect-[4/5] overflow-hidden bg-gray-50">
        <Link to={`/product/${product.id}`} className="block w-full h-full">
          <img
            src={product.image_url}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
            referrerPolicy="no-referrer"
          />
        </Link>
        
        {/* Badges */}
        <div className="absolute top-4 left-4 right-4 flex justify-between items-start pointer-events-none">
          {product.discount > 0 ? (
            <div className="px-3 py-1 bg-red-500 text-white text-[10px] font-black uppercase tracking-widest rounded-lg shadow-lg pointer-events-auto">
              -{product.discount}%
            </div>
          ) : <div />}
          
          <button
            onClick={(e) => {
              e.preventDefault();
              toggleWishlist(product);
            }}
            className={cn(
              "p-2.5 rounded-xl transition-all shadow-xl pointer-events-auto",
              isInWishlist(product.id) 
                ? "bg-red-500 text-white" 
                : "bg-white/90 backdrop-blur-md text-gray-400 hover:text-red-500"
            )}
          >
            <Heart className={cn("w-4 h-4", isInWishlist(product.id) && "fill-current")} />
          </button>
        </div>

        {/* Quick Add Overlay (Desktop) */}
        <div className="absolute inset-x-4 bottom-4 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300 hidden md:block">
          <button
            onClick={() => addToCart(product)}
            className="w-full py-3 bg-black text-white rounded-xl font-black uppercase tracking-widest text-[10px] shadow-2xl hover:bg-gray-800 transition-colors flex items-center justify-center space-x-2"
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            <span>Add to Cart</span>
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-5 flex flex-col flex-1 space-y-3">
        <div className="space-y-1">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">
              {product.category}
            </span>
            <div className="flex items-center text-yellow-400">
              <Star className="w-3 h-3 fill-current" />
              <span className="text-[10px] font-black ml-1 text-gray-400">4.8</span>
            </div>
          </div>
          <Link to={`/product/${product.id}`} className="block">
            <h3 className="font-bold text-gray-900 leading-tight line-clamp-2 group-hover:text-black transition-colors">
              {product.name}
            </h3>
          </Link>
        </div>

        <div className="mt-auto pt-2 flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-lg font-black text-black">
              ₹{discountedPrice.toLocaleString()}
            </span>
            {product.discount > 0 && (
              <span className="text-xs text-gray-400 line-through font-medium">
                ₹{product.price.toLocaleString()}
              </span>
            )}
          </div>
          
          {/* Mobile Add to Cart Button */}
          <button
            onClick={() => addToCart(product)}
            className="md:hidden p-3 bg-black text-white rounded-xl shadow-lg active:scale-95 transition-transform"
          >
            <ShoppingCart className="w-4 h-4" />
          </button>
        </div>
        
        {/* Desktop Always Visible Add to Cart (Optional, but user asked for it at bottom) */}
        <button
          onClick={() => addToCart(product)}
          className="hidden md:flex w-full py-3 mt-2 bg-gray-50 text-black border border-gray-100 rounded-xl font-black uppercase tracking-widest text-[10px] hover:bg-black hover:text-white transition-all items-center justify-center space-x-2"
        >
          <ShoppingCart className="w-3.5 h-3.5" />
          <span>Add to Cart</span>
        </button>
      </div>
    </motion.div>
  );
};

export default ProductCard;
