import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingCart, ArrowRight } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

export default function FloatingCart() {
  const { items, total } = useCart();
  const location = useLocation();

  // Only show on home page
  if (location.pathname !== '/') return null;

  return (
    <AnimatePresence>
      {items.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="fixed bottom-24 left-1/2 -translate-x-1/2 z-40"
        >
          <Link to="/checkout" className="block">
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-black text-white px-4 py-2 rounded-full shadow-xl flex items-center space-x-2 border border-white/20"
            >
              <ShoppingCart className="w-3.5 h-3.5" />
              <span className="text-[9px] font-bold uppercase tracking-tight whitespace-nowrap">
                {items.length} Items added in bag
              </span>
            </motion.div>
          </Link>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
