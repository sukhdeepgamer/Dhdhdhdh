import React, { useState, useEffect } from 'react';
import { MapPin, Navigation, Home, Briefcase, MoreHorizontal, Check } from 'lucide-react';
import { Address } from '../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface AddressFormProps {
  initialAddress?: Partial<Address>;
  onSubmit: (address: Address) => void;
  onCancel?: () => void;
}

export default function AddressForm({ initialAddress, onSubmit, onCancel }: AddressFormProps) {
  const [formData, setFormData] = useState<Partial<Address>>({
    fullName: '',
    mobileNumber: '',
    houseNumber: '',
    street: '',
    area: '',
    city: '',
    state: '',
    pincode: '',
    landmark: '',
    type: 'home',
    isDefault: false,
    ...initialAddress
  });

  const [isDetecting, setIsDetecting] = useState(false);

  const handlePincodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const pincode = e.target.value;
    setFormData(prev => ({ ...prev, pincode }));

    // Mock auto-fill logic
    if (pincode.length === 6) {
      if (pincode === '500001') {
        setFormData(prev => ({ ...prev, city: 'Hyderabad', state: 'Telangana' }));
      } else if (pincode === '110001') {
        setFormData(prev => ({ ...prev, city: 'New Delhi', state: 'Delhi' }));
      } else if (pincode === '400001') {
        setFormData(prev => ({ ...prev, city: 'Mumbai', state: 'Maharashtra' }));
      }
    }
  };

  const detectLocation = () => {
    setIsDetecting(true);
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          // In a real app, we'd use reverse geocoding here
          // Mocking for now
          setTimeout(() => {
            setFormData(prev => ({
              ...prev,
              houseNumber: '402, Tech Hub',
              street: 'Madhapur Main Road',
              area: 'Madhapur',
              city: 'Hyderabad',
              state: 'Telangana',
              pincode: '500081'
            }));
            setIsDetecting(false);
          }, 1500);
        },
        (error) => {
          console.error("Error detecting location:", error);
          setIsDetecting(false);
        }
      );
    } else {
      setIsDetecting(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      id: formData.id || Math.random().toString(36).substr(2, 9),
      ...formData
    } as Address);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Full Name</label>
          <input
            required
            type="text"
            value={formData.fullName}
            onChange={e => setFormData(prev => ({ ...prev, fullName: e.target.value }))}
            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-black transition-all"
            placeholder="Recipient's Name"
          />
        </div>
        <div className="space-y-2">
          <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Mobile Number</label>
          <input
            required
            type="tel"
            value={formData.mobileNumber}
            onChange={e => setFormData(prev => ({ ...prev, mobileNumber: e.target.value }))}
            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-black transition-all"
            placeholder="10-digit mobile number"
          />
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Address Details</label>
          <button
            type="button"
            onClick={detectLocation}
            disabled={isDetecting}
            className="flex items-center space-x-1 text-[10px] font-bold uppercase tracking-widest text-teal-600 hover:text-teal-700 transition-colors"
          >
            <Navigation className={cn("w-3 h-3", isDetecting && "animate-spin")} />
            <span>{isDetecting ? 'Detecting...' : 'Use Current Location'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input
            required
            type="text"
            value={formData.houseNumber}
            onChange={e => setFormData(prev => ({ ...prev, houseNumber: e.target.value }))}
            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-black transition-all"
            placeholder="House No., Building Name"
          />
          <input
            required
            type="text"
            value={formData.street}
            onChange={e => setFormData(prev => ({ ...prev, street: e.target.value }))}
            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-black transition-all"
            placeholder="Street Name, Colony"
          />
        </div>

        <input
          required
          type="text"
          value={formData.area}
          onChange={e => setFormData(prev => ({ ...prev, area: e.target.value }))}
          className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-black transition-all"
          placeholder="Area, Sector, Locality"
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <input
            required
            type="text"
            value={formData.pincode}
            onChange={handlePincodeChange}
            maxLength={6}
            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-black transition-all"
            placeholder="Pincode"
          />
          <input
            required
            type="text"
            value={formData.city}
            onChange={e => setFormData(prev => ({ ...prev, city: e.target.value }))}
            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-black transition-all"
            placeholder="City"
          />
          <input
            required
            type="text"
            value={formData.state}
            onChange={e => setFormData(prev => ({ ...prev, state: e.target.value }))}
            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-black transition-all"
            placeholder="State"
          />
        </div>

        <input
          type="text"
          value={formData.landmark}
          onChange={e => setFormData(prev => ({ ...prev, landmark: e.target.value }))}
          className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-black transition-all"
          placeholder="Landmark (Optional)"
        />
      </div>

      <div className="space-y-3">
        <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Address Type</label>
        <div className="flex space-x-4">
          {[
            { id: 'home', icon: Home, label: 'Home' },
            { id: 'work', icon: Briefcase, label: 'Work' },
            { id: 'other', icon: MoreHorizontal, label: 'Other' }
          ].map(type => (
            <button
              key={type.id}
              type="button"
              onClick={() => setFormData(prev => ({ ...prev, type: type.id as any }))}
              className={cn(
                "flex items-center space-x-2 px-4 py-2 rounded-xl border-2 transition-all",
                formData.type === type.id ? "border-black bg-black text-white" : "border-gray-100 text-gray-500 hover:border-gray-200"
              )}
            >
              <type.icon className="w-4 h-4" />
              <span className="text-xs font-bold">{type.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center space-x-3">
        <button
          type="button"
          onClick={() => setFormData(prev => ({ ...prev, isDefault: !prev.isDefault }))}
          className={cn(
            "w-5 h-5 rounded border-2 flex items-center justify-center transition-all",
            formData.isDefault ? "bg-black border-black text-white" : "border-gray-200"
          )}
        >
          {formData.isDefault && <Check className="w-3 h-3" />}
        </button>
        <span className="text-xs font-medium text-gray-600">Set as default address</span>
      </div>

      <div className="flex space-x-4 pt-4">
        <button
          type="submit"
          className="flex-1 py-4 bg-black text-white rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-gray-800 transition-all"
        >
          Save Address
        </button>
        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 py-4 bg-gray-100 text-gray-600 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-gray-200 transition-all"
          >
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}
