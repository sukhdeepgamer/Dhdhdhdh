import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Package, 
  ShoppingBag, 
  BarChart3, 
  Star, 
  Store, 
  TrendingUp, 
  ShieldCheck, 
  MessageSquare, 
  ShieldAlert, 
  Settings, 
  LogOut,
  Truck,
  Percent,
  Receipt,
  Globe,
  Home as HomeIcon,
  Wallet
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function AdminSidebar() {
  const location = useLocation();
  const { logout } = useAuth();

  const menuItems = [
    { icon: LayoutDashboard, label: 'Home', path: '/admin' },
    { icon: HomeIcon, label: 'Homepage Control', path: '/admin/homepage' },
    { icon: Package, label: 'Catalog', path: '/admin/products' },
    { icon: ShoppingBag, label: 'Orders', path: '/admin/orders' },
    { icon: Wallet, label: 'V Wallet', path: '/admin/wallet' },
    { icon: BarChart3, label: 'Analytics', path: '/admin/analytics' },
    { icon: Star, label: 'Manage Reviews', path: '/admin/reviews' },
    { icon: Percent, label: 'Offers & Discounts', path: '/admin/offers' },
    { icon: Truck, label: 'Delivery Settings', path: '/admin/delivery' },
    { icon: Receipt, label: 'Tax Management', path: '/admin/taxes' },
    { icon: Globe, label: 'Shipping Integration', path: '/admin/shipping' },
    { icon: ShieldAlert, label: 'RTO Reduction Suite', path: '/admin/rto' },
    { icon: Store, label: 'Store Configuration', path: '/admin/settings' },
    { icon: TrendingUp, label: 'Growth', path: '/admin/growth' },
    { icon: ShieldCheck, label: 'Trust Markers', path: '/admin/trust' },
    { icon: MessageSquare, label: 'Contact', path: '/admin/contact' },
    { icon: Settings, label: 'Settings', path: '/admin/settings' },
  ];

  return (
    <div className="w-64 bg-admin-sidebar text-white h-screen fixed left-0 top-0 flex flex-col z-50 border-r border-white/5">
      <div className="p-6 flex-1 overflow-y-auto custom-scrollbar">
        <div className="flex items-center space-x-2 mb-8 sticky top-0 bg-admin-sidebar z-10 pb-4">
          <div className="w-8 h-8 bg-teal-400 rounded-lg flex items-center justify-center">
            <Store className="w-5 h-5 text-admin-sidebar" />
          </div>
          <span className="font-display font-bold text-xl tracking-tight">SmartBiz</span>
        </div>
        
        <nav className="space-y-1">
          {menuItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center space-x-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all",
                  isActive
                    ? "bg-teal-500 text-white"
                    : "text-gray-300 hover:bg-white/10 hover:text-white"
                )}
              >
                <item.icon className={cn("w-4 h-4", isActive ? "text-white" : "text-gray-400")} />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>
      
      <div className="mt-auto p-6 border-t border-white/10">
        <button
          onClick={logout}
          className="flex items-center space-x-3 px-4 py-2.5 w-full text-gray-300 hover:text-white hover:bg-white/10 rounded-lg text-sm font-medium transition-all"
        >
          <LogOut className="w-4 h-4 text-gray-400" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
}
