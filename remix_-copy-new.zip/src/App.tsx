import React from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { CartProvider } from './contexts/CartContext';
import { WishlistProvider } from './contexts/WishlistContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import MobileNav from './components/MobileNav';
import Home from './pages/Home';
import Products from './pages/Products';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Checkout from './pages/Checkout';
import ThankYou from './pages/ThankYou';
import Orders from './pages/Orders';
import Wishlist from './pages/Wishlist';
import ProductDetail from './pages/ProductDetail';
import TrackOrder from './pages/TrackOrder';
import AdminDashboard from './pages/admin/Dashboard';
import FloatingCart from './components/FloatingCart';
import AdminProducts from './pages/admin/Products';
import AdminAddProduct from './pages/admin/AddProduct';
import AdminEditProduct from './pages/admin/EditProduct';
import AdminOrders from './pages/admin/Orders';
import AdminUsers from './pages/admin/Users';
import AdminSettings from './pages/admin/Settings';
import AdminAnalytics from './pages/admin/Analytics';
import AdminReviews from './pages/admin/Reviews';
import AdminGrowth from './pages/admin/Growth';
import AdminTrust from './pages/admin/Trust';
import AdminContact from './pages/admin/Contact';
import AdminRTO from './pages/admin/RTO';
import AdminDeliverySettings from './pages/admin/DeliverySettings';
import AdminOffers from './pages/admin/Offers';
import AdminTaxes from './pages/admin/Taxes';
import AdminShipping from './pages/admin/Shipping';
import AdminHomepageControl from './pages/admin/HomepageControl';
import AdminWallet from './pages/admin/Wallet';
import UserWallet from './pages/Wallet';

function ProtectedRoute({ children, adminOnly = false }: { children: React.ReactNode, adminOnly?: boolean }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="h-screen flex items-center justify-center">Loading...</div>;
  if (!user) return <Navigate to="/login" />;
  if (adminOnly && user.role !== 'admin') return <Navigate to="/" />;
  return <>{children}</>;
}

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <WishlistProvider>
          <AppContent />
        </WishlistProvider>
      </CartProvider>
    </AuthProvider>
  );
}

function AppContent() {
  const { pathname } = useLocation();
  const isAdminPage = pathname.startsWith('/admin');

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {!isAdminPage && <Navbar />}
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/products" element={<Products />} />
          <Route path="/product/:id" element={<ProductDetail />} />
          <Route path="/wishlist" element={<Wishlist />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/track-order" element={<TrackOrder />} />
          <Route path="/wallet" element={<ProtectedRoute><UserWallet /></ProtectedRoute>} />
          <Route path="/thank-you" element={<ThankYou />} />
          <Route path="/orders" element={<ProtectedRoute><Orders /></ProtectedRoute>} />
          
          {/* Admin Routes */}
          <Route path="/admin" element={<ProtectedRoute adminOnly><AdminDashboard /></ProtectedRoute>} />
          <Route path="/admin/products" element={<ProtectedRoute adminOnly><AdminProducts /></ProtectedRoute>} />
          <Route path="/admin/products/add" element={<ProtectedRoute adminOnly><AdminAddProduct /></ProtectedRoute>} />
          <Route path="/admin/products/edit/:id" element={<ProtectedRoute adminOnly><AdminEditProduct /></ProtectedRoute>} />
          <Route path="/admin/orders" element={<ProtectedRoute adminOnly><AdminOrders /></ProtectedRoute>} />
          <Route path="/admin/users" element={<ProtectedRoute adminOnly><AdminUsers /></ProtectedRoute>} />
          <Route path="/admin/settings" element={<ProtectedRoute adminOnly><AdminSettings /></ProtectedRoute>} />
          <Route path="/admin/analytics" element={<ProtectedRoute adminOnly><AdminAnalytics /></ProtectedRoute>} />
          <Route path="/admin/reviews" element={<ProtectedRoute adminOnly><AdminReviews /></ProtectedRoute>} />
          <Route path="/admin/growth" element={<ProtectedRoute adminOnly><AdminGrowth /></ProtectedRoute>} />
          <Route path="/admin/trust" element={<ProtectedRoute adminOnly><AdminTrust /></ProtectedRoute>} />
          <Route path="/admin/contact" element={<ProtectedRoute adminOnly><AdminContact /></ProtectedRoute>} />
          <Route path="/admin/rto" element={<ProtectedRoute adminOnly><AdminRTO /></ProtectedRoute>} />
          <Route path="/admin/homepage" element={<ProtectedRoute adminOnly><AdminHomepageControl /></ProtectedRoute>} />
          <Route path="/admin/delivery" element={<ProtectedRoute adminOnly><AdminDeliverySettings /></ProtectedRoute>} />
          <Route path="/admin/offers" element={<ProtectedRoute adminOnly><AdminOffers /></ProtectedRoute>} />
          <Route path="/admin/taxes" element={<ProtectedRoute adminOnly><AdminTaxes /></ProtectedRoute>} />
          <Route path="/admin/shipping" element={<ProtectedRoute adminOnly><AdminShipping /></ProtectedRoute>} />
          <Route path="/admin/wallet" element={<ProtectedRoute adminOnly><AdminWallet /></ProtectedRoute>} />
        </Routes>
      </main>
      {!isAdminPage && <Footer />}
      {!isAdminPage && <MobileNav />}
      {!isAdminPage && <FloatingCart />}
      <Toaster position="bottom-center" />
    </div>
  );
}
